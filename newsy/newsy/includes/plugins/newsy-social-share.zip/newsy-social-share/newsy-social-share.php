<?php
/*
Plugin Name: Newsy Social Share
Plugin URI: http://akbilisim.com
Description: Social share for Newsy. Add functionality for showing share buttons and share counts.
Version: 1.0.1
Author: akbilisim
Author URI: http://akbilisim.com
License: GPL2
*/

defined( 'NEWSY_SOCIAL_SHARE' ) or define( 'NEWSY_SOCIAL_SHARE', 'newsy-social-share' );
defined( 'NEWSY_SOCIAL_SHARE_VERSION' ) or define( 'NEWSY_SOCIAL_SHARE_VERSION', '1.0.1' );
defined( 'NEWSY_SOCIAL_SHARE_URI' ) or define( 'NEWSY_SOCIAL_SHARE_URI', plugins_url( NEWSY_SOCIAL_SHARE ) );
defined( 'NEWSY_SOCIAL_SHARE_PATH' ) or define( 'NEWSY_SOCIAL_SHARE_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Newsy Social Share init.
 */
if ( ! function_exists( 'newsy_social_share_load' ) ) {
	function newsy_social_share_load() {
		require_once 'class.newsy-social-share.php';
		Newsy_Social_Share::get_instance();

		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( NEWSY_SOCIAL_SHARE, false, basename( __DIR__ ) . '/languages/' );
	}
}

add_action( 'plugins_loaded', 'newsy_social_share_load' );

if ( ! function_exists( 'newsy_get_share_buttons' ) ) {
	/**
	 * Get social share buttons.
	 */
	function newsy_get_share_buttons( $sites, $post_id = null, $style = 'style-1', $count_type = 'total', $show_count = 3 ) {
		return Newsy_Social_Share::get_instance()->get_share_buttons( $sites, $post_id, $style, $count_type, $show_count );
	}
}

if ( ! function_exists( 'newsy_get_share_counts' ) ) {
	/**
	 * Helper function to get share counts.
	 */
	function newsy_get_share_counts( $post_id, $only_total = false, $force_update = false ) {
		return Newsy_Social_Share::get_instance()->get_share_counts( $post_id, $only_total, $force_update );
	}
}

if ( ! function_exists( 'newsy_get_share_options' ) ) {
	/**
	 * Handy callback to set all social share sites list.
	 *
	 * @return array
	 */
	function newsy_get_share_options() {
		return array(
			'facebook'    => '<i class="fa fa-facebook"></i> ' . __( 'Facebook', 'newsy-social-share' ),
			'twitter'     => '<i class="fa fa-twitter"></i> ' . __( 'Twitter', 'newsy-social-share' ),
			'pinterest'   => '<i class="fa fa-pinterest"></i> ' . __( 'Pinterest', 'newsy-social-share' ),
			'reddit'      => '<i class="fa fa-reddit-alien"></i> ' . __( 'ReddIt', 'newsy-social-share' ),
			'linkedin'    => '<i class="fa fa-linkedin"></i> ' . __( 'Linkedin', 'newsy-social-share' ),
			'tumblr'      => '<i class="fa fa-tumblr"></i> ' . __( 'Tumblr', 'newsy-social-share' ),
			'telegram'    => '<i class="fa fa-send"></i> ' . __( 'Telegram', 'newsy-social-share' ),
			'stumbleupon' => '<i class="fa fa-stumbleupon"></i> ' . __( 'StumbleUpon', 'newsy-social-share' ),
			'vk'          => '<i class="fa fa-vk"></i> ' . __( 'VK', 'newsy-social-share' ),
			'digg'        => '<i class="fa fa-digg"></i> ' . __( 'Digg', 'newsy-social-share' ),
			'whatsapp'    => '<i class="fa fa-whatsapp"></i> ' . __( 'Whatsapp (Only Mobiles)', 'newsy-social-share' ),
			'line'        => '<i class="fa fa-commenting"></i> ' . __( 'LINE (Only Mobiles)', 'newsy-social-share' ),
			'viber'       => '<i class="fa fa-volume-control-phone"></i> ' . __( 'Viber (Only Mobiles)', 'newsy-social-share' ),
			'email'       => '<i class="fa fa-envelope"></i> ' . __( 'Email', 'newsy-social-share' ),
		);
	}
}
