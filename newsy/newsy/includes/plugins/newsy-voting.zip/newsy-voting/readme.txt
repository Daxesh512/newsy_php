Change Log :

== 1.0.1 ==
- [IMPROVEMENT] Plugin translation

== 1.0.0 ==
- First Release
