<?php
/**
 * Newsy Voting MyCred Hook class
 */
class Newsy_Voting_myCRED_Hook extends myCRED_Hook {
	/**
	 * Construct
	 */
	public function __construct( $hook_prefs, $type = MYCRED_DEFAULT_TYPE_KEY ) {
		parent::__construct(
			array(
				'id'       => 'newsy_voting',
				'defaults' => array(
					'creds' => 1,
					'log'   => ak_get_translation( 'Voted for %post_title% with: %vote%', 'newsy-voting', 'voted_hook' ),
				),
			), $hook_prefs, $type
		);
	}

	/**
	 * Run.
	 */
	public function run() {
		add_action( 'newsy-voting/vote/added', array( $this, 'vote_added' ), 10, 2 );
		add_filter( 'mycred_parse_tags_newsy_voting', array( $this, 'parse_custom_tags' ), 10, 2 );
	}

	/**
	 * Parse Custom Tags in Log
	 */
	public function parse_custom_tags( $content, $log_entry ) {
		$data       = maybe_unserialize( $log_entry->data );
		$post_title = get_the_title( $data['post_id'] );
		$content    = str_replace( '%post_title%', $post_title, $content );
		$content    = str_replace( '%vote%', $data['vote'], $content );
		return $content;
	}

	/**
	 * Handle added vote.
	 *
	 * @param array $vote_arr  Vote array.
	 * @param array $meta       Post meta.
	 */
	public function vote_added( $post_id, $vote ) {
		$user_id = get_current_user_id();
		$amount  = $this->prefs['creds'];
		$entry   = $this->prefs['log'];
		$data    = array(
			'ref_type' => 'newsy_voting',
			'vote'     => $vote ? ak_get_translation( 'Up/Liked', 'newsy-voting', 'up_liked' ) : ak_get_translation( 'Down/Unliked', 'newsy-voting', 'down_unliked' ),
			'post_id'  => $post_id,
		);
		$this->core->add_creds(
			'newsy_voting',
			$user_id,
			$amount,
			$entry,
			'',
			$data,
			$this->mycred_type
		);
	}

	/**
	 * Preferences.
	 */
	public function preferences() {
		$prefs = $this->prefs;
		?>
			<div class="hook-instance">
			<h3><?php _ex( 'Voted for a post', 'myCRED hook instance', 'newsy-voting' ); ?></h3>
			<div class="row">
				<div class="col-lg-2 col-md-6 col-sm-6 col-xs-12">
					<div class="form-group">
						<label for="<?php echo $this->field_id( 'creds' ); ?>"><?php echo $this->core->plural(); ?></label>
						<input type="text" name="<?php echo $this->field_name( 'creds' ); ?>" id="<?php echo $this->field_id( 'creds' ); ?>"
						value="<?php echo $this->core->number( $prefs['creds'] ); ?>" class="form-control" />
					</div>
				</div>
				<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
					<div class="form-group">
						<label for="<?php echo $this->field_id( 'log' ); ?>"><?php _e( 'Log template', 'newsy-voting' ); ?></label>
						<input type="text" name="<?php echo $this->field_name( 'log' ); ?>" id="<?php echo $this->field_id( 'log' ); ?>" placeholder="<?php _e( 'required', 'newsy-voting' ); ?>" value="<?php echo esc_attr( $prefs['log'] ); ?>" class="form-control" />
						<span class="description"><?php echo $this->available_template_tags( array( 'general', 'user' ), '%post_title%, %vote%' ); ?></span>
					</div>
				</div>
			</div>
			</div>
		<?php
	}
}
