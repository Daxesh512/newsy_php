<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Newsy Voting
 */
class Newsy_Voting {

	/**
	 * @var Newsy_Voting
	 */
	private static $instance;

	/**
	 * @var string
	 */
	private $table_name = 'newsy_post_votes';

	/**
	 * @var string
	 */
	private $meta_prefix = 'newsy_post_vote_count';

	/**
	 * @return Newsy_Voting
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * Activation hook plugin
	 */
	public function activation_hook() {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		if ( $wpdb->get_var( "show tables like '$table_name'" ) != $table_name ) {
			$sql = 'CREATE TABLE ' . $table_name . " (
                    `id` bigint(11) NOT NULL AUTO_INCREMENT,
                    `post_id` int(11) NOT NULL,
                    `user_id` bigint(20) NOT NULL DEFAULT '0',
                    `vote` int(2) NOT NULL,
                    `date_time` datetime NOT NULL,
                    PRIMARY KEY (`id`), INDEX (`post_id`)
                )";

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
		}
	}

	/**
	 * Get total like and dislike
	 *
	 * @param int $post_id
	 *
	 * @return string  $result
	 *
	 */
	public function get_total_count( $post_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(id) FROM $table_name WHERE post_id = %d",
				$post_id
			)
		);

		return $result;
	}

	/**
	 * Get total like and dislike
	 *
	 * @param int $post_id
	 * @param string  $vote
	 *
	 * @return string  $result
	 *
	 */
	public function get_vote_count( $post_id, $vote ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		if ( 'up' === $vote ) {
			$result = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(id) FROM $table_name WHERE post_id = %d AND vote > 0",
					$post_id
				)
			);

			return $result;
		}

		if ( 'down' === $vote ) {
			$result = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(id) FROM $table_name WHERE post_id = %d AND vote < 0",
					$post_id
				)
			);

			return $result;
		}

		return false;
	}

	/**
	 * Get status if have liked or disliked
	 *
	 * @param  integer $post_id
	 * @param  integer $author_id
	 *
	 * @return int  $status
	 */
	public function get_status( $post_id, $author_id = 0 ) {

		if ( 0 === $author_id ) {
			$author_id = get_current_user_id();
		}

		// User not logged in, guest voting disabled.
		if ( 0 === $author_id && ! $this->is_guest_voting_enabled() ) {
			return false;
		}

		// User not logged in, guest voting enabled.
		if ( 0 === $author_id && $this->is_guest_voting_enabled() ) {
			$vote_cookie = filter_input( INPUT_COOKIE, 'newsy_voting_vote_' . $post_id, FILTER_SANITIZE_STRING );

			return $vote_cookie;
		}

		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$status = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT vote FROM $table_name WHERE post_id = %d AND user_id = %d ORDER BY id DESC LIMIT 1",
				$post_id,
				$author_id
			)
		);

		return $status;
	}

	/**
	* Get value of action
	*
	* @param  string $status
	* @param  string $action
	*
	* @return int
	*/
	public function get_converted_value( $status, $vote ) {
		$value = 0;

		if ( '1' === $status ) {
			$status = 'up';
		} elseif ( '-1' === $status ) {
			$status = 'down';
		}

		if ( 'up' === $vote ) {
			$value = 1;
		}

		if ( 'down' === $vote ) {
			$value = -1;
		}

		if ( $status === $vote ) {
			$value = 0;
		}

		return $value;
	}

	/**
	 * Insert data into database
	 *
	 * @param int $post_id
	 * @param string  $vote
	 *
	 * @return bool
	 */
	public function insert_vote( $post_id, $user_id, $vote ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$result = $wpdb->insert(
			$table_name,
			array(
				'post_id'   => $post_id,
				'user_id'   => $user_id,
				'vote'      => $vote,
				'date_time' => date( 'Y-m-d H:i:s' ),
			),
			array(
				'%d',
				'%d',
				'%s',
				'%s',
			)
		);

		return $result;
	}

	/**
	 * Update data value into database
	 *
	 * @param int $post_id
	 * @param string  $vote
	 *
	 * @return bool
	 *
	 */
	public function update_vote( $post_id, $user_id, $vote ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$result = $wpdb->update(
			$table_name,
			array(
				'vote'      => $vote,
				'date_time' => date( 'Y-m-d H:i:s' ),
			),
			array(
				'post_id' => $post_id,
				'user_id' => $user_id,
			)
		);

		return $result;
	}

	/**
	 * Update data value into database
	 *
	 * @param  integer $post_id
	 * @param  string  $vote
	 *
	 * @return bool
	 *
	 */
	public function update_meta_vote( $post_id ) {
		$up_count   = $this->get_vote_count( $post_id, 'up' );
		$down_count = $this->get_vote_count( $post_id, 'down' );
		$avg_count  = ceil( intval( $up_count ) - intval( $down_count ) );

		ak_update_post_meta( $this->meta_prefix . '_up', $post_id, $up_count );
		ak_update_post_meta( $this->meta_prefix . '_down', $post_id, $down_count );
		ak_update_post_meta( $this->meta_prefix . '_avg', $post_id, $avg_count );
	}

	/**
	 * Check whether guest user can vote
	 *
	 * @return bool
	 */
	public function get_meta_vote( $post_id, $vote ) {
		return ak_get_post_meta( $this->meta_prefix . '_' . $vote, $post_id, '0' );
	}

	/**
	 * Get total like of post
	 *
	 * @param  int $post_id
	 *
	 * @return string
	 *
	 */
	public function get_up_count( $post_id ) {
		return apply_filters( 'newsy_get_post_voting_up_count', $this->get_meta_vote( $post_id, 'up' ), $post_id );
	}

	/**
	 * Get total dislike of post
	 *
	 * @param  int $post_id
	 *
	 * @return string
	 *
	 */
	public function get_down_count( $post_id ) {
		return apply_filters( 'newsy_get_post_voting_down_count', $this->get_meta_vote( $post_id, 'down' ), $post_id );
	}

	/**
	 * Get total avarage voting of post
	 *
	 * @param  int $post_id
	 *
	 * @return string
	 *
	 */
	public function get_average_count( $post_id, $up_count = null, $down_count = null ) {
		if ( ! $up_count ) {
			$up_count = $this->get_up_count( $post_id );
		}
		if ( ! $down_count ) {
			$down_count = $this->get_down_count( $post_id );
		}

		$avg_count = ceil( intval( $up_count ) - intval( $down_count ) );

		return apply_filters( 'newsy_voting_average_count', $avg_count, $post_id );
	}

	/**
	 * Get status if have liked or disliked
	 *
	 * @param  integer $post_id
	 *
	 * @return int  $status
	 *
	 */
	public function send_success( $post_id, $vote ) {
		$this->update_meta_vote( $post_id );

		$up_count   = $this->get_up_count( $post_id );
		$down_count = $this->get_down_count( $post_id );
		$avg_count  = $this->get_average_count( $post_id, $up_count, $down_count );

		wp_send_json(
			array(
				'response'   => 1,
				'message'    => ak_get_translation( 'Thanks for your vote!', 'newsy-voting', 'thanks_for_vote' ),
				'up_count'   => apply_filters( 'newsy_number_format', $up_count ),
				'down_count' => apply_filters( 'newsy_number_format', $down_count ),
				'avg_count'  => apply_filters( 'newsy_number_format', $avg_count ),
				'vote'       => $vote,
			)
		);
	}

	/**
	 * Get status if have liked or disliked
	 *
	 * @param  integer $post_id
	 *
	 * @return int  $status
	 *
	 */
	public function send_fail() {
		wp_send_json(
			array(
				'response' => 0,
				'message'  => ak_get_translation( 'Failed to send request!', 'newsy-voting', 'failed_for_vote' ),
			)
		);
	}

	/**
	 * Main function
	 *
	 * @param  integer $post_id
	 * @param  string  $type
	 *
	 * @return json
	 *
	 */
	public function ajax_do_action( $post_id, $vote ) {
		$user_id = $this->get_current_user_id();
		$status  = $this->get_status( $post_id, $user_id );
		$vote    = $this->get_converted_value( $status, $vote );

		do_action( 'newsy-voting/vote', $post_id, $vote, $status );

		if ( null === $status ) {
			$result = $this->insert_vote( $post_id, $user_id, $vote );

			if ( $result ) {
				do_action( 'newsy-voting/vote/added', $post_id, $vote );

				$this->send_success( $post_id, $vote );
			} else {
				$this->send_fail();
			}
		} else {
			$result = $this->update_vote( $post_id, $user_id, $vote );

			if ( $result ) {
				do_action( 'newsy-voting/vote/added', $post_id, $vote );

				$this->send_success( $post_id, $vote );
			} else {
				$this->send_fail();
			}
		}
	}

	/**
	 * Main function for ajax
	 */
	public function ajax_vote() {
		check_ajax_referer( 'newsy-voting-vote', 'nonce' );

		if ( ! is_user_logged_in() && ! $this->is_guest_voting_enabled() ) {
			wp_send_json(
				array(
					'response' => -1,
					'message'  => ak_get_translation( 'You must login to vote!', 'newsy-reaction', 'must_login_vote' ),
				)
			);
		}

		// Sanitize post id.
		$post_id = (int) filter_input( INPUT_POST, 'post_id', FILTER_SANITIZE_NUMBER_INT ); // Removes all illegal characters from a number.

		if ( 0 === $post_id ) {
			$this->send_fail();
			exit;
		}

		$post = get_post( $post_id );

		if ( ! $post ) {
			$this->send_fail();
			exit;
		}

		// Sanitize type.
		$vote = filter_input( INPUT_POST, 'vote', FILTER_SANITIZE_STRING );

		$this->ajax_do_action( $post->ID, $vote );

		die();
	}

	/**
	 * Check whether guest user can vote
	 *
	 * @return bool
	 */
	public function get_current_user_id() {
		return is_user_logged_in() ? get_current_user_id() : '';
	}

	/**
	 * Check whether guest user can vote
	 *
	 * @return bool
	 */
	public function is_guest_voting_enabled() {
		return newsy_get_option( 'post_voting_guest_is_enabled' ) !== 'off';
	}
}
