<?php

/**
 * Block
 */
$fields[] = array(
	'heading' => 'Voting',
	'id'      => 'voting_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Points',
	'default' => 'Points',
	'id'      => 'points',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Thanks for your vote!',
	'default' => 'Thanks for your vote!',
	'id'      => 'thanks_for_vote',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Failed to send request!',
	'default' => 'Failed to send request!',
	'id'      => 'failed_for_vote',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'You must login to vote!',
	'default' => 'You must login to vote!',
	'id'      => 'must_login_vote',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Thanks for your vote!',
	'default' => 'Thanks for your vote!',
	'id'      => 'thanks_for_vote',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Block',
	'id'      => 'block_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Most Liked',
	'default' => 'Most Liked',
	'id'      => 'most_liked',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Most Disliked',
	'default' => 'Most Disliked',
	'id'      => 'most_disliked',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Voting Average',
	'default' => 'Voting Average',
	'id'      => 'voting_avg',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'myCred',
	'id'      => 'mycred_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Voted for %post_title% with: %vote%',
	'default' => 'Voted for %post_title% with: %vote%',
	'id'      => 'voted_hook',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Up/Liked',
	'default' => 'Up/Liked',
	'id'      => 'up_liked',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Down/Unliked',
	'default' => 'Down/Unliked',
	'id'      => 'down_unliked',
	'type'    => 'text',
	'section' => 'translation',
);
