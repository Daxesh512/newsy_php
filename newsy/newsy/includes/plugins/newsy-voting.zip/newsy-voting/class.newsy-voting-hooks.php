<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Newsy Voting Hooks
 */
class Newsy_Voting_Hooks {

	/**
	 * @var Newsy_Voting_Hooks
	 */
	private static $instance;

	/**
	 * @return Newsy_Voting_Hooks
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * Newsy_Voting_Hooks constructor.
	 */
	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 999 );
		add_action( 'ak-framework/frontend/ajax', array( $this, 'register_ajax' ) );
		add_filter( 'ak-framework/post-query-args', array( $this, 'register_post_query_args' ), 11, 2 );
		add_filter( 'newsy_block_order_by_options', array( $this, 'register_order_by_options' ), 11, 1 );

		add_filter( 'newsy_module_bottom_meta', array( $this, 'add_voting_module_bottom' ), 11, 2 );
		add_filter( 'newsy_single_post_social_share_top', array( $this, 'add_voting_post_share' ), 11, 2 );
		add_action( 'newsy_single_post_meta_right_before', array( $this, 'render_voting_meta_left' ) );
		add_action( 'newsy_single_post_meta_right_after', array( $this, 'render_voting_meta_right' ) );

		add_action( 'mycred_load_hooks', array( $this, 'mycred_load_hook' ), 69 );
		add_filter( 'mycred_setup_hooks', array( $this, 'mycred_register_hook' ), 69 );
		add_filter( 'mycred_all_references', array( $this, 'mycred_register_reference' ), 10, 1 );
		add_filter( 'ak-framework/register/translation', array( $this, 'register_translation_fields' ), 30 );
	}

	/**
	 * Load plugin assest
	 */
	public function register_assets() {
		wp_enqueue_script( NEWSY_VOTING, NEWSY_VOTING_URI . '/js/plugin.js', null, NEWSY_VOTING_VERSION, true );
	}

	/**
		 * Main function for ajax
		 */
	public function register_ajax( $action ) {
		if ( 'newsy_post_vote' === $action ) {
			Newsy_Voting::get_instance()->ajax_vote();
		}
	}

	/**
	 * Main function for ajax
	 */
	public function register_post_query_args( $args, $atts ) {
		// orderby
		if ( ! empty( $atts['order_by'] ) ) {
			switch ( $atts['order_by'] ) {
				case 'voting_up':
					$args['orderby']  = 'meta_value_num';
					$args['meta_key'] = 'ak_newsy_post_vote_count_up';
					$args['order']    = 'DESC';
					break;
				case 'voting_down':
					$args['orderby']  = 'meta_value_num';
					$args['meta_key'] = 'ak_newsy_post_vote_count_down';
					$args['order']    = 'DESC';
					break;
				case 'voting_avg':
					$args['orderby']  = 'meta_value_num';
					$args['meta_key'] = 'ak_newsy_post_vote_count_avg';
					$args['order']    = 'DESC';
					break;
			}
		}

		return $args;
	}
	/**
	 * Main function for ajax
	 */
	public function register_order_by_options( $options ) {
		$options['voting_up']   = ak_get_translation( 'Most Liked', 'newsy-voting', 'most_liked' );
		$options['voting_down'] = ak_get_translation( 'Most Disliked', 'newsy-voting', 'most_disliked' );
		$options['voting_avg']  = ak_get_translation( 'Voting Average', 'newsy-voting', 'voting_avg' );
		return $options;
	}

	/**
	 * Load plugin assest
	 */
	public function add_voting_module_bottom( $share_output, $post_id ) {
		$voting_output = $this->get_voting_element( $post_id, 'hide' );

		return '<div class="ak-row">
                    <div class="ak-column ak-column-normal">' . $voting_output . '</div>
                    <div class="ak-column ak-column-grow">' . $share_output . '</div>
                </div>';
	}
	/**
	 * Load plugin assest
	 */
	public function add_voting_post_share( $share_output, $post_id ) {
		if ( 'share_right' === newsy_get_option( 'post_voting_position', 'meta_left' ) ) {
			$voting_output = $this->get_voting_element( $post_id );

			return '<div class="ak-row">
                        <div class="ak-column ak-column-grow">' . $share_output . '</div>
                        <div class="ak-column ak-column-normal">' . $voting_output . '</div>
                    </div>';
		}

		return $share_output;
	}

	/**
	 * Load plugin assest
	 */
	public function render_voting_meta_left( $post_id ) {
		if ( 'meta_left' === newsy_get_option( 'post_voting_position', 'meta_left' ) ) {
			$this->render_voting_element( $post_id );
		}
	}

	/**
	 * Load plugin assest
	 */
	public function render_voting_meta_right( $post_id ) {
		if ( 'meta_right' === newsy_get_option( 'post_voting_position', 'meta_left' ) ) {
			$this->render_voting_element( $post_id );
		}
	}

	/**
	 * Generate like element
	 *
	 * @param int $post_id
	 * @param bool $show_count
	 *
	 * @return string
	 *
	 */
	public function get_up_btn( $post_id, $show_count = false ) {
		$nonce = wp_create_nonce( 'newsy-voting-vote' );
		$icon  = newsy_get_option( 'post_voting_up_icon', 'fa-thumbs-o-up' );
		$icon  = ak_get_icon( $icon );
		$total = $show_count ? '<span class="number">' . Newsy_Voting::get_instance()->get_up_count( $post_id ) . '</span>' : '';

		return "<a class='ak-voting-button up-btn' href='#' data-post-id='{$post_id}' data-type='up' data-nonce='{$nonce}'>
                   {$icon} {$total}
                </a>";
	}

	/**
	 * Generate dislike element
	 *
	 * @param int $post_id
	 * @param bool $show_count
	 *
	 * @return string
	 *
	 */
	public function get_down_btn( $post_id, $show_count = false ) {
		$nonce = wp_create_nonce( 'newsy-voting-vote' );
		$icon  = newsy_get_option( 'post_voting_down_icon', 'fa-thumbs-o-down' );
		$icon  = ak_get_icon( $icon );
		$total = $show_count ? '<span class="number">' . Newsy_Voting::get_instance()->get_down_count( $post_id ) . '</span>' : '';

		return "<a class='ak-voting-button down-btn' href='#' data-post-id='{$post_id}' data-type='down' data-nonce='{$nonce}'>
                    {$icon} {$total}
                </a>";
	}

	/**
	 * Load plugin assest
	 */
	public function get_voting_element( $post_id, $counts = '' ) {
		$instance = Newsy_Voting::get_instance();
		$status   = $instance->get_status( $post_id );
		$style    = newsy_get_option( 'post_voting_style' );

		if ( '' === $counts ) {
			$counts = newsy_get_option( 'post_voting_count_type', 'total' );
		}

		$show_items_count = ( 'items_count' === $counts );

		$is_voted = '';
		if ( '1' === $status ) {
			$is_voted = 'post-voted up-voted';
		} elseif ( '-1' === $status ) {
			$is_voted = 'post-voted down-voted';
		}

		$up_btn   = $this->get_up_btn( $post_id, $show_items_count );
		$down_btn = '';
		if ( 'yes' !== newsy_get_option( 'post_voting_single' ) ) {
			$down_btn = $this->get_down_btn( $post_id, $show_items_count );
		}

		$avg_count = '';
		if ( 'total' === $counts ) {
			$vote_count = $instance->get_average_count( $post_id );

			$avg_count = sprintf( '<span class="ak-voting-count"><span class="counts">%s</span><span class="points-text">%s</span></span>', $vote_count, ak_get_translation( 'Points', 'newsy-voting', 'points' ) );
		}

		$output =
			"<div class='ak-post-voting {$is_voted} {$style} clearfix'>
				{$up_btn}
                {$avg_count}
                {$down_btn}
            </div>";

		return $output;
	}

	/**
	 * Load plugin assest
	 */
	public function render_voting_element( $post_id ) {
		echo $this->get_voting_element( $post_id );
	}

	/**
	 * Add reference
	 *
	 * @param array $references References.
	 * @return array
	 */
	public function mycred_register_reference( $references ) {
		$references['newsy_voting'] = _x( 'Voted for a post', 'myCRED reference', 'newsy-voting' );
		return $references;
	}

	/**
	 * Register hook
	 *
	 * @param array $installed Installed hooks.
	 * @return array
	 */
	public function mycred_register_hook( $installed ) {
		$installed['newsy_voting'] = array(
			'title'       => _x( 'Vote for a post', 'myCRED hook name', 'newsy-voting' ),
			'description' => _x( 'Awards for voting post.', 'myCRED hook description', 'newsy-voting' ),
			'callback'    => array( 'Newsy_Voting_myCRED_Hook' ),
		);

		return $installed;
	}

	/**
	 * myCred Hook
	 */
	public function mycred_load_hook() {
		require_once NEWSY_VOTING_PATH . 'class.newsy-voting-mycred-hook.php';
	}


	/**
	 * Register the Newsy voting translations to framework.
	 *
	 * @return array
	 */
	public function register_translation_fields( $fields ) {
		$fields['newsy-voting'] = array(
			'name' => __( 'Newsy Voting', 'newsy-voting' ),
			'file' => NEWSY_VOTING_PATH . 'includes/translation.php',
		);

		return $fields;
	}
}
