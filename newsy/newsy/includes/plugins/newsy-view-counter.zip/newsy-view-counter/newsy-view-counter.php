<?php
/*
Plugin Name: Newsy View Counter
Plugin URI: http://akbilisim.com
Description: View counter for Newsy. Add functionality for showing top daily, weekly post..
Version: 1.0.1
Author: akbilisim
Author URI: http://akbilisim.com
License: GPL2
*/

defined( 'NEWSY_VIEW_COUNTER' ) or define( 'NEWSY_VIEW_COUNTER', 'newsy-view-counter' );
defined( 'NEWSY_VIEW_COUNTER_URI' ) or define( 'NEWSY_VIEW_COUNTER_URI', plugins_url( NEWSY_VIEW_COUNTER ) );
defined( 'NEWSY_VIEW_COUNTER_PATH' ) or define( 'NEWSY_VIEW_COUNTER_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Newsy View Counter init.
 */
if ( ! function_exists( 'newsy_view_counter_load' ) ) {
	function newsy_view_counter_load() {
		require_once 'class.newsy-view-counter.php';
		Newsy_View_Counter::get_instance();

		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( NEWSY_VIEW_COUNTER, false, basename( __DIR__ ) . '/languages/' );
	}
}

add_action( 'plugins_loaded', 'newsy_view_counter_load' );

if ( ! function_exists( 'newsy_get_post_view_count' ) ) {
	/**
	 * Helper function to get view counts.
	 */
	function newsy_get_post_view_count( $post_id, $force_update = false ) {
		return Newsy_View_Counter::get_instance()->get_page_views( $post_id, $force_update );
	}
}
