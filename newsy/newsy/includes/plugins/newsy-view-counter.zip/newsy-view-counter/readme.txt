Change Log :

== 1.0.1 ==
- [FIX] Issue on user post read counts

== 1.0.0 ==
- First Release
