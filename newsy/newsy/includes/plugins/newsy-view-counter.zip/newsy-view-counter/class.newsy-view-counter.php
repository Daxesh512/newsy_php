<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Newsy_View_Counter {

	/**
	 * The Newsy View Counter object instance.
	 *
	 * @var Newsy_View_Counter
	 */
	private static $instance;

	/**
	 * Version of Newsy View Counter.
	 *
	 * @var string
	 */
	public $version = '1.0.1';

	/**
	 * the name of the field total count for the given post.
	 *
	 * @var string
	 */
	public $post_view_counter_key = 'ak_post_views_count';

	/**
	 * the name of the field total views count for the user.
	 *
	 * @var string
	 */
	public $user_view_counter_key = 'ak_total_posts_view_count';

	/**
	 * the name of the field for the total of 7 days
	 *
	 * @var string
	 */
	public $post_view_counter_7_day_total = 'ak_post_views_count_7_day_total';

	/**
	 * the name of the field for the 7 days last page view - used on td_data_source to filter the posts with views older than 7 days
	 *
	 * @var string
	 */
	public $post_view_counter_7_day_last_date = 'ak_post_views_count_7_day_last_date';

	/**
	 * the name of the field where 7 days counter are kept(in a serialized array) for the given post
	 *
	 * @var string
	 */
	private $post_view_counter_7_day_array = 'ak_post_views_count_7_day_arr';

	private $post_view_7days_last_day = 'ak_post_view_7days_last_day';

	/**
	 * @return Newsy_View_Counter
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
			static::$instance->register_hooks();
		}

		return static::$instance;
	}

	/**
	 * Setup hooks.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_filter( 'manage_posts_columns', array( $this, 'on_manage_posts_columns_views' ) );
		add_action( 'manage_posts_custom_column', array( $this, 'on_manage_posts_custom_column' ), 10, 2 );

		add_filter( 'ak-framework/post-query-args', array( $this, 'register_post_query_args' ), 11, 2 );
		add_filter( 'newsy_block_order_by_options', array( $this, 'register_order_by_options' ), 16 );
	}

	//used only in single.php to update the views
	public function update_page_views( $post_id ) {
		//used for general count
		$count = get_post_meta( $post_id, $this->post_view_counter_key, true );
		if ( '' === $count ) {
			update_post_meta( $post_id, $this->post_view_counter_key, 1 );
		} else {
			$count++;
			update_post_meta( $post_id, $this->post_view_counter_key, $count );
		}

		if ( is_user_logged_in() ) {
			$user = get_current_user_id();

			// used for user read count
			$user_count = get_user_meta( $user, $this->user_view_counter_key, true );
			if ( ! $user_count ) {
				add_user_meta( $user, $this->user_view_counter_key, 1 );
			} else {
				$user_count++;
				update_user_meta( $user, $this->user_view_counter_key, $user_count );
			}
		}

		//stop here if
		if ( ! $this->is_weekly_views_enabled() ) {
			return $count;
		}

		//used for 7 day count array
		$current_day       = date( 'N' ) - 1;  //get the current day
		$current_date      = date( 'U' ); //get the current Unix date
		$count_7_day_array = get_post_meta( $post_id, $this->post_view_counter_7_day_array, true );  // get the array with day of week -> count

		//check if the first entry is an array (used to detect and reset the older themes array)
		if ( is_array( $count_7_day_array ) && is_array( $count_7_day_array[0] ) ) {
			if ( isset( $count_7_day_array[ $current_day ] ) ) { // check to see if the current day is defined - if it's not defined it's not ok.
				//check if the current day matches the 'date' key inside the count_7_day array
				$current_day_of_the_year = date( 'z', $current_date );
				$count_7_day_of_the_year = date( 'z', $count_7_day_array[ $current_day ]['date'] );
				if ( get_post_meta( $post_id, $this->post_view_7days_last_day, true ) == $current_day && $count_7_day_of_the_year == $current_day_of_the_year ) {
					//the day was not changed since the last update - increment the count
					$count_7_day_array[ $current_day ]['count']++;
				} else {
					//the day was changed since the last update - reset the current day
					$count_7_day_array[ $current_day ]['count'] = 1;
					//set the current date
					$count_7_day_array[ $current_day ]['date'] = $current_date;

					//reset old entries inside the 7 days array (older than 7 days)
					$one_week_ago = $current_date - 604800;
					foreach ( $count_7_day_array as $day => $parameters ) {
						if ( $parameters['date'] < $one_week_ago ) {
							$count_7_day_array[ $day ] = array(
								'date'  => 0,
								'count' => 0,
							);
						}
					}

					//update last day with the current day
					update_post_meta( $post_id, $this->post_view_7days_last_day, $current_day );

					//update last date with the current date - it only updates once when the day changes
					update_post_meta( $post_id, $this->post_view_counter_7_day_last_date, $current_date );
				}

				//update the array
				update_post_meta( $post_id, $this->post_view_counter_7_day_array, $count_7_day_array );

				//sum the 7days total count
				$sum_7_day_count = 0;
				foreach ( $count_7_day_array as $day => $parameters ) {
					$sum_7_day_count += $parameters['count'];
				}
				update_post_meta( $post_id, $this->post_view_counter_7_day_total, $sum_7_day_count );
			}
		} else {
			//the array is not initialized
			$count_7_day_array = array(
				0 => array(
					'date'  => 0,
					'count' => 0,
				),
				1 => array(
					'date'  => 0,
					'count' => 0,
				),
				2 => array(
					'date'  => 0,
					'count' => 0,
				),
				3 => array(
					'date'  => 0,
					'count' => 0,
				),
				4 => array(
					'date'  => 0,
					'count' => 0,
				),
				5 => array(
					'date'  => 0,
					'count' => 0,
				),
				6 => array(
					'date'  => 0,
					'count' => 0,
				),
			);

			$count_7_day_array[ $current_day ]['count'] = 1; // add one view on the current day
			$count_7_day_array[ $current_day ]['date']  = $current_date; //set the current date

			//update the array
			update_post_meta( $post_id, $this->post_view_counter_7_day_array, $count_7_day_array );

			//update last day with the current day
			update_post_meta( $post_id, $this->post_view_7days_last_day, $current_day );

			//update last date with the current date
			update_post_meta( $post_id, $this->post_view_counter_7_day_last_date, $current_date );

			//update the 7 days total - 1 view :)
			update_post_meta( $post_id, $this->post_view_counter_7_day_total, 1 );
		}

		return $count;
	}

	public function get_page_views( $post_id, $force_update = false ) {
		if ( $force_update ) {
			$count = $this->update_page_views( $post_id );
		} else {
			$count = get_post_meta( $post_id, $this->post_view_counter_key, true );
		}

		if ( ! $count ) {
			$count = 0;
		}

		return apply_filters( 'newsy_get_post_view_count', $count, $post_id );
	}

	public function on_manage_posts_columns_views( $columns ) {
		$columns['newsy_post_views'] = 'Views';
		return $columns;
	}

	public  function on_manage_posts_custom_column( $column_name, $post_id ) {
		if ( 'newsy_post_views' == $column_name ) {
			echo $this->get_page_views( $post_id );
		}
	}

	/**
	 * Register the Newsy view counter post query args to framework.
	 *
	 * @return array
	 */
	public function register_post_query_args( $args, $atts ) {

		// orderby
		if ( ! empty( $atts['order_by'] ) ) {
			switch ( $atts['order_by'] ) {
				case 'popular':
					$args['orderby']  = 'meta_value_num';
					$args['meta_key'] = $this->post_view_counter_key;
					$args['order']    = 'DESC';
					break;
				case 'popular_week':
					$args['orderby']  = 'meta_value_num';
					$args['meta_key'] = $this->post_view_counter_7_day_total;
					$args['order']    = 'DESC';
					break;
			}
		}

		return $args;
	}

	/**
	 * Register the Newsy view counter post query args to framework.
	 *
	 * @return array
	 */
	public function register_order_by_options( $options ) {
		$options['popular'] = __( 'Popular', 'newsy-view-counter' );

		if ( $this->is_weekly_views_enabled() ) {
			$options['popular_week'] = __( 'Weekly Popular ', 'newsy-view-counter' );
		}

		return $options;
	}

	/**
	 * Filter check if weekly views enabled
	 *
	 * @return boolean
	 */
	public function is_weekly_views_enabled() {
		return apply_filters( 'newsy_view_enable_weekly_views', true );
	}

	/**
	 * Used for accessing plugin directory URL
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_url( $address = '' ) {
		return NEWSY_VIEW_COUNTER_URI . $address;
	}

	/**
	 * Used for accessing plugin directory path
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_path( $address = '' ) {
		return NEWSY_VIEW_COUNTER_PATH . $address;
	}

	/**
	 * Returns plugin current Version
	 *
	 * @return string
	 */
	public function get_version() {
		return $this->version;
	}
}
