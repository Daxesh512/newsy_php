<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BuzzEditor Block
 */
class BuzzEditor_Block {
	private static $instance;

	public $supported_blocks = array(
		'beforeafter',
		'checklist',
		'convo',
		'flipcard',
		'list',
		'personality',
		'poll',
		'trivia',
		'versus',
		'text',
	);

	/**
	 * @return BuzzEditor_Block
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	private function __construct() {
		if ( function_exists( 'register_block_type' ) ) {
			$this->setup_hook();
		}
	}

	protected function setup_hook() {
		add_action( 'init', array( $this, 'register_blocks' ) );
		add_action( 'enqueue_block_assets', array( $this, 'register_block_assets' ) );
		add_action( 'enqueue_block_editor_assets', array( $this, 'register_block_editor_assets' ) );

		add_filter( 'block_categories_all', array( $this, 'register_block_categories' ) );

		add_filter( 'the_content', array( $this, 'add_amp_post_content_redirect_attr' ), 99 );
	}

	/**
	 * Register blocks on server-side.
	 */
	public function register_blocks() {
		foreach ( $this->supported_blocks as $block ) {
			// register only for options purpose
			register_block_type(
				'buzzeditor/' . $block, array(
					'title' => sprintf( __( 'BuzzEditor: %s', 'buzzeditor' ), ucfirst( $block ) ),
				)
			);
		}
	}

	/**
	 * Enqueue Gutenberg block assets for frontend.
	 *
	 * @since 1.0.0
	 */
	public function register_block_assets() {
		// Register block styles for both frontend + backend.
		wp_enqueue_style( 'buzzeditor-block-style', BUZZEDITOR_URL . '/css/blocks.style.build.css', array(), BUZZEDITOR_VERSION );
		wp_style_add_data( 'buzzeditor-block-style', 'rtl', 'replace' );

		wp_enqueue_script( 'buzzeditor-front-block-js', BUZZEDITOR_URL . '/js/plugin.js', array(), BUZZEDITOR_VERSION, true );
		wp_localize_script(
			'buzzeditor-front-block-js', 'buzzeditor_block_loc', array(
				'replay_quiz'        => ak_get_translation( 'Replay Quiz', 'buzzeditor', 'replay_quiz' ),
				'share_your_result'  => ak_get_translation( 'Share Your Quiz', 'buzzeditor', 'share_your_result' ),
				'share_your_vote'    => ak_get_translation( 'Share Your Vote:', 'buzzeditor', 'share_your_vote' ),
				'i_got'              => ak_get_translation( 'I got: "%1$s" | %2$s', 'buzzeditor', 'i_got' ),
				'i_vote_for'         => ak_get_translation( 'I vote for: "%1$s" | %2$s', 'buzzeditor', 'i_vote_for' ),
				'show_my_results'    => ak_get_translation( 'Show me my results!', 'buzzeditor', 'show_my_results' ),
				'click_to_flip'      => ak_get_translation( 'Click to Flip', 'buzzeditor', 'click_to_flip' ),
				'correct'            => ak_get_translation( 'Correct!', 'buzzeditor', 'correct' ),
				'wrong'              => ak_get_translation( 'Wrong!', 'buzzeditor', 'wrong' ),
				'login_to_vote'      => ak_get_translation( 'You must login to vote!', 'buzzeditor', 'login_to_vote' ),
				'login_to_take_quiz' => ak_get_translation( 'You must login to take this quiz!', 'buzzeditor', 'login_to_take_quiz' ),
			)
		);
	}

	/**
	 * Enqueue Gutenberg block assets for backend.
	 *
	 * @since 1.0.0
	 */
	public function register_block_editor_assets() {
		// Register block editor styles for backend.
		wp_enqueue_style( 'buzzeditor-editor-block-style', BUZZEDITOR_URL . '/css/blocks.editor.build.css', array( 'wp-edit-blocks' ), BUZZEDITOR_VERSION );
		wp_style_add_data( 'buzzeditor-editor-block-style', 'rtl', 'replace' );

		// Register block editor script for backend.
		wp_enqueue_script(
			'buzzeditor-block-js', BUZZEDITOR_URL . '/js/blocks.build.js', array(
				'wp-blocks',
				'wp-element',
				'wp-components',
				'wp-editor',
				'wp-i18n',
			), BUZZEDITOR_VERSION
		);
		wp_localize_script(
			'buzzeditor-block-js', 'buzzeditor_block_loc', array(
				'quiz'                         => ak_get_translation( 'Quiz', 'buzzeditor', 'quiz' ),
				'quiz_questions'               => ak_get_translation( 'Questions', 'buzzeditor', 'quiz_questions' ),
				'quiz_question'                => ak_get_translation( 'Question', 'buzzeditor', 'quiz_question' ),
				'quiz_results'                 => ak_get_translation( 'Results', 'buzzeditor', 'quiz_results' ),
				'quiz_result'                  => ak_get_translation( 'Result', 'buzzeditor', 'quiz_result' ),
				'quiz_answers'                 => ak_get_translation( 'Answers', 'buzzeditor', 'quiz_answers' ),
				'quiz_answer'                  => ak_get_translation( 'Answer', 'buzzeditor', 'quiz_answer' ),
				'quiz_answer_layout_style'     => ak_get_translation( 'Answer Layout Style', 'buzzeditor', 'quiz_answer_layout_style' ),
				'quiz_answer_text_list'        => ak_get_translation( 'Text List', 'buzzeditor', 'quiz_answer_text_list' ),
				'quiz_answer_1_col'            => ak_get_translation( '1 Column', 'buzzeditor', 'quiz_answer_1_col' ),
				'quiz_answer_2_cols'           => ak_get_translation( '2 Columns', 'buzzeditor', 'quiz_answer_2_cols' ),
				'quiz_answer_3_cols'           => ak_get_translation( '3 Columns', 'buzzeditor', 'quiz_answer_3_cols' ),
				'quiz_enter_question'          => ak_get_translation( 'Enter Question', 'buzzeditor', 'quiz_enter_question' ),
				'quiz_add_answer'              => ak_get_translation( 'Add Answer...', 'buzzeditor', 'quiz_add_answer' ),
				'trivia_quiz'                  => ak_get_translation( 'Trivia Quiz', 'buzzeditor', 'trivia_quiz' ),
				'trivia_quiz_description'      => ak_get_translation( 'Create "What do you know about ...?" type of quizzes', 'trivia_quiz_description', 'editor_description' ),
				'show_correct_wrong'           => ak_get_translation( 'Show correct/wrong feedback?', 'buzzeditor', 'show_correct_wrong' ),
				'trivia_correct'               => ak_get_translation( 'Correct?', 'buzzeditor', 'trivia_correct' ),
				'trivia_reveal'                => ak_get_translation( 'Reveal', 'buzzeditor', 'trivia_reveal' ),
				'trivia_reveal_heading'        => ak_get_translation( 'Reveal Heading', 'buzzeditor', 'trivia_reveal_heading' ),
				'trivia_reveal_description'    => ak_get_translation( 'Reveal Description', 'buzzeditor', 'trivia_reveal_description' ),
				'personality_quiz'             => ak_get_translation( 'Personality Quiz', 'buzzeditor', 'personality_quiz' ),
				'personality_quiz_description' => ak_get_translation( 'Create "What type of person are you?', 'buzzeditor', 'personality_quiz_description' ),
				'assing_a_result'              => ak_get_translation( 'Assign a Result', 'buzzeditor', 'assing_a_result' ),
				'checklist_quiz'               => ak_get_translation( 'Checklist Quiz', 'buzzeditor', 'checklist_quiz' ),
				'quiz_default_result'          => ak_get_translation( 'Default Result', 'buzzeditor', 'quiz_default_result' ),
				'quiz_custom_result'           => ak_get_translation( 'Custom Result', 'buzzeditor', 'quiz_custom_result' ),
				'quiz_result_text'             => ak_get_translation( 'Result Text:', 'buzzeditor', 'quiz_result_text' ),
				'quiz_share_text'              => ak_get_translation( 'Share Text:', 'buzzeditor', 'quiz_share_text' ),
				'checklist_you_got'            => ak_get_translation( 'You %1$s <b>#</b> out of <span>#</span> %2$s', 'buzzeditor', 'checklist_you_got' ),
				'checklist_i_got'              => ak_get_translation( 'I %1$s <b>#</b> out of <span>#</span> %2$s', 'buzzeditor', 'checklist_i_got' ),
				'poll'                         => ak_get_translation( 'Poll', 'buzzeditor', 'poll' ),
				'polls'                        => ak_get_translation( 'Polls', 'buzzeditor', 'polls' ),
				'poll_description'             => ak_get_translation( 'Create your own poll never easy like this.', 'buzzeditor', 'poll_description' ),
				'poll_enter_question'          => ak_get_translation( 'Enter Poll Question', 'buzzeditor', 'poll_enter_question' ),
				'poll_id'                      => ak_get_translation( 'Poll ID', 'buzzeditor', 'poll_id' ),
				'poll_answers'                 => ak_get_translation( 'Poll Answers', 'buzzeditor', 'poll_answers' ),
				'poll_add_answer'              => ak_get_translation( 'Add Answer...', 'buzzeditor', 'poll_add_answer' ),
				'poll_answer'                  => ak_get_translation( 'Poll Answer', 'buzzeditor', 'poll_answer' ),
				'poll_type_answer'             => ak_get_translation( 'Type an answer...', 'buzzeditor', 'poll_type_answer' ),
				'poll_type_media_credit'       => ak_get_translation( 'Type media credit...', 'buzzeditor', 'poll_type_media_credit' ),
				'versus'                       => ak_get_translation( 'Versus', 'buzzeditor', 'versus' ),
				'convo'                        => ak_get_translation( 'Convo', 'buzzeditor', 'convo' ),
				'convo_item'                   => ak_get_translation( 'Convo Item', 'buzzeditor', 'convo_item' ),
				'convo_description'            => ak_get_translation( 'Create a dialogue that fits today’s communication habits.', 'buzzeditor', 'convo_description' ),
				'add_participant'              => ak_get_translation( 'Add Participant...', 'buzzeditor', 'add_participant' ),
				'enter_participant'            => ak_get_translation( 'Enter Participant name...', 'buzzeditor', 'enter_participant' ),
				'convo_view_style'             => ak_get_translation( 'View Style', 'buzzeditor', 'convo_view_style' ),
				'convo_colored'                => ak_get_translation( 'Colored', 'buzzeditor', 'convo_colored' ),
				'convo_grey'                   => ak_get_translation( 'Grey', 'buzzeditor', 'convo_grey' ),
				'convo_dark'                   => ak_get_translation( 'Dark', 'buzzeditor', 'convo_dark' ),
				'beforeafter'                  => ak_get_translation( 'BeforeAfter', 'buzzeditor', 'beforeafter' ),
				'beforeafter_description'      => ak_get_translation( 'Create the perfect “before and after” experience.', 'buzzeditor', 'beforeafter_description' ),
				'before'                       => ak_get_translation( 'Before', 'buzzeditor', 'before' ),
				'after'                        => ak_get_translation( 'After', 'buzzeditor', 'after' ),
				'leave_empty_label'            => ak_get_translation( 'Leave empty for no label', 'buzzeditor', 'leave_empty_label' ),
				'orientation'                  => ak_get_translation( 'Orientation', 'buzzeditor', 'orientation' ),
				'horizontal'                   => ak_get_translation( 'Horizontal', 'buzzeditor', 'horizontal' ),
				'vertical'                     => ak_get_translation( 'Vertical', 'buzzeditor', 'vertical' ),
				'drag_position'                => ak_get_translation( 'Drag Handler Position', 'buzzeditor', 'drag_position' ),
				'drag_begin'                   => ak_get_translation( 'Begin', 'buzzeditor', 'drag_begin' ),
				'drag_center'                  => ak_get_translation( 'Center', 'buzzeditor', 'drag_center' ),
				'drag_end'                     => ak_get_translation( 'End', 'buzzeditor', 'drag_end' ),
				'flipcard'                     => ak_get_translation( 'FlipCard', 'buzzeditor', 'flipcard' ),
				'flipcard_description'         => ak_get_translation( 'Create the perfect “before and after” experience.', 'buzzeditor', 'flipcard_description' ),
				'flipcard_front'               => ak_get_translation( 'Front', 'buzzeditor', 'flipcard_front' ),
				'flipcard_back'                => ak_get_translation( 'Back', 'buzzeditor', 'flipcard_back' ),
				'text'                         => ak_get_translation( 'Text', 'buzzeditor', 'text' ),
				'enter_heading'                => ak_get_translation( 'Enter Heading', 'buzzeditor', 'enter_heading' ),
				'write_text'                   => ak_get_translation( 'Write text…', 'buzzeditor', 'write_text' ),
				'guest_can_vote'               => ak_get_translation( 'Guest Can Vote?', 'buzzeditor', 'guest_can_vote' ),
				'settings'                     => ak_get_translation( 'Settings', 'buzzeditor', 'settings' ),
				'are_you_sure'                 => ak_get_translation( 'Are you Sure?', 'buzzeditor', 'are_you_sure' ),
				'tell_them_a_bit_more'         => ak_get_translation( 'Tell them a bit more...', 'buzzeditor', 'tell_them_a_bit_more' ),
			)
		);
	}

	public function register_block_categories( $categories ) {
		return array_merge(
			array(
				array(
					'slug'  => 'quiz',
					'title' => ak_get_translation( 'Quizzes', 'buzzeditor', 'quizzes' ),
					'icon'  => null,
				),
			),
			$categories
		);

		return $categories;
	}

	public function add_amp_post_content_redirect_attr( $content ) {
		if ( function_exists( 'amp_is_request' ) ) {
			if ( amp_is_request() ) {
				$post_link = esc_url( get_permalink() );

				$dom = new DOMDocument;
				@$dom->loadHTML( mb_convert_encoding( $content, 'HTML-ENTITIES', 'UTF-8' ) );
				if ( $dom ) {
					$xpath = new DomXPath( $dom );
					$nodes = $xpath->query( "//*[contains(@class, 'be-answer') or contains(@class, 'be-flipcard')]" );
					if ( ! empty( $nodes ) ) {
						foreach ( $nodes as $node ) {
							$node->setAttribute( 'on', "tap:AMP.navigateTo(url='{$post_link}')" );
						}
						return $dom->saveHTML();
					}
				}
			}
		}

		return $content;
	}
}
