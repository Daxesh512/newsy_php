<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BuzzEditor Template
 */
class BuzzEditor_Template {

	private static $instance;

	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	private function __construct() {
		$this->setup_hook();
	}

	protected function setup_hook() {
		add_action( 'template_include', array( $this, 'add_page_template' ) );

		// only for users
		if ( ! current_user_can( 'manage_options' ) ) {
			add_action( 'delete_attachment', array( $this, 'disable_delete_attachment' ) );
			add_filter( 'ajax_query_attachments_args', array( $this, 'filter_user_media' ) );
			add_filter( 'media_view_strings', array( $this, 'remove_media_tab' ) );
			add_filter( 'upload_size_limit', array( $this, 'upload_size_limit' ) );
			add_filter( 'user_has_cap', array( $this, 'user_has_cap' ), 10, 3 );
			add_filter( 'allowed_block_types_all', array( $this, 'allowed_block_types' ), 9999, 2 );
			add_action( 'after_setup_theme', array( $this, 'remove_admin_bar' ), 9999 );
		}
	}

	public function add_page_template( $template ) {
		if ( ! $this->endpoint_check() ) {
			return $template;
		}

		$current_type = filter_input( INPUT_GET, 'type', FILTER_SANITIZE_STRING );
		$post         = filter_input( INPUT_GET, 'post', FILTER_SANITIZE_NUMBER_INT );

		if ( empty( $current_type ) && empty( $post ) ) {
			$file = BUZZEDITOR_PATH . 'template/page-start.php';
		} else {
			if ( $this->user_check_access() ) {
				add_filter( 'newsy_show_footer', '__return_false' );
				add_filter( 'body_class', array( $this, 'add_body_class' ), 9999 );

				$file = BUZZEDITOR_PATH . 'template/page-create.php';
			}
		}

		if ( ! empty( $file ) && file_exists( $file ) ) {
			$template = $file;
		}

		return $template;
	}

	public function add_body_class( $classes ) {
		$classes[] = buzzeditor_get_option( 'create_page_layout_style', 'content-boxed' );

		// Default to is-fullscreen-mode to avoid jumps in the UI.
		$classes[] = 'block-editor-page';

		if ( current_theme_supports( 'editor-styles' ) && current_theme_supports( 'dark-editor-style' ) ) {
			$classes[] = 'is-dark-theme';
		}

		return $classes;
	}

	public function endpoint_check() {
		global $wp;
		$endpoint = buzzeditor_get_editor_endpoint();

		if ( isset( $wp->query_vars[ $endpoint ] ) ) {
			return true;
		}

		return false;
	}
	public function user_check_access() {
		if ( ! function_exists( 'register_block_type' ) ) {
			// @TODO show that gutenberg disabled
			return false;
		}

		// check user is login
		if ( ! is_user_logged_in() ) {
			wp_redirect( wp_login_url( get_permalink() ) );
			exit;
		}

		// Check if the role to create.
		if ( ! $this->is_user_allow_access() ) {
			wp_redirect( home_url( '/404' ) );
			exit;
		}

		global $post;

		if ( ! function_exists( 'use_block_editor_for_post' ) || ! function_exists( 'get_default_post_to_edit' ) ) {
			require_once ABSPATH . 'wp-admin/includes/post.php';
		}

		if ( isset( $_GET['post'] ) ) {
			// show post if post_status's publish, pending or draft
			$post_status = array( 'publish', 'pending', 'draft' );
			$post        = get_post( absint( $_GET['post'] ) );
		} else {
			$user_id     = get_current_user_id();
			$post_status = array( 'draft', 'auto-draft' );

			$draft_post = get_posts(
				array(
					'numberposts' => 1,
					'post_type'   => 'post',
					'author'      => $user_id,
					'post_status' => $post_status,
					'meta_query'  => buzzeditor_is_classic() ? array(
						array(
							'key'     => BuzzEditor_Editor::get_instance()->format_meta_key,
							'value'   => filter_input( INPUT_GET, 'type', FILTER_SANITIZE_STRING ),
							'compare' => '=',
						),
					) : array(),
				)
			);

			// check for any draft post then continue
			if ( ! empty( $draft_post ) ) {
				$post = current( $draft_post );
			} else {
				$post = get_default_post_to_edit( 'post', true );
			}
		}

		// fix - gutenberg default title
		if ( __( 'Auto Draft' ) === $post->post_title ) {
			$post->post_title = '';
		}

		if (
			$post
			&& in_array( $post->post_status, $post_status, true )
			&& use_block_editor_for_post_type( $post->post_type )
			&& use_block_editor_for_post( $post )
		) {
			return true;
		}

		wp_redirect( home_url( '/404' ) );
		exit;
	}

	public function is_user_allow_access() {
		$roles = buzzeditor_get_option( 'accepted_user_roles', 'administrator,editor,author,contributor,subscriber' );
		$roles = explode( ',', $roles );

		$current_user_roles = wp_get_current_user()->roles;
		foreach ( $roles as $stack ) {
			if ( in_array( $stack, $current_user_roles ) ) {
				return true;
			}
		}
		return false;
	}

	public function user_has_cap( $caps, $cap, $args ) {
		// otherwise cause memory leak??
		if ( ! isset( $caps['edit_post'] ) ) {
			$edit_post = buzzeditor_get_option( 'user_can_edit_posts', 'yes' ) !== 'no';

			$caps['edit_post']       = $edit_post; // user can edit own draft or pending posts
			$caps['read_categories'] = $edit_post; // user can edit own draft or pending posts
			$caps['edit_posts']      = $edit_post; // user can see lists of own draft or pending posts
			$caps['delete_posts']    = buzzeditor_get_option( 'user_can_delete_posts', 'yes' ) !== 'no'; //  user can delete own draft or pending posts
			$caps['upload_files']    = $edit_post; // user can upload files

			$caps['publish_posts']          = buzzeditor_get_option( 'user_can_publish_posts', 'no' ) !== 'no'; // user can publish
			$caps['edit_published_posts']   = buzzeditor_get_option( 'user_can_edit_published_posts', 'no' ) !== 'no'; //  user can't edit published posts
			$caps['delete_published_posts'] = buzzeditor_get_option( 'user_can_delete_published_posts', 'no' ) !== 'no'; //  user can't delete published posts
		}

		return $caps;
	}

	/**
	 * Disable media library delete access
	 *
	 * @param array $query
	 * @return void
	 */
	public function disable_delete_attachment() {
		exit();
	}

	/**
	 * Limit media library access
	 *
	 * @param array $query
	 * @return void
	 */
	public function filter_user_media( $query ) {
		$user_id = get_current_user_id();
		if ( $user_id && ! current_user_can( 'edit_others_posts' ) ) {
			$query['author'] = $user_id;
		}

		return $query;
	}

	public function remove_media_tab( $strings ) {
		$strings['setFeaturedImageTitle']    = '';
		$strings['insertFromUrlTitle']       = '';
		$strings['createPlaylistTitle']      = '';
		$strings['createVideoPlaylistTitle'] = '';
		$strings['deletePermanently']        = '';
		$strings['deleteSelected']           = '';

		return $strings;
	}

	public function upload_size_limit( $size ) {
		// 5 MB.
		$user_size = buzzeditor_get_option( 'user_max_upload_file_size', 5 );
		$size      = absint( $user_size ) * 1024 * 1024;

		return $size;
	}

	public function allowed_block_types( $allowed_block_types ) {
		$user_blocks = buzzeditor_get_option( 'user_enabled_blocks', true );

		if ( true === $user_blocks ) {
			return $allowed_block_types;
		}

		if ( is_string( $user_blocks ) ) {
			$allowed_block_types = explode( ',', $user_blocks );
		}

		return $allowed_block_types;
	}

	function remove_admin_bar() {
		if ( 'hide' === buzzeditor_get_option( 'hide_admin_bar', 'hide' ) ) {
			add_filter( 'show_admin_bar', '__return_false' );
		}
	}
}
