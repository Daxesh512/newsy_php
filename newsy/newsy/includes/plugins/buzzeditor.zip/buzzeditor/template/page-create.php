<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

defined( 'BUZZEDITOR_FRONTEND_PAGE' ) or define( 'BUZZEDITOR_FRONTEND_PAGE', true );

if ( ! function_exists( 'get_current_screen' ) ) {
	function get_current_screen() {
		return null;
	}
}

/**
 * @global string       $post_type
 * @global WP_Post_Type $post_type_object
 * @global WP_Post      $post             Global post object.
 * @global string       $title
 */
global $post_type, $post_type_object, $post, $title;

$block_editor_context = new WP_Block_Editor_Context( array( 'post' => $post ) );

wp_enqueue_script( 'heartbeat' );
wp_enqueue_script( 'wp-edit-post' );
wp_enqueue_script( 'wp-format-library' );
wp_enqueue_script( 'postbox', admin_url( 'js/postbox.min.js' ), array( 'jquery-ui-sortable' ), false, 1 );

wp_add_inline_script(
	'wp-blocks',
	sprintf( 'wp.blocks.setCategories( %s );', wp_json_encode( get_block_categories( $post ) ) ),
	'after'
);

/*
 * Assign initial edits, if applicable. These are not initially assigned to the persisted post,
 * but should be included in its save payload.
 */
$initial_edits = null;
$is_new_post   = false;
if ( 'auto-draft' === $post->post_status ) {
	$is_new_post = true;
	// Override "(Auto Draft)" new post default title with empty string, or filtered value.
	$initial_edits = array(
		'title'   => $post->post_title,
		'content' => $post->post_content,
		'excerpt' => $post->post_excerpt,
	);
}

// Preload server-registered block schemas.
wp_add_inline_script(
	'wp-blocks',
	'wp.blocks.unstable__bootstrapServerSideBlockDefinitions(' . wp_json_encode( get_block_editor_server_block_settings() ) . ');'
);

/*
 * Initialize the editor.
 */

$align_wide         = get_theme_support( 'align-wide' );
$color_palette      = current( (array) get_theme_support( 'editor-color-palette' ) );
$font_sizes         = current( (array) get_theme_support( 'editor-font-sizes' ) );
$gradient_presets   = current( (array) get_theme_support( 'editor-gradient-presets' ) );
$custom_line_height = get_theme_support( 'custom-line-height' );
$custom_units       = get_theme_support( 'custom-units' );

/**
 * Filters the allowed block types for the editor, defaulting to true (all
 * block types supported).
 *
 * @since 5.0.0
 *
 * @param bool|array $allowed_block_types Array of block type slugs, or
 *                                        boolean to enable/disable all.
 * @param WP_Post    $post                The post resource data.
 */
$allowed_block_types = apply_filters( 'allowed_block_types_all', true, $post );

// Media settings.
$max_upload_size = wp_max_upload_size();
if ( ! $max_upload_size ) {
	$max_upload_size = 0;
}


// Image sizes.

/** This filter is documented in wp-admin/includes/media.php */
$image_size_names = apply_filters(
	'image_size_names_choose',
	array(
		'thumbnail' => esc_html__( 'Thumbnail' ),
		'medium'    => esc_html__( 'Medium' ),
		'large'     => esc_html__( 'Large' ),
		'full'      => esc_html__( 'Full Size' ),
	)
);

$available_image_sizes = array();
foreach ( $image_size_names as $image_size_slug => $image_size_name ) {
	$available_image_sizes[] = array(
		'slug' => $image_size_slug,
		'name' => $image_size_name,
	);
}

$image_dimensions = array();
$all_sizes        = wp_get_registered_image_subsizes();
foreach ( $available_image_sizes as $size ) {
	$key = $size['slug'];
	if ( isset( $all_sizes[ $key ] ) ) {
		$image_dimensions[ $key ] = $all_sizes[ $key ];
	}
}

// Lock settings.
$user_id = wp_check_post_lock( $post->ID );
if ( $user_id ) {
	$locked = false;

	/** This filter is documented in wp-admin/includes/post.php */
	if ( apply_filters( 'show_post_locked_dialog', true, $post, $user_id ) ) {
		$locked = true;
	}

	$user_details = null;
	if ( $locked ) {
		$user         = get_userdata( $user_id );
		$user_details = array(
			'name' => $user->display_name,
		);
		$avatar       = get_avatar_url( $user_id, array( 'size' => 64 ) );
	}

	$lock_details = array(
		'isLocked' => $locked,
		'user'     => $user_details,
	);
} else {
	// Lock the post.
	$active_post_lock = wp_set_post_lock( $post->ID );
	if ( $active_post_lock ) {
		$active_post_lock = esc_attr( implode( ':', $active_post_lock ) );
	}

	$lock_details = array(
		'isLocked'       => false,
		'activePostLock' => $active_post_lock,
	);
}

$editor_settings = array(
	'alignWide'              => $align_wide,
	'allowedBlockTypes'      => $allowed_block_types,
	'disableCustomColors'    => get_theme_support( 'disable-custom-colors' ),
	'disableCustomFontSizes' => get_theme_support( 'disable-custom-font-sizes' ),
	'disableCustomGradients' => get_theme_support( 'disable-custom-gradients' ),
	'disablePostFormats'     => true,
	/** This filter is documented in wp-admin/edit-form-advanced.php */
	'isRTL'                  => is_rtl(),
	'autosaveInterval'       => buzzeditor_get_option( 'editor_autosave_interval', AUTOSAVE_INTERVAL ),
	'maxUploadFileSize'      => $max_upload_size,
	'allowedMimeTypes'       => get_allowed_mime_types(),
	'imageSizes'             => $available_image_sizes,
	'imageDimensions'        => $image_dimensions,
	'richEditingEnabled'     => user_can_richedit(),
	'postLock'               => $lock_details,
	'postLockUtils'          => array(
		'nonce'       => wp_create_nonce( 'lock-post_' . $post->ID ),
		'unlockNonce' => wp_create_nonce( 'update-post_' . $post->ID ),
		'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
	),

	// Whether or not to load the 'postcustom' meta box is stored as a user meta
	// field so that we're not always loading its assets.
	'enableCustomLineHeight' => $custom_line_height,
	'enableCustomUnits'      => $custom_units,
);

$autosave = wp_get_post_autosave( $post->ID );
if ( $autosave ) {
	if ( mysql2date( 'U', $autosave->post_modified_gmt, false ) > mysql2date( 'U', $post->post_modified_gmt, false ) ) {
		$editor_settings['autosave'] = array(
			'editLink' => get_edit_post_link( $autosave->ID ),
		);
	} else {
		wp_delete_post_revision( $autosave->ID );
	}
}

if ( false !== $color_palette ) {
	$editor_settings['colors'] = $color_palette;
}

if ( false !== $font_sizes ) {
	$editor_settings['fontSizes'] = $font_sizes;
}

if ( false !== $gradient_presets ) {
	$editor_settings['gradients'] = $gradient_presets;
}


/**
 * Scripts
 */
wp_enqueue_media(
	array(
		'post' => $post->ID,
	)
);
wp_tinymce_inline_scripts();
wp_enqueue_editor();


/**
 * Styles
 */
wp_enqueue_style( 'wp-edit-post' );
wp_enqueue_style( 'wp-format-library' );


// since current_screen is admin area function this not working in frontend do it manually.
$block_registry = WP_Block_Type_Registry::get_instance();
foreach ( $block_registry->get_all_registered() as $block_name => $block_type ) {
	// Front-end styles.
	if ( ! empty( $block_type->style ) ) {
		wp_enqueue_style( $block_type->style );
	}

	// Front-end script.
	if ( ! empty( $block_type->script ) ) {
		wp_enqueue_script( $block_type->script );
	}

	// Editor styles.
	if ( ! empty( $block_type->editor_style ) ) {
		wp_enqueue_style( $block_type->editor_style );
	}

	// Editor script.
	if ( ! empty( $block_type->editor_script ) ) {
		wp_enqueue_script( $block_type->editor_script );
	}
}

/**
 * Fires after block assets have been enqueued for the editing interface.
 *
 * Call `add_action` on any hook before 'admin_enqueue_scripts'.
 *
 * In the function call you supply, simply use `wp_enqueue_script` and
 * `wp_enqueue_style` to add your functionality to the block editor.
 *
 * @since 5.0.0
 */
do_action( 'enqueue_block_editor_assets' );


/**
 * Fires after block assets have been enqueued for the editing interface.
 *
 * Call `add_action` on any hook before 'admin_enqueue_scripts'.
 *
 * In the function call you supply, simply use `wp_enqueue_script` and
 * `wp_enqueue_style` to add your functionality to the block editor.
 *
 * @since 5.0.0
 */
do_action( 'buzzeditor_frontend_enqueue_scripts' );


/**
 * Filters the settings to pass to the block editor.
 *
 * @since 5.0.0
 *
 * @param array   $editor_settings Default editor settings.
 * @param WP_Post $post            Post being edited.
 */
if ( function_exists( 'get_block_editor_settings' ) ) {
	$editor_settings = get_block_editor_settings( $editor_settings, $block_editor_context );
} else {
	$editor_settings = apply_filters( 'block_editor_settings_all', $editor_settings, $post );
}

$editor_settings = apply_filters( 'buzzeditor_editor_settings', $editor_settings, $post );

$init_script = <<<JS
( function() {
	window._wpLoadBlockEditor = new Promise( function( resolve ) {
		wp.domReady( function() {
			resolve( wp.editPost.initializeEditor( 'editor', "%s", %d, %s, %s ) );
		} );
	} );
} )();
JS;

$script = sprintf(
	$init_script,
	$post->post_type,
	$post->ID,
	wp_json_encode( $editor_settings ),
	wp_json_encode( $initial_edits )
);
wp_add_inline_script( 'wp-edit-post', $script );


// template
$template_id = 'create_page';

$classes = apply_filters(
	'newsy_content_wrap_class', array(
		'ak-' . $template_id . '-wrap',
		'ak-layout-' . buzzeditor_get_option( 'create_page_layout_style', 'content-boxed' ),
	), $template_id, $post->id
);

$editor_classes = apply_filters(
	'buzzeditor_wrap_class', array(
		'buzzeditor-frontend',
		'buzzeditor-' . buzzeditor_get_editor_style(),
		'block-editor',
		'gutenberg',
	), $template_id, $post->id
);
get_header();
?>
<div class="ak-content-wrap <?php echo esc_attr( implode( ' ', $classes ) ); ?>">
	<div class="ak-container">
		<div class="ak-content">
			<div class="<?php echo esc_attr( implode( ' ', $editor_classes ) ); ?>">
				<div id="editor" class="block-editor__container gutenberg__editor">
					<div class="ak-loading-circle"><div class="ak-loading-circle-inner"></div></div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
