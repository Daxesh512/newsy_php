<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BuzzEditor BuddyPress
 */
class BuzzEditor_Bp {
	private static $instance;

	/**
	 * @return BuzzEditor_Bp
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	private function __construct() {
		$this->setup_hook();
	}

	protected function setup_hook() {
		add_action( 'bp_setup_nav', array( $this, 'bp_add_nav' ), 20 );
	}

	/**
	 * Add playlist tab on nav BuddyPress
	 */
	public function bp_add_nav() {
		bp_core_new_nav_item(
			array(
				'name'                => ak_get_translation( 'Posts', 'buzzeditor', 'posts' ),
				'slug'                => 'posts',
				'position'            => 30,
				'screen_function'     => array( $this, 'bp_public_posts_page_screen_feedback' ),
				'default_subnav_slug' => 'published',
			)
		);

		$user_domain = bp_displayed_user_domain() ? bp_displayed_user_domain() : bp_loggedin_user_domain();

		$component_link = trailingslashit( $user_domain . 'posts' );

		bp_core_new_subnav_item(
			array(
				'name'            => ak_get_translation( 'Published', 'buzzeditor', 'published' ),
				'slug'            => 'published',
				'parent_url'      => $component_link,
				'parent_slug'     => 'posts',
				'screen_function' => array( $this, 'bp_public_posts_page_screen_feedback' ),
				'item_css_id'     => 'published-posts',
			)
		);

		if ( get_current_user_id() === bp_displayed_user_id() ) {
			bp_core_new_subnav_item(
				array(
					'name'            => ak_get_translation( 'Pendings', 'buzzeditor', 'pendings' ),
					'slug'            => 'pending',
					'parent_url'      => $component_link,
					'parent_slug'     => 'posts',
					'screen_function' => array( $this, 'bp_pending_posts_page_screen_feedback' ),
					'item_css_id'     => 'pending-posts',
				)
			);

			bp_core_new_subnav_item(
				array(
					'name'            => ak_get_translation( 'Drafts', 'buzzeditor', 'drafts' ),
					'slug'            => 'drafts',
					'parent_url'      => $component_link,
					'parent_slug'     => 'posts',
					'screen_function' => array( $this, 'bp_draft_posts_page_screen_feedback' ),
					'item_css_id'     => 'draft-posts',
				)
			);
		}

	}

	// show feedback when ‘Feedback’ tab is clicked
	public function bp_public_posts_page_screen_feedback() {
		add_action( 'bp_template_content', array( $this, 'bp_public_posts_page_screen_function' ) );
		bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
	}

	// show feedback when ‘Feedback’ tab is clicked
	public function bp_draft_posts_page_screen_feedback() {
		add_action( 'bp_template_content', array( $this, 'bp_draft_posts_page_screen_function' ) );
		bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
	}
	// show feedback when ‘Feedback’ tab is clicked
	public function bp_pending_posts_page_screen_feedback() {
		add_action( 'bp_template_content', array( $this, 'bp_pending_posts_page_screen_function' ) );
		bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
	}

	/**
	 * Set public playlist screen function
	 */
	public function bp_public_posts_page_screen_function() {
		ak_do_shortcode(
			'newsy_list_1_medium', array(
				'count'               => 10,
				'author'              => bp_displayed_user_id(),
				'pagination'          => 'next_prev',
				'block_width'         => 2,
				'block_extra_classes' => 'ak-block-module-boxed',
			)
		);
	}

	/**
	 * Set public playlist screen function
	 */
	public function bp_draft_posts_page_screen_function() {
		ak_do_shortcode(
			'newsy_list_1_medium', array(
				'count'               => 10,
				'author'              => bp_displayed_user_id(),
				'post_status'         => 'draft',
				'pagination'          => 'next_prev',
				'block_width'         => 2,
				'block_extra_classes' => 'ak-block-module-boxed',
			)
		);
	}

	/**
	 * Set public playlist screen function
	 */
	public function bp_pending_posts_page_screen_function() {
		ak_do_shortcode(
			'newsy_list_1_medium', array(
				'count'               => 10,
				'author'              => bp_displayed_user_id(),
				'post_status'         => 'pending',
				'pagination'          => 'next_prev',
				'block_width'         => 2,
				'block_extra_classes' => 'ak-block-module-boxed',
			)
		);
	}
}
