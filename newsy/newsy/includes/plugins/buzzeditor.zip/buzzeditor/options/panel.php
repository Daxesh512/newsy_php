<?php
function buzzeditor_get_block_names() {
	if ( ! class_exists( 'WP_Block_Type_Registry' ) ) {
		return array();
	}
	$block_registry = WP_Block_Type_Registry::get_instance();

	$blocks = array();
	foreach ( $block_registry->get_all_registered() as $block_name => $block_type ) {
		if ( ! isset( $blocks[ $block_name ] ) ) {
			$blocks[ $block_name ] = ! empty( $block_type->title ) ? $block_type->title : $block_name;
		}
	}

	return array_reverse( $blocks );
}

/**
 * General Settings Tab
 */
$fields[] = array(
	'id'      => 'general',
	'type'    => 'section',
	'heading' => esc_html__( 'Frontend Editor', 'buzzeditor' ),
);
$fields[] = array(
	'id'          => 'enable_frontend',
	'type'        => 'switcher',
	'heading'     => esc_html__( 'Enable Frontend Editor', 'buzzeditor' ),
	'description' => esc_html__( 'Here you can enabled/disable frontend editor. BuzzEditor blocks will always available for backend.', 'buzzeditor' ),
	'options'     => array(
		'off' => 'no',
		'on'  => '',
	),
	'section'     => 'general',
);

$fields[] = array(
	'id'          => 'frontend_style',
	'type'        => 'visual_select',
	'heading'     => esc_html__( 'Frontend Editor Style', 'buzzeditor' ),
	'description' => esc_html__( 'Here you can choose frontend editor style. Advanced: More options and complex design. Classic: Less options and simple design.', 'buzzeditor' ),
	'options'     => array(
		'classic'  => __( 'Classic', 'buzzeditor' ),
		'advanced' => __( 'Advanced', 'buzzeditor' ),
	),
	'default'     => 'classic',
	'section'     => 'general',
	'dependency'  => array(
		'element' => 'enable_frontend',
		'value'   => array( '' ),
	),
);

$fields[] = array(
	'id'                 => 'frontend_classic_types',
	'type'               => 'repeater',
	'heading'            => esc_html__( 'Frontend Editor Post Formats', 'buzzeditor' ),
	'repeat_heading'     => esc_html__( 'Post Format', 'buzzeditor' ),
	'repeat_title_field' => 'name',
	'description'        => esc_html__( 'Here you can choose classic frontend editor post formats. Each type has starter blocks and accepted blocks and you can enable for editor, start page and dropdown.', 'buzzeditor' ),
	'fields'             => array(
		array(
			'id'      => 'type',
			'type'    => 'text',
			'heading' => esc_html__( 'Type', 'buzzeditor' ),
		),
		array(
			'id'      => 'name',
			'type'    => 'text',
			'heading' => esc_html__( 'Name', 'buzzeditor' ),
		),
		array(
			'id'      => 'desc',
			'type'    => 'text',
			'heading' => esc_html__( 'Description', 'buzzeditor' ),
		),
		array(
			'id'      => 'icon',
			'type'    => 'icon_select',
			'heading' => esc_html__( 'Icon', 'buzzeditor' ),
		),
		array(
			'id'       => 'starter_blocks',
			'type'     => 'select',
			'multiple' => 50,
			'options'  => buzzeditor_get_block_names(),
			'heading'  => esc_html__( 'Starter Blocks', 'buzzeditor' ),
		),
		array(
			'id'       => 'accepted_blocks',
			'type'     => 'select',
			'multiple' => 50,
			'options'  => buzzeditor_get_block_names(),
			'heading'  => esc_html__( 'Accepted Blocks', 'buzzeditor' ),
		),
		array(
			'id'      => 'show_in_editor',
			'type'    => 'switcher',
			'heading' => esc_html__( 'Show in Editor Top Bar', 'buzzeditor' ),
			'options' => array(
				'off' => 'no',
				'on'  => '',
			),
		),
		array(
			'id'      => 'show_in_start',
			'type'    => 'switcher',
			'heading' => esc_html__( 'Show in Start Page', 'buzzeditor' ),
			'options' => array(
				'off' => 'no',
				'on'  => '',
			),
		),
		array(
			'id'      => 'show_in_dropdown',
			'type'    => 'switcher',
			'heading' => esc_html__( 'Show in Dropdown', 'buzzeditor' ),
			'options' => array(
				'off' => 'no',
				'on'  => '',
			),
		),
	),
	'default'            => BuzzEditor_Editor::get_instance()->get_default_post_types(),
	'filter_default'     => false,
	'defaults_on_empty'  => true,
	'section'            => 'general',
	'dependency'         => array(
		'element' => 'enable_frontend',
		'value'   => array( '' ),
	),
);

$fields[] = array(
	'id'         => 'show_dropdown',
	'type'       => 'switcher',
	'heading'    => esc_html__( 'Show Create Dropdown', 'buzzeditor' ),
	'section'    => 'general',
	'options'    => array(
		'off' => 'hide',
		'on'  => '',
	),
	'dependency' => array(
		'element' => 'enable_frontend',
		'value'   => array( '' ),
	),
);

$fields[] = array(
	'id'         => 'show_dropdown_all_button',
	'type'       => 'switcher',
	'heading'    => esc_html__( 'Show Create Button All Formats Button', 'buzzeditor' ),
	'section'    => 'general',
	'options'    => array(
		'off' => 'hide',
		'on'  => '',
	),
	'dependency' => array(
		'element' => 'show_dropdown',
		'value'   => array( '' ),
	),
);

$fields[] = array(
	'id'          => 'create_page_layout_style',
	'heading'     => esc_html__( 'Frontend Editor Layout Style', 'buzzeditor' ),
	'description' => esc_html__( 'Select whether you want a boxed or a full width layout.', 'buzzeditor' ),
	'type'        => 'visual_select',
	'options'     => array(
		'full-width'    => esc_html__( 'Full Width', 'buzzeditor' ),
		'boxed'         => esc_html__( 'Full Boxed', 'buzzeditor' ),
		'content-boxed' => esc_html__( 'Boxed Content', 'buzzeditor' ),
	),
	'default'     => 'content-boxed',
	'section'     => 'general',
	'dependency'  => array(
		'element' => 'enable_frontend',
		'value'   => array( '' ),
	),
);

$fields[] = array(
	'id'      => 'user',
	'type'    => 'section',
	'heading' => esc_html__( 'User Permissions', 'buzzeditor' ),
);

$fields[] = array(
	'id'               => 'accepted_user_roles',
	'type'             => 'visual_checkbox',
	'heading'          => esc_html__( 'Enable  Frontend Editor for User Roles', 'buzzeditor' ),
	'description'      => esc_html__( 'Choose Frontend editor access by user roles. You may want to allow access only for Editor user role.', 'buzzeditor' ),
	'default'          => 'administrator,editor,author,contributor,subscriber',
	'options_callback' => 'Ak\Form\FormCallback::get_roles',
	'section'          => 'user',
);

$fields[] = array(
	'id'          => 'user_info',
	'type'        => 'info',
	'heading'     => esc_html__( 'Tip', 'buzzeditor' ),
	'description' => esc_html__( 'Please select non-admin users capabilities.', 'buzzeditor' ),
	'info_type'   => 'tip',
	'section'     => 'user',
);

$fields[] = array(
	'id'      => 'user_can_edit_posts',
	'type'    => 'switcher',
	'heading' => esc_html__( 'User Can Add and Edit Draft/Pending Posts', 'buzzeditor' ),
	'options' => array(
		'off' => 'no',
		'on'  => 'yes',
	),
	'default' => 'yes',
	'section' => 'user',
);

$fields[] = array(
	'id'      => 'user_can_delete_posts',
	'type'    => 'switcher',
	'heading' => esc_html__( 'User Can Delete Draft/Pending Posts', 'buzzeditor' ),
	'options' => array(
		'off' => 'no',
		'on'  => 'yes',
	),
	'default' => 'yes',
	'section' => 'user',
);

$fields[] = array(
	'id'      => 'user_can_publish_posts',
	'type'    => 'switcher',
	'heading' => esc_html__( 'User Can Publish Posts', 'buzzeditor' ),
	'default' => 'no',
	'options' => array(
		'off' => 'no',
		'on'  => 'yes',
	),
	'section' => 'user',
);

$fields[] = array(
	'id'      => 'user_can_edit_published_posts',
	'type'    => 'switcher',
	'heading' => esc_html__( 'User Can Edit Published Posts', 'buzzeditor' ),
	'default' => 'no',
	'options' => array(
		'off' => 'no',
		'on'  => 'yes',
	),
	'section' => 'user',
);

$fields[] = array(
	'id'      => 'user_can_delete_published_posts',
	'type'    => 'switcher',
	'heading' => esc_html__( 'User Can Delete Published Posts', 'buzzeditor' ),
	'default' => 'no',
	'options' => array(
		'off' => 'no',
		'on'  => 'yes',
	),
	'section' => 'user',
);

$fields[] = array(
	'id'          => 'user_max_upload_file_size',
	'type'        => 'number',
	'heading'     => esc_html__( 'User Max Upload File Size', 'buzzeditor' ),
	'description' => esc_html__( 'Default is 5 MB.', 'buzzeditor' ),
	'default'     => 5,
	'section'     => 'user',
);


$fields[] = array(
	'id'      => 'blocks',
	'type'    => 'section',
	'heading' => esc_html__( 'User Blocks', 'buzzeditor' ),
);


$fields[] = array(
	'id'          => 'user_enabled_blocks',
	'type'        => 'visual_checkbox',
	'heading'     => esc_html__( 'Enable User Blocks', 'buzzeditor' ),
	'description' => esc_html__( 'Here you can select frontend blocks. User will be able to add only selected blocks. Do not select any to allow all blocks. Core blocks may depends on another core block, please make sure that you have selected both. Ex: core/column block works with core/columns block.', 'buzzeditor' ),
	'options'     => buzzeditor_get_block_names(),
	'section'     => 'blocks',
);

$fields[] = array(
	'id'      => 'advanced',
	'type'    => 'section',
	'heading' => esc_html__( 'Advanced', 'buzzeditor' ),
);

$fields[] = array(
	'id'          => 'editor_url_slug',
	'type'        => 'text',
	'heading'     => esc_html__( 'Frontend Endpoint', 'buzzeditor' ),
	'description' => esc_html__( 'Choose Frontend editor access endpoint. You may want to change url for editor page with this option. Default is "editor"', 'buzzeditor' ),
	'default'     => 'editor',
	'section'     => 'advanced',
);

$fields[] = array(
	'id'          => 'editor_autosave_interval',
	'type'        => 'number',
	'heading'     => esc_html__( 'Editor Autosave Interval', 'buzzeditor' ),
	'description' => esc_html__( 'Default is 60 seconds.', 'buzzeditor' ),
	'default'     => AUTOSAVE_INTERVAL,
	'section'     => 'advanced',
);

$fields[] = array(
	'id'          => 'hide_admin_bar',
	'type'        => 'switcher',
	'heading'     => esc_html__( 'Remove Admin Bar For Non-Admins', 'buzzeditor' ),
	'description' => esc_html__( 'Force hide admin bar for users.', 'buzzeditor' ),
	'options'     => array(
		'off' => 'hide',
		'on'  => 'show',
	),
	'default'     => 'show',
	'section'     => 'advanced',
);
