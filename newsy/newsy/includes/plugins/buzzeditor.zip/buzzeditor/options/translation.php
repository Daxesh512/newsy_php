<?php


/**
 * Block
 */
$fields[] = array(
	'heading' => 'Post Page',
	'id'      => 'post_page_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);

$fields[] = array(
	'heading' => 'Quiz',
	'id'      => 'post_Quiz_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Quiz',
	'default' => 'Quiz',
	'id'      => 'quiz',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Quizzes',
	'default' => 'Quizzes',
	'id'      => 'quizzes',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Replay Quiz',
	'default' => 'Replay Quiz',
	'id'      => 'replay_quiz',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Share Your Quiz',
	'default' => 'Share Your Quiz',
	'id'      => 'share_your_result',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Share Your Vote:',
	'default' => 'Share Your Vote:',
	'id'      => 'share_your_vote',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'I got: "%1$s" | %2$s',
	'default' => 'I got: "%1$s" | %2$s',
	'id'      => 'i_got',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'I vote for: "%1$s',
	'default' => 'I vote for: "%1$s',
	'id'      => 'i_vote_for',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Show me my results!',
	'default' => 'Show me my results!',
	'id'      => 'show_my_results',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Correct!',
	'default' => 'Correct!',
	'id'      => 'correct',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Wrong!',
	'default' => 'Wrong!',
	'id'      => 'wrong',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'You must login to take this quiz!',
	'default' => 'You must login to take this quiz!',
	'id'      => 'login_to_take_quiz',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Poll',
	'id'      => 'poll_group_start',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => '%s Votes',
	'default' => '%s Votes',
	'id'      => 'number_votes',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Thanks for your vote!',
	'default' => 'Thanks for your vote!',
	'id'      => 'thanks_for_vote',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Total: %s Votes',
	'default' => 'Total: %s Votes',
	'id'      => 'total_number_votes',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'You must login to vote!',
	'default' => 'You must login to vote!',
	'id'      => 'login_to_vote',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'You already voted on this poll!',
	'default' => 'You already voted on this poll!',
	'id'      => 'must_login_poll_vote',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Failed to send request!',
	'default' => 'Failed to send request!',
	'id'      => 'failed_request',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'FlipCard',
	'id'      => 'flipcard_group_start',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Click to Flip',
	'default' => 'Click to Flip',
	'id'      => 'click_to_flip',
	'type'    => 'text',
	'section' => 'translation',
);


/**
 * Editor
 */
$fields[] = array(
	'heading' => 'Frontend Editor',
	'id'      => 'classic_editor_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Title & Category',
	'default' => 'Title & Category',
	'id'      => 'editor_title_category',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Categories',
	'default' => 'Categories',
	'id'      => 'editor_categories',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Description',
	'default' => 'Description',
	'id'      => 'editor_description',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Enter a short description...',
	'default' => 'Enter a short description...',
	'id'      => 'editor_description_placeholder',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Blocks',
	'default' => 'Blocks',
	'id'      => 'editor_blocks',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Add New Block',
	'default' => 'Add New Block',
	'id'      => 'editor_add_new_block',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Preview Image',
	'default' => 'Preview Image',
	'id'      => 'editor_preview_image',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Tags',
	'default' => 'Tags',
	'id'      => 'editor_tags',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Publish Date',
	'default' => 'Publish Date',
	'id'      => 'editor_publish_date',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Text Editor',
	'default' => 'Text Editor',
	'id'      => 'editor_text_editor',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Quiz General',
	'id'      => 'quiz_general_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);

$fields[] = array(
	'heading' => 'Quiz',
	'default' => 'Quiz',
	'id'      => 'quiz',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Questions',
	'default' => 'Questions',
	'id'      => 'quiz_questions',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Question',
	'default' => 'Question',
	'id'      => 'quiz_question',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Results',
	'default' => 'Results',
	'id'      => 'quiz_results',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Result',
	'default' => 'Result',
	'id'      => 'quiz_result',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Answers',
	'default' => 'Answers',
	'id'      => 'quiz_answers',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Answer',
	'default' => 'Answer',
	'id'      => 'quiz_answer',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Answer Layout Style',
	'default' => 'Answer Layout Style',
	'id'      => 'quiz_answer_layout_style',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Text List',
	'default' => 'Text List',
	'id'      => 'quiz_answer_text_list',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => '1 Column',
	'default' => '1 Column',
	'id'      => 'quiz_answer_1_col',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => '2 Columns',
	'default' => '2 Columns',
	'id'      => 'quiz_answer_2_cols',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => '3 Columns',
	'default' => '3 Columns',
	'id'      => 'quiz_answer_3_cols',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Enter Question',
	'default' => 'Enter Question',
	'id'      => 'quiz_enter_question',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Add Answer...',
	'default' => 'Add Answer...',
	'id'      => 'quiz_add_answer',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Trivia Quiz',
	'id'      => 'trivia_quiz_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Trivia Quiz',
	'default' => 'Trivia Quiz',
	'id'      => 'trivia_quiz',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Create "What do you know about ...?" type of quizzes',
	'default' => 'Create "What do you know about ...?" type of quizzes',
	'id'      => 'trivia_quiz_description',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Show correct/wrong feedback?',
	'default' => 'Show correct/wrong feedback?',
	'id'      => 'show_correct_wrong',
	'type'    => 'text',
	'section' => 'translation',
);


$fields[] = array(
	'heading' => 'Correct?',
	'default' => 'Correct?',
	'id'      => 'trivia_correct',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Reveal',
	'default' => 'Reveal',
	'id'      => 'trivia_reveal',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Reveal Heading',
	'default' => 'Reveal Heading',
	'id'      => 'trivia_reveal_heading',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Reveal Description',
	'default' => 'Reveal Description',
	'id'      => 'trivia_reveal_description',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Personality Quiz',
	'id'      => 'personality_quiz_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Personality Quiz',
	'default' => 'Personality Quiz',
	'id'      => 'personality_quiz',
	'type'    => 'text',
	'section' => 'translation',
);


$fields[] = array(
	'heading' => 'Create "What type of person are you?" type of quizzes',
	'default' => 'Create "What type of person are you?" type of quizzes',
	'id'      => 'personality_quiz_description',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Assign a Result',
	'default' => 'Assign a Result',
	'id'      => 'assing_a_result',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Checklist Quiz',
	'id'      => 'checklist_quiz_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Checklist Quiz',
	'default' => 'Checklist Quiz',
	'id'      => 'checklist_quiz',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Default Result',
	'default' => 'Default Result',
	'id'      => 'quiz_default_result',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Custom Result',
	'default' => 'Custom Result',
	'id'      => 'quiz_custom_result',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Result Text:',
	'default' => 'Result Text:',
	'id'      => 'quiz_result_text',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Share Text:',
	'default' => 'Share Text:',
	'id'      => 'quiz_share_text',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'You %1$s <b>#</b> out of <span>#</span> %2$s',
	'default' => 'You %1$s <b>#</b> out of <span>#</span> %2$s',
	'id'      => 'checklist_you_got',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'I %1$s <b>#</b> out of <span>#</span> %2$s',
	'default' => 'I %1$s <b>#</b> out of <span>#</span> %2$s',
	'id'      => 'checklist_i_got',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Poll',
	'id'      => 'poll_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Poll',
	'default' => 'Poll',
	'id'      => 'poll',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Polls',
	'default' => 'Polls',
	'id'      => 'polls',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Create your own poll never easy like this.',
	'default' => 'Create your own poll never easy like this.',
	'id'      => 'poll_description',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Enter Poll Question',
	'default' => 'Enter Poll Question',
	'id'      => 'poll_enter_question',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Poll ID',
	'default' => 'Poll ID',
	'id'      => 'poll_id',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Poll Answers',
	'default' => 'Poll Answers',
	'id'      => 'poll_answers',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Add Answer...',
	'default' => 'Add Answer...',
	'id'      => 'poll_add_answer',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Poll Answer',
	'default' => 'Poll Answer',
	'id'      => 'poll_answer',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Type an answer...',
	'default' => 'Type an answer...',
	'id'      => 'poll_type_answer',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Type media credit...',
	'default' => 'Type media credit...',
	'id'      => 'poll_type_media_credit',
	'type'    => 'text',
	'section' => 'translation',
);

/**
 * Block
 */
$fields[] = array(
	'heading' => 'Versus',
	'id'      => 'versus_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);

$fields[] = array(
	'heading' => 'Versus',
	'default' => 'Versus',
	'id'      => 'versus',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Convo',
	'id'      => 'convo_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Convo',
	'default' => 'Convo',
	'id'      => 'convo',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Convo Item',
	'default' => 'Convo Item',
	'id'      => 'convo_item',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Create a dialogue that fits today’s communication habits.',
	'default' => 'Create a dialogue that fits today’s communication habits.',
	'id'      => 'convo_description',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Add Participant...',
	'default' => 'Add Participant...',
	'id'      => 'add_participant',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Enter Participant name...',
	'default' => 'Enter Participant name...',
	'id'      => 'enter_participant',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'View Style',
	'default' => 'View Style',
	'id'      => 'convo_view_style',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Colored',
	'default' => 'Colored',
	'id'      => 'convo_colored',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Grey',
	'default' => 'Grey',
	'id'      => 'convo_grey',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Dark',
	'default' => 'Dark',
	'id'      => 'convo_dark',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'BeforeAfter',
	'id'      => 'beforeafter_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'BeforeAfter',
	'default' => 'BeforeAfter',
	'id'      => 'beforeafter',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Create the perfect “before and after” experience.',
	'default' => 'Create the perfect “before and after” experience.',
	'id'      => 'beforeafter_description',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Before',
	'default' => 'Before',
	'id'      => 'before',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'After',
	'default' => 'After',
	'id'      => 'after',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Leave empty for no label',
	'default' => 'Leave empty for no label',
	'id'      => 'leave_empty_label',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Orientation',
	'default' => 'Orientation',
	'id'      => 'orientation',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Horizontal',
	'default' => 'Horizontal',
	'id'      => 'horizontal',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Vertical',
	'default' => 'Vertical',
	'id'      => 'vertical',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Drag Handler Position',
	'default' => 'Drag Handler Position',
	'id'      => 'drag_position',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Begin',
	'default' => 'Begin',
	'id'      => 'drag_begin',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Center',
	'default' => 'Center',
	'id'      => 'drag_center',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'End',
	'default' => 'End',
	'id'      => 'drag_end',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'FlipCard',
	'id'      => 'flipcard_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'FlipCard',
	'default' => 'FlipCard',
	'id'      => 'flipcard',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Create the perfect “before and after” experience.',
	'default' => 'Create the perfect “before and after” experience.',
	'id'      => 'flipcard_description',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Front',
	'default' => 'Front',
	'id'      => 'flipcard_front',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Back',
	'default' => 'Back',
	'id'      => 'flipcard_back',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Text',
	'id'      => 'text_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Text',
	'default' => 'Text',
	'id'      => 'text',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Enter Heading',
	'default' => 'Enter Heading',
	'id'      => 'enter_heading',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Write text…',
	'default' => 'Write text…',
	'id'      => 'write_text',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Common',
	'id'      => 'common_heading',
	'type'    => 'heading',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Guest Can Vote?',
	'default' => 'Guest Can Vote?',
	'id'      => 'guest_can_vote',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Settings',
	'default' => 'Settings',
	'id'      => 'settings',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Are you Sure?',
	'default' => 'Are you Sure?',
	'id'      => 'are_you_sure',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Tell them a bit more...',
	'default' => 'Tell them a bit more...',
	'id'      => 'tell_them_a_bit_more',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Fronend Editor Start Page',
	'id'      => 'start_page_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Frontend Post Submission',
	'default' => 'Frontend Post Submission',
	'id'      => 'start_page_heading',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'We\'ve got you covered for all the best post formats from Story to Viral List, Quiz to Poll, and Image Gallery to Video Embed. Choose a post format to start creating your awesome post.',
	'default' => 'We\'ve got you covered for all the best post formats from Story to Viral List, Quiz to Poll, and Image Gallery to Video Embed. Choose a post format to start creating your awesome post.',
	'id'      => 'start_page_description',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'BuddyPress',
	'id'      => 'bp_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Posts',
	'default' => 'Posts',
	'id'      => 'posts',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Published',
	'default' => 'Published',
	'id'      => 'published',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Drafts',
	'default' => 'Drafts',
	'id'      => 'drafts',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Pendings',
	'default' => 'Pendings',
	'id'      => 'pendings',
	'type'    => 'text',
	'section' => 'translation',
);


$fields[] = array(
	'heading' => 'Other',
	'id'      => 'other_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'View All Formats',
	'default' => 'View All Formats',
	'id'      => 'view_all_formats',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Edit with BuzzEditor',
	'default' => 'Edit with BuzzEditor',
	'id'      => 'edit_with_buzzeditor',
	'type'    => 'text',
	'section' => 'translation',
);

