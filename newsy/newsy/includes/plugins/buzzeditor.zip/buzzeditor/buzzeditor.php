<?php
/*
Plugin Name:    BuzzEditor
Plugin URI:     http://themeforest.net/user/akbilisim
Description:    BuzzEditor is a frontend post submission tool that lets you and your users create amazing posts.
Author:         akbilisim
Version:        1.5.0
Author URI:     http://akbilisim.com
Text Domain:    buzzeditor
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

defined( 'BUZZEDITOR_VERSION' ) or define( 'BUZZEDITOR_VERSION', '1.5.0' );
defined( 'BUZZEDITOR_URL' ) or define( 'BUZZEDITOR_URL', plugins_url( 'buzzeditor' ) );
defined( 'BUZZEDITOR_PATH' ) or define( 'BUZZEDITOR_PATH', plugin_dir_path( __FILE__ ) );
defined( 'BUZZEDITOR_OPTIONS' ) or define( 'BUZZEDITOR_OPTIONS', 'buzzeditor-options' );
defined( 'BUZZEDITOR_TRANSLATION' ) or define( 'BUZZEDITOR_TRANSLATION', 'buzzeditor-translation' );

require_once 'class.buzzeditor-block.php';
require_once 'class.buzzeditor-editor.php';
require_once 'class.buzzeditor-endpoint.php';
require_once 'class.buzzeditor-template.php';
require_once 'class.buzzeditor-poll.php';
require_once 'class.buzzeditor-bp.php';

if ( ! function_exists( 'buzzeditor_load' ) ) {
	function buzzeditor_load() {
		BuzzEditor_Block::get_instance();
		BuzzEditor_Editor::get_instance();
		BuzzEditor_Endpoint::get_instance();
		BuzzEditor_Template::get_instance();
		BuzzEditor_Poll::get_instance();
		BuzzEditor_Bp::get_instance();
	}
}

add_action( 'ak-framework/setup/after', 'buzzeditor_load', 98 );

/**
 * Activation hook
 */
function buzzeditor_activation_hook() {
	BuzzEditor_Endpoint::get_instance()->activation_hook();
	BuzzEditor_Poll::get_instance()->activation_hook();
}

register_activation_hook( __FILE__, 'buzzeditor_activation_hook' );

/**
 * Deactivation hook
 */
function buzzeditor_deactivation_hook() {
	BuzzEditor_Endpoint::get_instance()->flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'buzzeditor_deactivation_hook' );

/**
 * Load Text Domain
 */
function buzzeditor_load_textdomain() {
	load_plugin_textdomain( 'buzzeditor', false, basename( __DIR__ ) . '/languages/' );
}

buzzeditor_load_textdomain();

if ( ! function_exists( 'buzzeditor_get_option' ) ) {
	function buzzeditor_get_option( $option_name = '', $default_value = '' ) {
		if ( ! function_exists( 'ak_get_option' ) ) {
			return $default_value;
		}
		return ak_get_option( BUZZEDITOR_OPTIONS, $option_name, $default_value );
	}
}

if ( ! function_exists( 'buzzeditor_echo_option' ) ) {
	function buzzeditor_echo_option( $option_name = '', $default_value = '' ) {
		echo buzzeditor_get_option( $option_name, $default_value );
	}
}

if ( ! function_exists( 'buzzeditor_get_editor_endpoint' ) ) {
	function buzzeditor_get_editor_endpoint() {
		return buzzeditor_get_option( 'editor_url_slug', 'editor' );
	}
}

if ( ! function_exists( 'buzzeditor_get_editor_style' ) ) {
	function buzzeditor_get_editor_style() {
		return buzzeditor_get_option( 'frontend_style', 'classic' );
	}
}

if ( ! function_exists( 'buzzeditor_is_classic' ) ) {
	function buzzeditor_is_classic() {
		return 'classic' === buzzeditor_get_editor_style();
	}
}

add_filter( 'ak-framework/product/pages', 'buzzeditor_register_product_pages', 12 );

if ( ! function_exists( 'buzzeditor_register_product_pages' ) ) {
	function buzzeditor_register_product_pages( $pages ) {
		$pages[ BUZZEDITOR_OPTIONS ] = array(
			'product'    => 'newsy',
			'page_title' => esc_html__( 'BuzzEditor Options', 'buzzeditor' ),
			'capability' => 'manage_options',
			'module'     => 'option-panel',
			'hide_tab'   => true,
			'position'   => 110,
			'config'     => array(
				'panel_title'   => esc_html__( 'BuzzEditor Options', 'buzzeditor' ),
				'panel_options' => array(
					'file'        => BUZZEDITOR_PATH . 'options/panel.php', //conf
					'panel_class' => 'ak-panel-menu-top ', //conf
					'option_id'   => BUZZEDITOR_OPTIONS,
				),
			),
		);

		return $pages;
	}
}


add_filter( 'ak-framework/register/translation', 'buzzeditor_register_translation_fields', 60 );

if ( ! function_exists( 'buzzeditor_register_translation_fields' ) ) {
	/**
	 * Register the BuzzEditor translations to framework.
	 *
	 * @return array
	 */
	function buzzeditor_register_translation_fields( $fields ) {
		$fields['buzzeditor'] = array(
			'name' => __( 'BuzzEditor', 'buzzeditor' ),
			'file' => BUZZEDITOR_PATH . 'options/translation.php',
		);

		return $fields;
	}
}
