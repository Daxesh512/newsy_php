<?php
/*
Plugin Name: Newsy JSON-LD
Plugin URI: http://akbilisim.com
Description: Newsy JSON-LD Schema.
Version: 1.0.0
Author: akbilisim
Author URI: http://akbilisim.com
License: GPL2
*/

defined( 'NEWSY_JSONLD' ) or define( 'NEWSY_JSONLD', 'newsy-jsonld' );
defined( 'NEWSY_JSONLD_URI' ) or define( 'NEWSY_JSONLD_URI', plugins_url( NEWSY_JSONLD ) );
defined( 'NEWSY_JSONLD_PATH' ) or define( 'NEWSY_JSONLD_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Newsy JSON LD init.
 */
if ( ! function_exists( 'newsy_jsonld_load' ) ) {
	function newsy_jsonld_load() {
		require_once 'class.newsy-jsonld.php';
		Newsy_JSONLD::get_instance();

		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( NEWSY_JSONLD, false, basename( __DIR__ ) . '/languages/' );
	}

	add_action( 'plugins_loaded', 'newsy_jsonld_load' );
}
