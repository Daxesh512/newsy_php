<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Newsy_JSONLD {

	/**
	 * The Newsy JSONLD object instance.
	 *
	 * @var Newsy_JSONLD
	 */
	private static $instance;

	/**
	 * Version of Newsy JSONLD.
	 *
	 * @var string
	 */
	public $version = '1.0.0';

	/**
	 * Contains plugin option panel ID
	 *
	 * @var string
	 */
	private $option_id = 'newsy-jsonld-options';

	private $json_header    = array();
	private $json_item_list = array();

	/**
	 * @return Newsy_JSONLD
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	/**
	 * Setup plugin constants.
	 *
	 * @since   1.0.0
	 *
	 * @return void
	 */
	private function __construct() {
		$this->register_hooks();
	}

	/**
	 * Setup hooks.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_head', array( $this, 'build_main_schema' ), 20 );
		add_action( 'wp_head', array( $this, 'render_head' ), 90 );
		add_action( 'wp_footer', array( $this, 'render_footer' ), 90 );
		add_filter( 'ak-framework/product/pages', array( $this, 'register_product_pages' ), 111 );
	}

	/**
	 * Json Output
	 *
	 * @param $data
	 *
	 * @return false|string
	 */
	public function json_output( $data ) {
		return wp_json_encode( $data );
	}

	public function print_json_ld( $json ) {
		if ( $this->get_option( 'enable_schema' ) !== 'hide' ) {
			echo "<script type='application/ld+json'>" . wp_json_encode( $json ) . "</script>\n";
		}
	}

	public function build_main_schema() {
		$scheme_type = $this->get_option( 'main_schema_type', 'organization' );

		if ( 'organization' === $scheme_type ) {
			$organization = array(
				'@context' => 'http://schema.org',
				'@type'    => 'Organization',
				'@id'      => site_url( '/#organization' ),
				'url'      => site_url( '/' ),
				'name'     => $this->json_output( $this->get_option( 'main_schema_organization_name' ) ),
				'logo'     => array(
					'@type' => 'ImageObject',
					'url'   => $this->get_option( 'main_schema_logo' ),
				),
				'sameAs'   => apply_filters( 'newsy_json_ld_social', array() ),
			);

			// contact
			$telephone = $this->get_option( 'main_scheme_telephone' );
			if ( ! empty( $telephone ) ) {
				$contact                = array();
				$contact['@type']       = 'ContactPoint';
				$contact['telephone']   = $telephone;
				$contact['contactType'] = $this->json_output( $this->get_option( 'main_scheme_contact_type', 'Customer Service' ) );

				$area = $this->get_option( 'main_scheme_area' );
				if ( ! empty( $area ) ) {
					$contact['areaServed'] = explode( ',', $area );
				}

				$organization['contactPoint'] = $contact;
			}

			array_push( $this->json_header, $organization );

		} elseif ( 'person' === $scheme_type ) {
			$person = array(
				'@context' => 'http://schema.org',
				'@type'    => 'Person',
				'url'      => site_url( '/' ),
				'name'     => $this->json_output( $this->get_option( 'main_schema_person_name' ) ),
				'sameAs'   => apply_filters( 'newsy_json_ld_social', array() ),
			);

			$country = $this->get_option( 'main_scheme_person_address' );
			if ( $country ) {
				$person['homeLocation'] = array(
					'@type'   => 'Place',
					'address' => array(
						'@type'          => 'PostalAddress',
						'addressCountry' => $this->json_output( $this->get_option( 'main_scheme_person_address' ) ),
					),
				);
			}

			array_push( $this->json_header, $person );
		}

		$organization = array(
			'@context'        => 'http://schema.org',
			'@type'           => 'WebSite',
			'@id'             => site_url( '/#website' ),
			'url'             => site_url( '/' ),
			'name'            => $this->json_output( $this->get_option( 'main_schema_organization_name' ) ),
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => site_url( '/?s={search_term_string}' ),
				'query-input' => 'required name=search_term_string',
			),
		);

		array_push( $this->json_header, $organization );
	}

	public function render_head() {
		if ( $this->json_header ) {
			foreach ( $this->json_header as $id => $json_ld ) {
				$this->print_json_ld( $json_ld );
				unset( $this->json_header[ $id ] );
			}
		}
	}

	public function render_footer() {
		global $wp;
		$current_url = add_query_arg( $wp->query_string, '', home_url() );

		// render archive
		$this->json_item_list = apply_filters( 'newsy_json_item_list', $this->json_item_list );

		if ( ! empty( $this->json_item_list ) ) {
			$archive = array(
				'@context'        => 'http://schema.org',
				'@type'           => 'ItemList',
				'url'             => $current_url,
				'itemListElement' => $this->json_item_list,
			);

			$this->print_json_ld( $archive );
		}

		// render post
		global $wp_query;

		if ( isset( $wp_query->post->ID ) ) {
			$post_id   = $wp_query->post->ID;
			$post      = get_post( $post_id );
			$author_id = $post->post_author;

			if ( is_single() && get_post_type( $post_id ) === 'post' ) {
				$single = array(
					'@context'         => 'http://schema.org',
					'@type'            => $this->get_option( 'article_schema_type', 'article' ),
					'mainEntityOfPage' => array(
						'@type' => 'WebPage',
						'@id'   => get_the_permalink( $post ),
					),
					'dateCreated'      => get_the_date( 'Y-m-d H:i:s', $post ),
					'datePublished'    => get_the_date( 'Y-m-d H:i:s', $post ),
					'dateModified'     => get_post_modified_time( 'Y-m-d H:i:s', $post ),
					'url'              => get_the_permalink( $post ),
					'headline'         => $this->json_output( get_the_title( $post ) ),
					'name'             => $this->json_output( get_the_title( $post ) ),
					'articleBody'      => $this->json_output( $post->post_content ),
					'author'           => array(
						'@type' => 'Person',
						'name'  => $this->json_output( get_the_author_meta( 'display_name', $author_id ) ),
						'url'   => get_author_posts_url( get_the_author_meta( 'ID', $author_id ) ),
					),
				);

				$author_social = $this->get_author_social_meta( $author_id );
				if ( ! empty( $author_social ) ) {
					$single['author']['sameAs'] = $author_social;
				}

				$categories = get_the_category( $post_id );
				if ( ! empty( $categories ) ) {
					$single['articleSection'] = array();
					foreach ( $categories as $category ) {
						$single['articleSection'][] = $this->json_output( $category->name );
					}
				}

				// Post thumbnail
				if ( has_post_thumbnail() ) {
					$post_thumbnail_id = get_post_thumbnail_id( $post_id );
					$image_size        = wp_get_attachment_image_src( $post_thumbnail_id, $post_id );

					$single['image'] = array(
						'@type'  => 'ImageObject',
						'url'    => $image_size[0],
						'width'  => (int) $image_size[1],
						'height' => (int) $image_size[2],
					);
				}

				// Publisher
				$scheme_type = $this->get_option( 'main_schema_type', 'organization' );

				if ( 'organization' === $scheme_type ) {
					$name = $this->get_option( 'main_schema_organization_name' );
				} else {
					$name = $this->get_option( 'main_schema_person_name' );
				}

				$single['publisher'] = array(
					'@type'  => 'Organization',
					'name'   => $this->json_output( $name ),
					'url'    => home_url(),
					'logo'   => array(
						'@type' => 'ImageObject',
						'url'   => $this->get_option( 'main_schema_logo' ),
					),
					'sameAs' => apply_filters( 'newsy_json_ld_social', array() ),
				);

				$logo = $this->get_option( 'main_schema_logo' );

				if ( ! empty( $logo ) ) {
					$single['publisher']['logo'] = array(
						'@type' => 'ImageObject',
						'url'   => $logo,
					);
				}

				// Article
				$this->print_json_ld( $single );

				$hentry = array(
					'@context'    => 'http://schema.org',
					'@type'       => 'hentry',
					'entry-title' => $this->json_output( get_the_title( $post ) ),
					'published'   => get_the_date( 'Y-m-d H:i:s', $post ),
					'updated'     => get_post_modified_time( 'Y-m-d H:i:s', $post ),
				);

				// Hentry
				$this->print_json_ld( $hentry );
			}

			// is page
			if ( get_post_type( $post_id ) === 'page' ) {
				$single = array(
					'@context' => 'http://schema.org',
					'@type'    => 'Webpage',
					'headline' => $this->json_output( get_the_title( $post ) ),
					'url'      => get_the_permalink( $post ),
				);

				// Post thumbnail
				if ( has_post_thumbnail() ) {
					$post_thumbnail_id = get_post_thumbnail_id( $post_id );
					$image_size        = wp_get_attachment_image_src( $post_thumbnail_id, $post_id );

					$single['image'] = array(
						'@type'  => 'ImageObject',
						'url'    => $image_size[0],
						'width'  => $image_size[1],
						'height' => $image_size[2],
					);
				}

				$this->print_json_ld( $single );
			}
		}
	}

	public function get_author_social_meta( $author_id ) {
		$socials    = array(
			'url',
			'facebook',
			'twitter',
			'google',
			'instagram',
			'youtube',
			'vimeo',
			'pinterest',
			'reddit',
			'linkedin',
			'tumblr',
			'flickr',
			'telegram',
			'stumbleupon',
			'digg',
			'whatsapp',
			'foursquare',
			'yahoo',
			'steam',
			'twitch',
			'lastfm',
			'soundcloud',
			'stack-overflow',
			'behance',
			'dribbble',
			'vk',
			'odnoklassniki',
			'weibo',
			'github',
			'wordpress',
			'rss',
		);
		$social_url = array();
		foreach ( $socials as $social ) {
			if ( get_the_author_meta( $social, $author_id ) ) {
				$social_url[] = get_the_author_meta( $social, $author_id );
			}
		}

		return $social_url;
	}

	public function register_product_pages( $pages ) {
		$pages['newsy-jsonld'] = array(
			'product'    => 'newsy',
			'page_title' => __( 'JSON-LD Options', 'newsy-jsonld' ),
			'module'     => 'option-panel',
			'hide_tab'   => true,
			'position'   => 158,
			'config'     => array(
				'panel_title'   => __( 'JSON-LD Schema Options', 'newsy-jsonld' ),
				'panel_options' => array(
					'file'      => $this->dir_path( 'options/panel.php' ),
					'option_id' => $this->option_id,
				),
			),
		);

		return $pages;
	}

	/**
	 * Used for retrieving options simply and safely for next versions
	 *
	 * @param $option_key
	 *
	 * @return mixed|null
	 */
	public function get_option( $option_key, $default_value = '' ) {
		if ( ! function_exists( 'ak_get_option' ) ) {
			return $default_value;
		}

		return ak_get_option( $this->option_id, $option_key, $default_value );
	}

	/**
	 * Used for accessing plugin directory URL
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_url( $address = '' ) {
		return NEWSY_JSONLD_URI . $address;
	}

	/**
	 * Used for accessing plugin directory path
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_path( $address = '' ) {
		return NEWSY_JSONLD_PATH . $address;
	}

	/**
	 * Returns plugin current Version
	 *
	 * @return string
	 */
	public function get_version() {
		return self::$version;
	}
}
