<?php
$fields[] = array(
	'heading' => esc_html__( 'Schema Settings', 'newsy-jsonld' ),
	'id'      => 'schema',
	'type'    => 'section',
);

$fields[] = array(
	'id'          => 'enable_schema',
	'type'        => 'switcher',
	'heading'     => esc_html__( 'Enable json ld schema', 'newsy-jsonld' ),
	'description' => esc_html__( 'Turn this option on to enable newsy generate JSON LD Schema for your website.', 'newsy-jsonld' ),
	'options'     => array(
		'off' => 'hide',
		'on'  => '',
	),
	'section'     => 'schema',
);

$fields[] = array(
	'heading' => esc_html__( 'Main Schema', 'newsy-jsonld' ),
	'id'      => 'main_schema_group_start',
	'type'    => 'group_start',
	'state'   => 'open',
	'section' => 'schema',
);

$fields[] = array(
	'id'          => 'main_schema_type',
	'type'        => 'select',
	'heading'     => esc_html__( 'Home Page Schema Type', 'newsy-jsonld' ),
	'description' => esc_html__( 'Choose which schema you want to use for your home page.', 'newsy-jsonld' ),
	'options'     => array(
		'person'       => esc_html__( 'Person', 'newsy-jsonld' ),
		'organization' => esc_html__( 'Organization', 'newsy-jsonld' ),
	),
	'default'     => 'organization',
	'section'     => 'schema',
);

$fields[] = array(
	'heading'    => esc_html__( 'Person Schema', 'newsy-jsonld' ),
	'id'         => 'main_schema_type_header_person',
	'type'       => 'heading',
	'dependency' => array(
		'element' => 'main_schema_type',
		'value'   => array( 'person' ),
	),
	'section'    => 'schema',
);

$fields[] = array(
	'id'          => 'main_schema_person_name',
	'type'        => 'text',
	'heading'     => esc_html__( 'Name', 'newsy-jsonld' ),
	'description' => esc_html__( 'Insert person name.', 'newsy-jsonld' ),
	'dependency'  => array(
		'element' => 'main_schema_type',
		'value'   => array( 'person' ),
	),
	'section'     => 'schema',
);

$fields[] = array(
	'id'          => 'main_scheme_person_address',
	'type'        => 'text',
	'heading'     => esc_html__( 'Address', 'newsy-jsonld' ),
	'description' => esc_html__( 'Insert country address.', 'newsy-jsonld' ),
	'dependency'  => array(
		'element' => 'main_schema_type',
		'value'   => array( 'person' ),
	),
	'section'     => 'schema',
);

$fields[] = array(
	'heading'    => esc_html__( 'Organization Schema', 'newsy-jsonld' ),
	'id'         => 'main_schema_type_header_organization',
	'type'       => 'heading',
	'dependency' => array(
		'element' => 'main_schema_type',
		'value'   => array( 'organization' ),
	),
	'section'    => 'schema',
);

$fields[] = array(
	'id'          => 'main_schema_organization_name',
	'type'        => 'text',
	'heading'     => esc_html__( 'Organization Name', 'newsy-jsonld' ),
	'description' => esc_html__( 'Insert organization or company name.', 'newsy-jsonld' ),
	'dependency'  => array(
		'element' => 'main_schema_type',
		'value'   => array( 'organization' ),
	),
	'section'     => 'schema',
);

$fields[] = array(
	'id'          => 'main_schema_logo',
	'type'        => 'media_image',
	'heading'     => esc_html__( 'Logo', 'newsy-jsonld' ),
	'description' => esc_html__( 'Upload organization or company logo. This logo will also used by Newsy AMP for showing logo on google search card', 'newsy-jsonld' ),
	'dependency'  => array(
		'element' => 'main_schema_type',
		'value'   => array( 'organization' ),
	),
	'section'     => 'schema',
);

$fields[] = array(
	'id'          => 'main_scheme_telephone',
	'type'        => 'text',
	'heading'     => esc_html__( 'Telephone', 'newsy-jsonld' ),
	'description' => esc_html__( 'e.g. : +1-880-555-1212', 'newsy-jsonld' ),
	'dependency'  => array(
		'element' => 'main_schema_type',
		'value'   => array( 'organization' ),
	),
	'section'     => 'schema',
);

$fields[] = array(
	'id'          => 'main_scheme_contact_type',
	'type'        => 'select',
	'heading'     => esc_html__( 'Contact Type', 'newsy-jsonld' ),
	'description' => esc_html__( 'Choose company contact type.', 'newsy-jsonld' ),
	'options'     => array(
		'customer service'    => esc_attr__( 'Customer service', 'newsy-jsonld' ),
		'technical support'   => esc_attr__( 'Technical support', 'newsy-jsonld' ),
		'billing support'     => esc_attr__( 'Billing support', 'newsy-jsonld' ),
		'bill payment'        => esc_attr__( 'Bill payment', 'newsy-jsonld' ),
		'sales'               => esc_attr__( 'Sales', 'newsy-jsonld' ),
		'reservations'        => esc_attr__( 'Reservations', 'newsy-jsonld' ),
		'credit card_support' => esc_attr__( 'Credit card support', 'newsy-jsonld' ),
		'emergency'           => esc_attr__( 'Emergency', 'newsy-jsonld' ),
		'baggage tracking'    => esc_attr__( 'Baggage tracking', 'newsy-jsonld' ),
		'roadside assistance' => esc_attr__( 'Roadside assistance', 'newsy-jsonld' ),
		'package tracking'    => esc_attr__( 'Package tracking', 'newsy-jsonld' ),
	),
	'default'     => 'customer_service',
	'dependency'  => array(
		'element' => 'main_schema_type',
		'value'   => array( 'organization' ),
	),
	'section'     => 'schema',

);

$fields[] = array(
	'id'          => 'main_scheme_area',
	'type'        => 'text',
	'heading'     => esc_html__( 'Area Served', 'newsy-jsonld' ),
	'description' => esc_html__( 'eg : US , or US,CA', 'newsy-jsonld' ),
	'dependency'  => array(
		'element' => 'main_schema_type',
		'value'   => array( 'organization' ),
	),
	'section'     => 'schema',
);

$fields[] = array(
	'heading' => esc_html__( 'Post Schema', 'newsy-jsonld' ),
	'id'      => 'post_schema_group_start',
	'type'    => 'group_start',
	'state'   => 'open',
	'section' => 'schema',
);

$fields[] = array(
	'id'          => 'article_schema_type',
	'default'     => 'article',
	'type'        => 'select',
	'heading'     => esc_html__( 'Blog Page Schema Type', 'newsy-jsonld' ),
	'description' => esc_html__( 'Choose which schema you want to use for your blog post.', 'newsy-jsonld' ),
	'options'     => array(
		'Article'     => esc_html__( 'Article', 'newsy-jsonld' ),
		'BlogPosting' => esc_html__( 'Blog Posting', 'newsy-jsonld' ),
		'NewsArticle' => esc_html__( 'News Article', 'newsy-jsonld' ),
		'TechArticle' => esc_html__( 'Tech Article ', 'newsy-jsonld' ),
	),
	'section'     => 'schema',
);
