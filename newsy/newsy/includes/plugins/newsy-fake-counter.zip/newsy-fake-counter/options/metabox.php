<?php
include NEWSY_FAKE_COUNTER_PATH . 'options/panel.php';
