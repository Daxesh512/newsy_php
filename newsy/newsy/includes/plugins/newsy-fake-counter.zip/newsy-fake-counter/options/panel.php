<?php

$fields[] = array(
	'heading' => __( 'View Counter', 'newsy-fake-counter' ),
	'id'      => 'settings',
	'type'    => 'section',
	'icon'    => 'fa-eye',
);

if ( ! function_exists( 'newsy_get_post_view_count' ) ) {
	$fields[] = array(
		'heading'     => __( 'Warning', 'newsy-fake-counter' ),
		'description' => __( 'This options needs Newsy View Counter plugin to work properly. Please enable Newsy View Counter plugin.', 'newsy-fake-counter' ),
		'id'          => 'view_counter_info',
		'type'        => 'info',
		'info_type'   => 'warning',
		'section'     => 'settings',
	);
}

$fields[] = array(
	'id'          => 'post_view_base_count',
	'type'        => 'slider',
	'heading'     => __( 'Initial View Count', 'newsy-fake-counter' ),
	'description' => __( 'This value will increase your initial view counter. This value will affect social share, post voting, reaction voting values.', 'newsy-fake-counter' ),
	'input_desc'  => __( 'Leave emty for no fake count', 'newsy-fake-counter' ),
	'default'     => '100',
	'min'         => 0,
	'max'         => 9999,
	'step'        => 5,
	'unit'        => 'views',
	'section'     => 'settings',
);

$fields[] = array(
	'heading' => __( 'Share Counter', 'newsy-fake-counter' ),
	'id'      => 'share',
	'type'    => 'section',
	'icon'    => 'fa-share',
);

$fields[] = array(
	'id'          => 'post_share_view_percentage',
	'type'        => 'slider',
	'heading'     => __( 'Social Share Value base on View', 'newsy-fake-counter' ),
	'description' => __( 'We increase your social share value base on percentage of your view.', 'newsy-fake-counter' ),
	'input_desc'  => __( 'Leave emty for no fake count', 'newsy-fake-counter' ),
	'default'     => '0',
	'min'         => 0,
	'max'         => 100,
	'unit'        => '%',
	'section'     => 'share',
);

$fields[] = array(
	'id'         => 'facebook_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Facebook Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 40,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'twitter_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Twitter Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 25,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'pinterest_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Pinterest Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 9,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'email_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Whatsapp Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 7,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);
$fields[] = array(
	'id'         => 'whatsapp_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Whatsapp Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 5,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'reddit_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Reddit Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 3,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'tumblr_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Tumblr Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 2,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'stumbleupon_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Stumbleupon Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 1,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'line_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Line Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 1,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'viber_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Viber Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 1,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'vk_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'VK Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 1,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'digg_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Digg Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 1,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'id'         => 'linkedin_share_fake_percentage',
	'type'       => 'slider',
	'heading'    => __( 'Linkedin Share Value Percentage', 'newsy-fake-counter' ),
	'default'    => 1,
	'min'        => 0,
	'max'        => 100,
	'unit'       => '%',
	'section'    => 'share',
	'dependency' => array(
		'element'   => 'post_share_view_percentage',
		'not_empty' => true,
	),
);

$fields[] = array(
	'heading' => __( 'Reactions', 'newsy-fake-counter' ),
	'id'      => 'reaction',
	'type'    => 'section',
	'icon'    => 'fa-smile-o',
);

$fields[] = array(
	'id'          => 'post_reaction_view_percentage',
	'type'        => 'slider',
	'heading'     => __( 'Reaction Value base on View', 'newsy-fake-counter' ),
	'description' => __( 'We increase your reaction voting value base on percentage of your view.', 'newsy-fake-counter' ),
	'input_desc'  => __( 'Leave emty for no fake count', 'newsy-fake-counter' ),
	'default'     => '0',
	'min'         => 0,
	'max'         => 100,
	'unit'        => '%',
	'section'     => 'reaction',
);

if ( class_exists( 'Newsy_Reaction' ) ) {
	$reactions      = Newsy_Reaction::get_instance()->get_reactions();
	$reaction_count = count( $reactions );
	foreach ( $reactions as $i => $reaction ) {
		$fields[] = array(
			'id'         => $reaction->slug . '_reaction_fake_percentage',
			'type'       => 'slider',
			'heading'    => sprintf( __( '%s Reaction Value Percentage', 'newsy-fake-counter' ), $reaction->name ),
			'default'    => $reaction_count - $i,
			'min'        => 0,
			'max'        => 100,
			'unit'       => '%',
			'section'    => 'reaction',
			'dependency' => array(
				'element'   => 'post_reaction_view_percentage',
				'not_empty' => true,
			),
		);
	}
}

$fields[] = array(
	'heading' => __( 'Voting ', 'newsy-fake-counter' ),
	'id'      => 'voting',
	'type'    => 'section',
	'icon'    => 'fa-check',
);

$fields[] = array(
	'id'          => 'post_vote_up_base_count',
	'type'        => 'number',
	'heading'     => __( 'Up/Like Voting Count Base', 'newsy-fake-counter' ),
	'description' => __( 'Base value for up voting count.', 'newsy-fake-counter' ),
	'min'         => 10,
	'max'         => 9999999,
	'step'        => 1,
	'section'     => 'voting',
);
$fields[] = array(
	'id'          => 'post_vote_up_view_percentage',
	'type'        => 'slider',
	'heading'     => __( 'Up/Like Voting Value base on View', 'newsy-fake-counter' ),
	'description' => __( 'We increase your post voting value base on percentage of post view.', 'newsy-fake-counter' ),
	'input_desc'  => __( 'Leave emty for no fake count', 'newsy-fake-counter' ),
	'default'     => '0',
	'min'         => 0,
	'max'         => 100,
	'unit'        => '%',
	'section'     => 'voting',
);

$fields[] = array(
	'id'          => 'post_vote_down_base_count',
	'type'        => 'number',
	'heading'     => __( 'Down/Dislike Voting Count Base', 'newsy-fake-counter' ),
	'description' => __( 'Base value for down voting count.', 'newsy-fake-counter' ),
	'min'         => 10,
	'max'         => 9999999,
	'step'        => 1,
	'section'     => 'voting',
);
$fields[] = array(
	'id'          => 'post_vote_down_view_percentage',
	'type'        => 'slider',
	'heading'     => __( 'Down/Dislike Voting Value base on View', 'newsy-fake-counter' ),
	'description' => __( 'We increase your post voting value base on percentage of post view.', 'newsy-fake-counter' ),
	'input_desc'  => __( 'Leave emty for no fake count', 'newsy-fake-counter' ),
	'default'     => '0',
	'min'         => 0,
	'max'         => 100,
	'unit'        => '%',
	'section'     => 'voting',
);
