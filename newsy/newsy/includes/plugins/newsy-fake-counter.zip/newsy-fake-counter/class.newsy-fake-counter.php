<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Newsy_Fake_Counter {

	/**
	 * The Newsy Fake Counter object instance.
	 *
	 * @var Newsy_Fake_Counter
	 */
	private static $instance;

	/**
	 * Version of Newsy Fake Counter.
	 *
	 * @var string
	 */
	public $version = '1.0.0';

	/**
	 * Contains plugin option panel ID
	 *
	 * @var string
	 */
	private $option_id = 'newsy-fake-counter-options';

	/**
	 * @return Newsy_Fake_Counter
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
			static::$instance->register_hooks();
		}

		return static::$instance;
	}

	/**
	 * Setup hooks.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_filter( 'newsy_get_post_view_count', array( $this, 'fake_post_view_count' ), 11, 2 );
		add_filter( 'newsy_get_post_share_counts', array( $this, 'fake_post_share_count' ), 11, 3 );
		add_filter( 'newsy_get_post_reaction_votes', array( $this, 'fake_reaction_count' ), 11, 2 );
		add_filter( 'newsy_get_post_voting_up_count', array( $this, 'fake_voting_up_count' ), 11, 2 );
		add_filter( 'newsy_get_post_voting_down_count', array( $this, 'fake_voting_down_count' ), 11, 2 );

		add_filter( 'ak-framework/product/pages', array( $this, 'register_product_pages' ), 111 );
		// add_filter( 'ak-framework/post/meta', array( $this, 'register_post_meta' ), 111 );
	}

	/**
	 * Filter post view count with fake count.
	 *
	 * @param int $count
	 * @param int $post_id
	 * @return array
	 */
	public function fake_post_view_count( $count, $post_id ) {
		$view_base = $this->get_option( 'post_view_base_count', 100 );

		return (int) $count + (int) $view_base;
	}

	/**
	 * Filter post share counts with fake count.
	 *
	 * @param array $votes
	 * @param int $post_id
	 * @return array
	 */
	public function fake_post_share_count( $share_data, $post_id, $share_sites ) {
		$percentage = $this->get_option( 'post_share_view_percentage', 0 );
		if ( $percentage <= 0 ) {
			return $share_data;
		}

		// get base count from percent of views
		$base_count = $this->get_view_base_count( $percentage, $post_id );

		$total = 0;
		foreach ( $share_sites as $social ) {
			$count           = isset( $share_data[ $social ] ) ? $share_data[ $social ] : 0;
			$item_percentage = $this->social_fake_item_percentage( $social );
			$item_base       = round( $base_count * $item_percentage / 100 );

			$new_count = (int) $count + (int) $item_base;

			$share_data[ $social ] = $new_count;
			$total                += $new_count;
		}

		$share_data['total'] = $total;

		return $share_data;
	}

	/**
	 * Get social provider specific percentage.
	 *
	 * @param $social
	 * @return int|mixed
	 */
	public function social_fake_item_percentage( $social ) {
		$percentage = 0;

		switch ( $social ) {
			case 'facebook':
				$percentage = $this->get_option( $social . '_share_fake_percentage', 40 );
				break;
			case 'twitter':
				$percentage = $this->get_option( $social . '_share_fake_percentage', 25 );
				break;
			case 'pinterest':
				$percentage = $this->get_option( $social . '_share_fake_percentage', 9 );
				break;
			case 'email':
				$percentage = $this->get_option( $social . '_share_fake_percentage', 7 );
				break;
			case 'whatsapp':
				$percentage = $this->get_option( $social . '_share_fake_percentage', 5 );
				break;
			case 'reddit':
				$percentage = $this->get_option( $social . '_share_fake_percentage', 3 );
				break;
			case 'tumblr':
				$percentage = $this->get_option( $social . '_share_fake_percentage', 2 );
				break;
			case 'line':
			case 'viber':
			case 'vk':
			case 'digg':
			case 'linkedin':
			case 'stumbleupon':
				$percentage = $this->get_option( $social . '_share_fake_percentage', 1 );
				break;
			default:
				$percentage = 1;
				break;
		}

		return $percentage;
	}

	/**
	 * Filter reaction vote counts with fake count.
	 *
	 * @param array $votes
	 * @param int $post_id
	 * @return array
	 */
	public function fake_reaction_count( $votes, $post_id ) {
		$percentage = $this->get_option( 'post_reaction_view_percentage', 0 );
		if ( $percentage <= 0 ) {
			return $votes;
		}

		// get base count from percent of views
		$base_count = $this->get_view_base_count( $percentage, $post_id );

		$reactions      = Newsy_Reaction::get_instance()->get_reactions();
		$reaction_count = count( $reactions );
		$total          = 0;

		// Fill fake votes array with $votes data (if any) to keep order.
		foreach ( $reactions as $i => $reaction_term ) {
			$id              = $reaction_term->slug;
			$count           = isset( $votes[ $id ]['count'] ) ? $votes[ $id ]['count'] : 0;
			$item_percentage = $this->reaction_fake_item_percentage( $id, $reaction_count - $i );
			$item_base       = round( $base_count * $item_percentage / 100 );

			$new_count = (int) $count + (int) $item_base;

			// If condig exists, use it.
			$votes[ $id ]['count'] = $new_count;

			$total += $new_count;
		}

		// Recalculate percentages.
		foreach ( $votes as $id => $data ) {
			$vote_per = 0;
			if ( $data['count'] ) {
				$vote_per = (int) round( ( 100 * (int) $data['count'] ) / $total );
			}

			$votes[ $id ]['percentage'] = $vote_per;
		}

		return $votes;
	}

	/**
	 * Get reaction item fake percentage.
	 *
	 * @param $reaction reaction id.
	 * @param $default Item percentage default.
	 *
	 * @return int|mixed
	 */
	public function reaction_fake_item_percentage( $reaction, $default = 0 ) {
		return $this->get_option( $reaction . '_reaction_fake_percentage', $default );
	}

	public function fake_voting_up_count( $vote, $post_id ) {
		$up_base = $this->get_option( 'post_vote_up_base_count', 0 );

		if ( $up_base > 0 ) {
			$vote += (int) $up_base;
		}

		$percentage = $this->get_option( 'post_vote_up_view_percentage', 0 );
		if ( $percentage <= 0 ) {
			return $vote;
		}

		// get base count from percent of views
		$base_count = $this->get_view_base_count( $percentage, $post_id );

		return  (int) $vote + (int) $base_count;
	}

	public function fake_voting_down_count( $vote, $post_id ) {
		$down_base = $this->get_option( 'post_vote_down_base_count', 0 );

		if ( $down_base > 0 ) {
			$vote += (int) $down_base;
		}

		$percentage = $this->get_option( 'post_vote_down_view_percentage', 0 );
		if ( $percentage <= 0 ) {
			return $vote;
		}
		// get base count from percent of views
		$base_count = $this->get_view_base_count( $percentage, $post_id );

		return  (int) $vote + (int) $base_count;
	}

	private function get_view_base_count( $percentage, $post_id ) {
		// get base count from percent of views
		if ( function_exists( 'newsy_get_post_view_count' ) ) {
			$view = newsy_get_post_view_count( $post_id );
		} else {
			$view = 1;
		}

		return (int) round( (int) $view * (int) $percentage / 100 );
	}

	function register_product_pages( $pages ) {
		$pages['newsy-fake-counter'] = array(
			'product'    => 'newsy',
			'page_title' => __( 'Fake Counter Options', 'newsy-fake-counter' ),
			'module'     => 'option-panel',
			'hide_tab'   => true,
			'position'   => 153,
			'config'     => array(
				'panel_title'   => __( 'Fake Counter Options', 'newsy-fake-counter' ),
				'panel_options' => array(
					'file'        => $this->dir_path( 'options/panel.php' ),
					'panel_class' => 'ak-panel-menu-top ',
					'option_id'   => $this->option_id,
				),
			),
		);

		return $pages;
	}


	function register_post_meta( $meta ) {
		$meta['newsy-fake-counter-meta'] = array(
			'title'     => __( 'Fake Counter Options Override', 'newsy-fake-counter' ),
			'file'      => $this->dir_path( 'options/metabox.php' ),
			'post_type' => 'post',
			'context'   => 'normal',
			'prefix'    => false,
			'priority'  => 'low',
		);

		return $meta;
	}

	/**
	 * Used for retrieving options simply and safely for next versions
	 *
	 * @param $option_key
	 *
	 * @return mixed|null
	 */
	public function get_option( $option_key, $default_value = '' ) {
		if ( ! function_exists( 'ak_get_option' ) ) {
			return $default_value;
		}

		return ak_get_option( $this->option_id, $option_key, $default_value );
	}

	/**
	 * Used for accessing plugin directory URL
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_url( $address = '' ) {
		return NEWSY_FAKE_COUNTER_URI . $address;
	}

	/**
	 * Used for accessing plugin directory path
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_path( $address = '' ) {
		return NEWSY_FAKE_COUNTER_PATH . $address;
	}

	/**
	 * Returns plugin current Version
	 *
	 * @return string
	 */
	public function get_version() {
		return $this->version;
	}
}
