<?php

/**
 * Newsy Reaction MyCred Hook class
 */
class Newsy_Reaction_myCRED_Hook extends myCRED_Hook {

	/**
	 * Construct
	 */
	public function __construct( $hook_prefs, $type = MYCRED_DEFAULT_TYPE_KEY ) {
		parent::__construct(
			array(
				'id'       => 'newsy_reaction',
				'defaults' => array(
					'creds' => 1,
					'log'   => _x( 'Reacted to %post_title% with: %reaction%', 'myCRED hook log', 'newsy-reaction' ),
				),
			), $hook_prefs, $type
		);
	}

	/**
	 * Run.
	 */
	public function run() {
		add_action( 'newsy-reaction/vote/added', array( $this, 'vote_added' ), 10, 2 );
		add_filter( 'mycred_parse_tags_newsy_reaction', array( $this, 'parse_custom_tags' ), 10, 2 );
	}

	/**
	 * Parse Custom Tags in Log
	 */
	public function parse_custom_tags( $content, $log_entry ) {
		$data       = maybe_unserialize( $log_entry->data );
		$post_title = get_the_title( $data['post_id'] );
		$content    = str_replace( '%post_title%', $post_title, $content );
		$content    = str_replace( '%reaction%', $data['reaction'], $content );
		return $content;
	}

	/**
	 * Handle added vote.
	 *
	 * @param array $vote_arr  Vote array.
	 * @param array $meta       Post meta.
	 */
	public function vote_added( $post_id, $vote ) {
		$user_id  = get_current_user_id();
		$amount   = $this->prefs['creds'];
		$entry    = $this->prefs['log'];
		$reaction = Newsy_Reaction::get_instance()->get_reaction( $vote );
		$data     = array(
			'ref_type' => 'newsy_reaction',
			'reaction' => $reaction->name,
			'post_id'  => $post_id,
		);
		$this->core->add_creds(
			'newsy_reaction',
			$user_id,
			$amount,
			$entry,
			'',
			$data,
			$this->mycred_type
		);
	}

	/**
	 * Preferences.
	 */
	public function preferences() {
		$prefs = $this->prefs;
		?>
			<div class="hook-instance">
			<h3><?php _ex( 'Reacting to a post', 'myCRED hook instance', 'newsy-reaction' ); ?></h3>
			<div class="row">
				<div class="col-lg-2 col-md-6 col-sm-6 col-xs-12">
					<div class="form-group">
						<label for="<?php echo $this->field_id( 'creds' ); ?>"><?php echo $this->core->plural(); ?></label>
						<input type="text" name="<?php echo $this->field_name( 'creds' ); ?>" id="<?php echo $this->field_id( 'creds' ); ?>"
						value="<?php echo $this->core->number( $prefs['creds'] ); ?>" class="form-control" />
					</div>
				</div>
				<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
					<div class="form-group">
						<label for="<?php echo $this->field_id( 'log' ); ?>"><?php _e( 'Log template', 'newsy-reaction' ); ?></label>
						<input type="text" name="<?php echo $this->field_name( 'log' ); ?>" id="<?php echo $this->field_id( 'log' ); ?>" placeholder="<?php _e( 'required', 'newsy-reaction' ); ?>" value="<?php echo esc_attr( $prefs['log'] ); ?>" class="form-control" />
						<span class="description"><?php echo $this->available_template_tags( array( 'general', 'user' ), '%post_title%, %reaction%' ); ?></span>
					</div>
				</div>
			</div>
			</div>
			<?php
	}
}
