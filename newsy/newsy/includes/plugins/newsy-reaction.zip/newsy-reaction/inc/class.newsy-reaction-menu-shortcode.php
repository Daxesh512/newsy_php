<?php
use Ak\Shortcode\ShortcodeAbstract;

/**
 * Newsy Reaction Menu Shortcode
 */
class Newsy_Reaction_Menu_Shortcode extends ShortcodeAbstract {

	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 *
	 * @return string
	 */
	function render( $atts, $content = '' ) {
		$buffy = '';

		ob_start();
		?>
		<div class="ak-block ak-block-reaction-menu">
			<?php
			newsy_reaction_get_badge_menu();
			?>
		</div>
		<?php
		$buffy .= ob_get_clean();

		return $buffy;
	}

	/**
	 * Fields Map for Shortcode
	 */
	function fields() {
		return array(
			array(
				'type'    => 'css_editor',
				'heading' => __( 'CSS box', 'newsy-elements' ),
				'id'      => 'css',
				'section' => __( 'Design', 'newsy-elements' ),
			),
		);
	}
}
