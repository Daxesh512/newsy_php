<?php
/*
Plugin Name:    Newsy Reaction
Plugin URI:     http://themeforest.net/user/akbilisim
Description:    Cool emoji style buttons to attract your audience to your posts.
Author:         akbilisim
Version:        1.5.0
Author URI:     http://akbilisim.com
Text Domain:    newsy-reaction
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'NEWSY_REACTION_VERSION', '1.5.0' );
define( 'NEWSY_REACTION_URI', plugin_dir_url( __FILE__ ) );
define( 'NEWSY_REACTION_PATH', plugin_dir_path( __FILE__ ) );

require_once 'class.newsy-reaction.php';

if ( ! function_exists( 'newsy_reaction_load' ) ) {
	function newsy_reaction_load() {
		require_once 'class.newsy-reaction-hooks.php';
		Newsy_Reaction_Hooks::get_instance();

		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( 'newsy-reaction', false, basename( __DIR__ ) . '/languages/' );
	}
}

add_action( 'plugins_loaded', 'newsy_reaction_load' );

/**
 * Activation hook
 */
register_activation_hook( __FILE__, array( Newsy_Reaction::get_instance(), 'activation_hook' ) );

if ( ! function_exists( 'newsy_reaction_get_reaction_icon' ) ) {
	/**
	 * Used for retrieving reaction icon.
	 *
	 * @param $term
	 * @param $args
	 *
	 * @return mixed|null
	 */
	function newsy_reaction_get_reaction_icon( $term, $args = array() ) {

		$buffy = '';

		if ( ! is_wp_error( $term ) && gettype( $term ) == 'object' ) {
			$term_url        = get_term_link( $term, '' );
			$term_badge_type = get_term_meta( $term->term_id, 'ak_term_badge_type', true );

			if ( empty( $term_badge_type ) ) {
				return '';
			}

			$term_badge_icon = get_term_meta( $term->term_id, 'ak_term_badge_icon', true );
			$term_badge_text = get_term_meta( $term->term_id, 'ak_term_badge_text', true );

			$term_args = array(
				'only_icon'   => false,
				'url'         => $term_url,
				'icon'        => $term_badge_icon,
				'text'        => ! empty( $term_badge_text ) ? $term_badge_text : $term->name,
				'icon_width'  => 50,
				'icon_height' => 50,
			);

			$args = wp_parse_args( $args, $term_args );
			if ( ! $args['only_icon'] ) {
				$buffy .= '<a href="' . esc_url( $args['url'] ) . '" title="' . esc_attr( $args['text'] ) . '">';
			}

			$buffy .= '<span class="ak-badge-icon ak-badge-type-' . esc_attr( $term_badge_type ) . ' term-' . $term->term_id . '">';
			if ( 'text' === $term_badge_type ) {
				$buffy .= '<span class="ak-badge-icon-text">' . esc_html( $args['text'] ) . '</span>';
			} else {
				$buffy .= ak_get_icon( $args['icon'], 'ak-badge-icon-i', $args['text'] );
			}
			$buffy .= '</span>';

			if ( ! $args['only_icon'] ) {
				$buffy .= '</a>';
			}
		}

		return $buffy;
	}
}

if ( ! function_exists( 'newsy_reaction_get_badge_menu' ) ) {
	/**
	 * Used for retrieving options simply and safely for next versions
	 *
	 * @param $option_key
	 *
	 * @return mixed|null
	 */
	function newsy_reaction_get_badge_menu() {
		if ( ! class_exists( 'Newsy_Reaction_Menu_Walker' ) ) {
			require_once NEWSY_REACTION_PATH . 'inc/class.newsy-reaction-menu-walker.php';
		}

		ak_nav_menu(
			array(
				'walker'         => new Newsy_Reaction_Menu_Walker(),
				'theme_location' => 'badge-menu',
				'menu_class'     => 'ak-menu-wide clearfix',
				'echo'           => true,
			)
		);
	}
}

if ( ! function_exists( 'newsy_reaction_get_voting_box' ) ) {
	/**
	 * Helper function to get voting bax.
	 */
	function newsy_reaction_get_voting_box( $post_id = 0 ) {
		return Newsy_Reaction::get_instance()->render_reaction_box( $post_id );
	}
}
