<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Newsy Reaction
 */
class Newsy_Reaction {

	/**
	 * @var Newsy_Reaction
	 */
	private static $instance;

	/**
	 * @var string
	 */
	public $tax_name = 'reaction';

	/**
	 * @var string
	 */
	private $table_name = 'newsy_reactions_votes';

	/**
	 * @var string
	 */
	private $meta_name = 'ak_br_post_votes';

	/**
	 * Contains plugin option panel ID
	 *
	 * @var string
	 */
	public $option_id = 'newsy-reaction-options';

	/**
	 * @return Newsy_Reaction
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * Activation hook plugin
	 */
	public function activation_hook() {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		if ( $wpdb->get_var( "show tables like '$table_name'" ) != $table_name ) {
			$sql = 'CREATE TABLE ' . $table_name . " (
                    vote_id bigint(20) unsigned NOT NULL auto_increment,
                    post_id bigint(20) NOT NULL ,
                    vote varchar(20) NOT NULL,
                    author_id bigint(20) NOT NULL default '0',
                    author_ip varchar(100) NOT NULL default '',
                    author_host varchar(200) NOT NULL default '',
                    date datetime NOT NULL default '0000-00-00 00:00:00',
                    date_gmt datetime NOT NULL default '0000-00-00 00:00:00',
                    PRIMARY KEY (vote_id),
                    KEY post_id (post_id)
                )";

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
		}
	}

	/**
	 * Return reaction term object by name
	 *
	 * @param string $name      Reaction name.
	 *
	 * @return bool|WP_Term
	 */
	public function get_reaction( $name ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $this->tax_name,
				'hide_empty' => false,
				'slug'       => $name,
			)
		);

		if ( empty( $terms ) ) {
			return false;
		}

		return $terms[0];
	}

	/**
	 * Return list of ordered reactions
	 *
	 * @return array        List of term objects.
	 */
	public function get_reactions() {

		$terms              = array();
		$selected_reactions = $this->get_option( 'reaction_vote_items' );

		if ( ! empty( $selected_reactions ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $this->tax_name,
					'include'    => explode( ',', $selected_reactions ),
					'orderby'    => 'include',
					'order'      => 'ASC',
					'hide_empty' => false,
				)
			);
		}

		if ( empty( $terms ) ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $this->tax_name,
					'hide_empty' => false,
				)
			);
		}

		if ( is_wp_error( $terms ) ) {
			return array();
		}

		return $terms;
	}

	/**
	 * Check whether guest user can vote
	 *
	 * @return bool
	 */
	public function is_valid_reaction( $name ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $this->tax_name,
				'hide_empty' => false,
				'slug'       => $name,
			)
		);

		return ! empty( $terms );
	}

	/**
	 * Return list of ordered post reactions
	 *
	 * @return array        List of term objects.
	 */
	public function get_post_reactions( $post_id = null ) {

		$terms = wp_get_post_terms(
			$post_id,
			$this->tax_name,
			array()
		);

		return $terms;
	}

	/**
	 * Return list of ordered post reactions
	 *
	 * @return string       List of term objects.
	 */
	public function get_most_reactions( $post_id = null, $count = false ) {

		$most_reactions = $this->get_post_reactions( $post_id );

		if ( $count ) {
			$most_reactions = array_slice( $most_reactions, 0, $count );
		}

		$buffy = '';
		foreach ( $most_reactions as $term ) {
			$buffy .= newsy_reaction_get_reaction_icon( $term );
		}

		return $buffy;
	}

	public function render_reaction_box( $post_id = 0 ) {
		$reactions = $this->get_reactions();
		if ( empty( $reactions ) ) {
			return '';
		}

		if ( $post_id ) {
			$post = get_post( $post_id );
		} else {
			$post = get_post();
		}

		if ( ! $post ) {
			return;
		}

		// Common for all reactions.
		$votes     = $this->get_votes( $post->ID );
		$br_nonce  = wp_create_nonce( 'br-reaction-vote' );
		$box_style = $this->get_option( 'reaction_box_style', 'style-1' );

		ob_start();
		?>
	<ul class="br-reaction-items br-reaction-<?php echo esc_attr( $box_style ); ?>"  data-nonce="<?php echo esc_attr( $br_nonce ); ?>" data-post-id="<?php echo absint( $post->ID ); ?>" data-post-url="<?php echo esc_url( get_permalink( $post->ID ) ); ?>">
		<?php
		foreach ( $reactions as $reaction ) :
			// Reaction CSS classes.
			$classes = array(
				'br-reaction',
				'br-reaction-' . $reaction->slug,
			);

			if ( $this->get_status( $post->ID, $reaction->slug ) === $reaction->slug ) {
				$classes[] = 'br-reaction-voted';
			}

			$reaction_value      = isset( $votes[ $reaction->slug ] ) ? $votes[ $reaction->slug ]['count'] : 0;
			$reaction_percentage = isset( $votes[ $reaction->slug ] ) ? $votes[ $reaction->slug ]['percentage'] : 0;
			?>
			<li class="br-reaction-item">
				<a class="<?php echo implode( ' ', $classes ); ?>" data-vote="<?php echo esc_attr( $reaction->slug ); ?>">
					<div class="br-reaction-track">
						<div class="br-reaction-bar" style="height: <?php echo absint( $reaction_percentage ); ?>%;">
							<div class="br-reaction-value"><?php echo absint( $reaction_value ); ?></div>
						</div>
					</div>
					<div class="br-reaction-button">
						<div class="br-reaction-icon-but">
							<?php echo newsy_reaction_get_reaction_icon( $reaction, array( 'only_icon' => true ) ); ?>
						</div>
						<strong class="br-reaction-label"><?php echo esc_html( $reaction->name ); ?></strong>
					</div>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
		<?php
		return ob_get_clean();
	}

	/**
	 * Get total like and dislike
	 *
	 * @param  integer $post_id
	 * @param  string  $type
	 *
	 * @return string  $result
	 *
	 */
	public function get_total_count( $post_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(id) FROM $table_name WHERE post_id = %d",
				$post_id
			)
		);

		return $result;
	}

	/**
	 * Get total reaction vote count.
	 *
	 * @param  integer $post_id
	 * @param  string  $type
	 *
	 * @return string  $result
	 *
	 */
	public function get_vote_count( $post_id, $vote ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(id) FROM $table_name WHERE post_id = %d AND vote = %d",
				$post_id,
				$vote
			)
		);

		return $result;
	}

	/**
	 * Get all reaction votes.
	 *
	 * @param  integer $post_id
	 * @param  array  $votes
	 *
	 * @return string  $result
	 *
	 */
	public function get_votes( $post_id = 0, $votes = array() ) {
		if ( empty( $votes ) ) {
			$votes = get_post_meta( $post_id, $this->meta_name, true );
		}

		if ( empty( $votes ) ) {
			$votes = array();
		}

		return apply_filters( 'newsy_get_post_reaction_votes', $votes, $post_id );
	}

	/**
	 * Get status if have liked or disliked
	 *
	 * @param  integer $post_id
	 *
	 * @return int  $status
	 *
	 */
	public function get_status( $post_id, $vote, $author_id = 0 ) {

		if ( 0 === $author_id ) {
			$author_id = get_current_user_id();
		}

		// User not logged in, guest voting disabled.
		if ( 0 === $author_id && ! $this->is_guest_voting_enabled() ) {
			return false;
		}

		// User not logged in, guest voting enabled.
		if ( 0 === $author_id && $this->is_guest_voting_enabled() ) {
			$vote_cookie = filter_input( INPUT_COOKIE, 'newsy_reaction_vote_' . $vote . '_' . $post_id, FILTER_SANITIZE_STRING );

			return $vote_cookie;
		}

		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$status = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT vote FROM $table_name WHERE post_id = %d AND author_id = %d AND vote = %d ORDER BY vote_id DESC LIMIT 1",
				$post_id,
				$author_id,
				$vote
			)
		);

		return $status;
	}


	/**
	 * Get status if have liked or disliked
	 *
	 * @param  integer $post_id
	 *
	 * @return int  $status
	 *
	 */
	public function send_success( $post_id, $vote ) {

		$votes_meta = $this->update_metadata( $post_id );
		$votes      = $this->get_votes( $post_id, $votes_meta );
		$this->set_post_terms( $post_id, $vote, $votes );

		wp_send_json(
			array(
				'response' => 1,
				'message'  => __( 'Thanks for your vote!', 'newsy-reaction' ),
				'votes'    => $votes,
				'vote'     => $vote,
			)
		);
	}

	/**
	 * Get status if have liked or disliked
	 *
	 * @param  integer $post_id
	 *
	 * @return int  $status
	 *
	 */
	public function send_fail() {
		wp_send_json(
			array(
				'response' => 0,
				'message'  => __( 'Some error occurred while voting. ', 'newsy-reaction' ),
			)
		);
	}

	/**
	 * Main function
	 *
	 * @param  integer $post_id
	 * @param  string  $type
	 *
	 * @return json
	 *
	 */
	public function ajax_do_action( $post_id, $vote ) {

		$status = $this->get_status( $post_id, $vote );

		do_action( 'newsy-reaction/vote', $post_id, $vote, $status );

		if ( null === $status ) {
			$result = $this->insert_vote( $post_id, $vote );

			if ( $result ) {
				do_action( 'newsy-reaction/vote/added', $post_id, $vote );

				$this->send_success( $post_id, $vote );
			} else {
				$this->send_fail();
			}
		} else {
			$result = $this->update_vote( $post_id, $vote );

			if ( $result ) {
				do_action( 'newsy-reaction/vote/updated', $post_id, $vote );

				$this->send_success( $post_id, $vote );
			} else {
				$this->send_fail();
			}
		}
	}

	/**
	 * Main function for ajax
	 */
	public function ajax_vote() {
		check_ajax_referer( 'br-reaction-vote', 'nonce' );

		if ( ! is_user_logged_in() && ! $this->is_guest_voting_enabled() ) {
			wp_send_json(
				array(
					'response' => -1,
					'message'  => __( 'You must login to vote!', 'newsy-reaction' ),
				)
			);
		}

		// Sanitize post id.
		$post_id = (int) filter_input( INPUT_POST, 'post_id', FILTER_SANITIZE_NUMBER_INT ); // Removes all illegal characters from a number.

		if ( 0 === $post_id ) {
			$this->send_fail();
			exit;
		}

		$post = get_post( $post_id );

		if ( ! $post ) {
			$this->send_fail();
			exit;
		}

		// Sanitize type.
		$vote = filter_input( INPUT_POST, 'vote', FILTER_SANITIZE_STRING );

		if ( ! $this->is_valid_reaction( $vote ) ) {
			wp_send_json(
				array(
					'response' => 0,
					'message'  => __( 'Invalid reaction type!', 'newsy-reaction' ),
				)
			);
			exit;
		}

		$this->ajax_do_action( $post->ID, $vote );

		die();
	}


	/**
	 * Insert data into database
	 *
	 * @param  integer $post_id
	 * @param  string  $vote
	 *
	 * @return bool
	 *
	 */
	public function insert_vote( $post_id, $vote ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$post_date  = current_time( 'mysql' );
		$author_id  = get_current_user_id();
		$ip_address = ak_get_ip_address();
		$host       = gethostbyaddr( $ip_address );

		$result = $wpdb->insert(
			$table_name,
			array(
				'post_id'     => $post_id,
				'vote'        => $vote,
				'author_id'   => $author_id,
				'author_ip'   => $ip_address ? $ip_address : '',
				'author_host' => $host ? $host : '',
				'date'        => $post_date,
				'date_gmt'    => get_gmt_from_date( $post_date ),
			),
			array(
				'%d',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
			)
		);

		return $result;
	}

	/**
	 * Update data value into database
	 *
	 * @param  integer $post_id
	 * @param  string  $vote
	 *
	 * @return bool
	 *
	 */
	public function update_vote( $post_id, $vote ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$post_date  = current_time( 'mysql' );
		$author_id  = get_current_user_id();
		$ip_address = ak_get_ip_address();
		$host       = gethostbyaddr( $ip_address );

		$result = $wpdb->update(
			$table_name,
			array(
				'vote'     => $vote,
				'date'     => $post_date,
				'date_gmt' => get_gmt_from_date( $post_date ),
			),
			array(
				'post_id'     => $post_id,
				'author_id'   => $author_id,
				'author_ip'   => $ip_address ? $ip_address : '',
				'author_host' => $host ? $host : '',
			)
		);

		return $result;
	}

	/**
	 * Update data value into database
	 *
	 * @param  integer $post_id
	 * @param  string  $vote
	 *
	 * @return bool
	 *
	 */
	public function generate_metadata( $post_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$votes = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT vote, count(vote) AS cnt
				FROM $table_name
				WHERE post_id = %d
				GROUP BY vote",
				$post_id
			)
		);

		$total_votes = 0;
		$meta        = array();

		foreach ( $votes as $group_data ) {
			$vote = $group_data->vote;
			$cnt  = $group_data->cnt;

			$meta[ $vote ] = array(
				'count' => intval( $cnt ),
			);

			$total_votes += $cnt;
		}

		// Calculate percentages.
		foreach ( $meta as $vote => $data ) {
			$percentage = round( ( 100 * $data['count'] ) / $total_votes );

			$meta[ $vote ]['percentage'] = intval( $percentage );
		}

		return apply_filters( 'br_generate_metadata', $meta, $post_id );
	}

	/**
	 * Check whether guest user can vote
	 *
	 * @return bool
	 */
	public function update_metadata( $post_id = 0, $meta = array() ) {
		$post = get_post( $post_id );

		if ( ! $post ) {
			return false;
		}

		if ( empty( $meta ) ) {
			$meta = $this->generate_metadata( $post_id );
		}

		if ( empty( $meta ) ) {
			return false;
		}

		update_post_meta( $post_id, $this->meta_name, $meta );

		return $meta;
	}

	/**
	 * Check whether guest user can vote
	 *
	 * @return bool
	 */
	public function set_post_terms( $post_id, $vote, $votes ) {
		// Assign post to reaction term if reached threshold.
		$threshold = $this->get_option( 'reaction_threshold', 100 );

		if ( isset( $votes[ $vote ] ) && $votes[ $vote ]['count'] >= $threshold ) {
			$term = $this->get_reaction( $vote );

			if ( $term ) {
				wp_set_post_terms( $post_id, array( $term->term_id ), $this->tax_name, true );
			}
		}
	}

	/**
	 * Check whether guest user can vote
	 *
	 * @return bool
	 */
	public function is_guest_voting_enabled() {
		return $this->get_option( 'guest_voting_is_enabled' ) !== 'off';
	}

	/**
	 * Used for retrieving options simply and safely for next versions
	 *
	 * @param $option_key
	 *
	 * @return mixed|null
	 */
	public function get_option( $option_key, $default_value = '' ) {
		if ( ! function_exists( 'ak_get_option' ) ) {
			return $default_value;
		}

		return ak_get_option( $this->option_id, $option_key, $default_value );
	}

	/**
	 * Used for accessing plugin directory URL
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_url( $address = '' ) {
		return NEWSY_REACTION_URI . $address;
	}

	/**
	 * Used for accessing plugin directory path
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_path( $address = '' ) {
		return NEWSY_REACTION_PATH . $address;
	}

}
