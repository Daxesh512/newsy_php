Change Log :

== 1.5.0 ==
- [NEW] LinkedIn provider
- [IMPROVEMENT] Compatible with Newsy v1.5.0

== 1.0.1 ==
- [Fix] Issue on Social counts

== 1.0.0 ==
- First Release
