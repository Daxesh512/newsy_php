<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Used for retrieving social data from social sites and caching them
 */
class Newsy_Social_Counter {

	/**
	 * Contain live instance object class
	 *
	 * @var Newsy_Social_Counter
	 */
	private static $instance;

	/**
	 * Cached value for counts
	 *
	 * @var array
	 */
	private static $cache = array();

	/**
	 * Cached value for counts
	 *
	 * @var array
	 */
	private static $cache_key = 'newsy_social_counter_data_';

	/**
	 * Contain sites that supported in classs
	 *
	 * @return array
	 */
	private static $supported_sites = array(
		'facebook',
		'twitter',
		'youtube',
		'instagram',
		'soundcloud',
		'twitch',
		'pinterest',
		'steam',
		'flickr',
		'foursquare',
		'linkedin',
		'vk',
		'rss',
	);

	/**
	 * @return Newsy_Social_Counter
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * used for getting sites data in out of class
	 *
	 * @param $service_id
	 * @param $fetch_count
	 * @return array|boolean
	 */
	public function get_social_data( $service_id, $fetch_count = true ) {

		// if id empty or invalid id
		if ( empty( $service_id ) || ! in_array( $service_id, self::$supported_sites, true ) ) {
			return false;
		}

		$id = $this->get_option( $service_id . '_id' );

		if ( empty( $id ) && 'rss' !== $service_id ) {
			return false;
		}

		$count = 0;

		if ( $fetch_count && 'rss' !== $service_id ) {
			$count = $this->get_count( $service_id, $id );
			if ( ! $count ) {
				$count = $this->get_option( $service_id . '_default_count', 0 );
			}
			$count = apply_filters( 'newsy_number_format', $count );
		}

		$data_array = array();

		switch ( $service_id ) {
			case 'facebook':
				$data_array = array(
					'count'      => $count,
					'url'        => "https://www.facebook.com/$id",
					'name'       => ak_get_translation( 'Facebook', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Likes', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Join us on Facebook', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Like our page', 'newsy-social-counter', $service_id . '_button' ),
				);

				break;

			case 'twitter':
				$data_array = array(
					'count'      => $count,
					'url'        => "https://www.twitter.com/$id",
					'name'       => ak_get_translation( 'Twitter', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Followers', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Join us on Twitter', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Follow Us', 'newsy-social-counter', $service_id . '_button' ),
				);

				break;

			case 'youtube':
				$data_array = array(
					'count'      => $count,
					'url'        => ( strpos( 'channel/', $id ) >= 0 ) ? "https://www.youtube.com/$id" : "https://www.youtube.com/user/$id",
					'name'       => ak_get_translation( 'Youtube', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Subscribers', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Join us on Youtube', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Subscribe', 'newsy-social-counter', $service_id . '_button' ),
				);

				break;

			case 'instagram':
				$data_array = array(
					'count'      => $count,
					'url'        => "https://instagram.com/$id",
					'name'       => ak_get_translation( 'Instagram', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Followers', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Join us on Instagram', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Follow Us', 'newsy-social-counter', $service_id . '_button' ),
				);

				break;

			case 'soundcloud':
				$data_array = array(
					'count'      => $count,
					'url'        => "https://soundcloud.com/$id",
					'name'       => ak_get_translation( 'SoundCloud', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Followers', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Join us on SoundCloud', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Follow Us', 'newsy-social-counter', $service_id . '_button' ),
				);

				break;

			case 'pinterest':
				$data_array = array(
					'count'      => $count,
					'url'        => "https://www.pinterest.com/$id",
					'name'       => ak_get_translation( 'Pinterest', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Followers', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Join us on Pinterest', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Follow Us', 'newsy-social-counter', $service_id . '_button' ),
				);

				break;

			case 'vk':
				$data_array = array(
					'count'      => $count,
					'url'        => "https://vk.com/$id",
					'name'       => ak_get_translation( 'Vk', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Members', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Join us on Vk', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Join Us', 'newsy-social-counter', $service_id . '_button' ),
				);

				break;

			case 'twitch':
				$data_array = array(
					'count'      => $count,
					'url'        => "https://twitch.com/$id",
					'name'       => ak_get_translation( 'Twitch', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Followers', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Join us on Twitch', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Follow Us', 'newsy-social-counter', $service_id . '_button' ),
				);
				break;

			case 'steam':
				$data_array = array(
					'count'      => $count,
					'url'        => "http://steamcommunity.com/groups/$id",
					'name'       => ak_get_translation( 'Steam', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Members', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Join us on Steam', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Join Us', 'newsy-social-counter', $service_id . '_button' ),
				);
				break;

			case 'flickr':
				$data_array = array(
					'count'      => $count,
					'url'        => "https://flickr.com/groups/$id",
					'name'       => ak_get_translation( 'Flickr', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Followers', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Follow us on Flickr', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Follow Us', 'newsy-social-counter', $service_id . '_button' ),
				);
				break;

			case 'foursquare':
				$data_array = array(
					'count'      => $count,
					'url'        => "https://foursquare.com/user/$id",
					'name'       => ak_get_translation( 'Foursquare', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Followers', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Follow us on Foursquare', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Follow Us', 'newsy-social-counter', $service_id . '_button' ),
				);
				break;

			case 'linkedin':
				$data_array = array(
					'count'      => $count,
					'url'        => $id,
					'name'       => ak_get_translation( 'LinkedIn', 'newsy-social-counter', $service_id . '_name' ),
					'title'      => ak_get_translation( 'Followers', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Follow us on LinkedIn', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Follow Us', 'newsy-social-counter', $service_id . '_button' ),
				);
				break;

			case 'rss':
				$rss_name   = $this->get_option( $service_id . '_name', __( 'RSS', 'newsy-social-counter' ) );
				$data_array = array(
					'count'      => $rss_name,
					'url'        => get_bloginfo( 'rss_url' ),
					'name'       => $rss_name,
					'title'      => ak_get_translation( 'Subscribe', 'newsy-social-counter', $service_id . '_title' ),
					'title_join' => ak_get_translation( 'Subscribe our RSS', 'newsy-social-counter', $service_id . '_title_join' ),
					'button'     => ak_get_translation( 'Subscribe', 'newsy-social-counter', $service_id . '_button' ),
				);

				break;
		}

		return $data_array;
	}

	/**
	 * - retrieve the count for each service(likes, followers, etc)
	 * @param $service_id
	 * @param $user_id
	 * @param $access_token
	 * @return int
	 */
	private function get_count( $service_id, $user_id, $access_token = '' ) {
		$cached = $this->get_transient( $service_id . '_' . $user_id );

		if ( false !== $cached ) {
			return $cached;
		}

		$final_count = 0;

		try {
			switch ( $service_id ) {
				case 'facebook':
					$access_token = $this->get_option( 'facebook_access_token' );
					if ( ! empty( $access_token ) ) {
						$data = $this->remote_get( "https://graph.facebook.com/v3.0/$user_id?access_token=$access_token&fields=fan_count" );

						if ( ! empty( $data['fan_count'] ) ) {
							$final_count = $data['fan_count'];
						}
					} else {
						$data = $this->remote_get( "https://www.facebook.com/plugins/likebox.php?href=https://facebook.com/$user_id&show_faces=true&header=false&stream=false&show_border=false&locale=en_US", false, array( 'timeout' => 20 ) );

						$pattern = '/_1drq[^>]+>(.*?)<\/a/s';
						preg_match( $pattern, $data, $matches );

						if ( ! empty( $matches[1] ) ) {
							$number = strip_tags( $matches[1] );

							foreach ( str_split( $number ) as $char ) {
								if ( is_numeric( $char ) ) {
									$final_count .= $char;
								}
							}
						}
					}

					break;

				case 'twitter':
					$twitter_key   = $this->get_option( 'twitter_key' );
					$default_token = 'AAAAAAAAAAAAAAAAAAAAAJBzagAAAAAAXr%2Fxj2UWtV%2BnQNigsUm%2Bjrlkr4o%3DoYt2AFQFvPpPsJ1wtVmJ3MLetbYnmTWLFzDZJWLnXZtRJRZKOQ';
					$token         = strlen( $twitter_key ) > 5 ? $twitter_key : $default_token;

					add_filter( 'https_ssl_verify', '__return_false' );
					$data = $this->remote_get(
						"https://api.twitter.com/1.1/users/show.json?screen_name=$user_id", true, array(
							'httpversion' => '1.1',
							'blocking'    => true,
							'timeout'     => 10,
							'headers'     => array(
								'Authorization'   => "Bearer $token",
								'Accept-Language' => 'en',
							),
						)
					);

					if ( isset( $data['followers_count'] ) && ! empty( $data['followers_count'] ) ) {
						$final_count = $data['followers_count'];
					}
					break;

				case 'youtube':
					$youtube_key = $this->get_option( 'youtube_key' );
					$url         = "https://www.googleapis.com/youtube/v3/channels?part=statistics&key=$youtube_key";

					$search_id = str_replace( 'channel/', '', $user_id );

					if ( strpos( $user_id, 'channel/' ) === 0 ) {
						$url .= "&id=$search_id";
					} else {
						$url .= "&forUsername=$search_id";
					}

					$data = $this->remote_get( $url );

					if ( isset( $data['items'][0]['statistics']['subscriberCount'] ) ) {
						$final_count = (int) $data['items'][0]['statistics']['subscriberCount'];
					}
					break;

				case 'instagram':
					$instagram_key = $this->get_option( 'instagram_key' );

					$token = $instagram_key ? $instagram_key : '2367672995.f53f83f.88eda6a77b1d4a9fb704fedc4ff869eb';
					if ( strlen( $token ) > 5 ) {
						$explode_us = explode( '.', $token );
						$id         = current( $explode_us );
						$url        = sprintf(
							'https://api.instagram.com/v1/users/%s?access_token=%s',
							$id,
							$token
						);
						$data       = $this->remote_get( $url );

						if ( isset( $data['data']['counts']['followed_by'] ) ) {
							$final_count = (int) $data['data']['counts']['followed_by'];
						}
					} else {
						$data    = $this->remote_get( 'http://instagram.com/' . $user_id . '#', false, array( 'timeout' => 20 ) );
						$pattern = '/followed_by":[ ]*{"count":(.*?)}/';

						if ( is_string( $data ) && preg_match( $pattern, $data, $matches ) ) {

							$final_count = intval( $matches[1] );
						}
					}
					break;

				case 'soundcloud':
					$data = $this->remote_get( "https://soundcloud.com/$user_id", false );

					$pattern = '/<meta property="soundcloud:follower_count" content="(.*?)">/';
					preg_match( $pattern, $data, $matches );

					if ( ! empty( $matches[1] ) ) {
						$final_count = $matches[1];
					}

					break;

				case 'pinterest':
					$prev = libxml_use_internal_errors( true );
					$html = $this->remote_get( 'http://www.pinterest.com/' . $user_id, false );

					if ( class_exists( 'DOMDocument' ) && $html ) {
						$doc = new DOMDocument();
						$doc->loadHTML( $html );
						libxml_use_internal_errors( $prev );
						$metas = $doc->getElementsByTagName( 'meta' );
						for ( $i = 0; $i < $metas->length; $i ++ ) {
							$meta = $metas->item( $i );
							if ( $meta->getAttribute( 'name' ) == 'pinterestapp:followers' ) {
								$final_count = $meta->getAttribute( 'content' );
								break;
							}
						}
					}
					break;

				case 'twitch':
					$twitch_channel_id = $this->get_option( 'twitch_channel_id' );
					$twitch_key        = $this->get_option( 'twitch_key' );
					$data              = $this->remote_get( "https://api.twitch.tv/kraken/channels/$twitch_channel_id?client_id=$twitch_key" );

					if ( ! empty( $data['followers'] ) ) {
						$final_count = (int) $data['followers'];
					}
					break;

				case 'vk':
					$vk_key = $this->get_option( 'vk_key' );
					$data   = $this->remote_get( "https://api.vk.com/method/users.getFollowers?user_id=$user_id&access_token=$vk_key" );

					if ( ! empty( $data['response']['count'] ) ) {
						$final_count = (int) $data['response']['count'];
					}
					break;

				case 'github':
					$data = $this->remote_get( "https://api.github.com/users/$user_id" );

					if ( ! empty( $data['followers'] ) ) {
						$final_count = (int) $data['followers'];
					}
					break;

				case 'foursquare':
					$key  = $this->get_option( 'foursquare_key' );
					$date = date( 'Ymd' );
					$data = $this->remote_get( "https://api.foursquare.com/v2/users/self?oauth_token=$key&v=$date" );

					if ( isset( $data['response']['user']['friends']['count'] ) ) {
						$final_count = (int) $data['response']['user']['friends']['count'];
					}
					break;

				case 'flickr':
					$key  = $this->get_option( 'flickr_key' );
					$data = $this->remote_get( "https://api.flickr.com/services/rest/?method=flickr.groups.getInfo&api_key=$key&group_id=$user_id&format=json&nojsoncallback=1" );

					if ( isset( $data['group']['members']['_content'] ) ) {
						$final_count = (int) $data['group']['members']['_content'];
					}
					break;

				case 'steam':
					$data = $this->remote_get( "http://steamcommunity.com/groups/$user_id/memberslistxml?xml=1", false );
					$data = @new SimpleXmlElement( $data );
					if ( isset( $data->groupDetails->memberCount ) ) {
						$final_count = (int) $data->groupDetails->memberCount;
					}
					break;
			}
		} catch ( Exception $e ) {
		}

		$final_count = is_numeric( $final_count ) && $final_count > 0 ? intval( $final_count ) : 0;

		$this->set_transient( $service_id . '_' . $user_id, $final_count );

		return $final_count;
	}

	/**
	 * Get remote data
	 *
	 * @param      $url
	 * @param bool $json
	 *
	 * @return array|mixed|string
	 */
	private function remote_get( $url, $json = true, $args = array(
		'timeout'   => 18,
		'sslverify' => false,
	) ) {

		$get_request = wp_remote_get( $url, $args );

		$request = wp_remote_retrieve_body( $get_request );

		if ( $json ) {
			$request = @json_decode( $request, true );
		}

		return $request;
	}

	/**
	 * Used for retrieving data for a social site
	 *
	 * @param      $id
	 * @param bool $fresh
	 *
	 * @return bool|mixed
	 */
	public function get_transient( $id, $fresh = false ) {

		if ( isset( self::$cache[ $id ] ) && ! $fresh ) {
			return self::$cache[ $id ];
		}

		$temp = get_transient( self::$cache_key . $id );

		self::$cache[ $id ] = $temp;

		return $temp;
	}

	/**
	 * Save a value in WP cache system
	 *
	 * @param $id
	 * @param $data
	 *
	 * @return bool
	 */
	public function set_transient( $id, $data ) {
		return set_transient( self::$cache_key . $id, $data, $this->get_option( 'cache_time', 12 ) * HOUR_IN_SECONDS );
	}

	/**
	 * clear cache in WP cache system
	 *
	 * @param $id
	 *
	 * @return bool
	 */
	public function clear_transient( $id ) {
		return delete_transient( self::$cache_key . $id );
	}

	/**
	 * Deletes cached data
	 *
	 * @param string $key
	 */
	public static function clear_cache( $key = 'all' ) {
		if ( 'all' === $key ) {
			global $wpdb;
			$wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name LIKE %s", '_transient_' . self::$cache_key . '%' ) );
			$wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name LIKE %s", '_transient_timeout_' . self::$cache_key . '%' ) );
		} else {
			self::get_instance()->clear_transient( $key );
		}
	}

	/**
	 * Used for retrieving options simply and safely for next versions
	 *
	 * @param $option_key
	 *
	 * @return mixed|null
	 */
	public function get_option( $option_key, $default_value = '' ) {
		if ( ! function_exists( 'ak_get_option' ) ) {
			return $default_value;
		}

		return ak_get_option( NEWSY_SOCIAL_COUNTER, $option_key, $default_value );
	}

	/**
	 * Used for accessing plugin directory URL
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_url( $address = '' ) {
		return NEWSY_SOCIAL_COUNTER_URI . $address;
	}

	/**
	 * Used for accessing plugin directory path
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_path( $address = '' ) {
		return NEWSY_SOCIAL_COUNTER_PATH . $address;
	}
}
