<?php
/*
Plugin Name: Newsy Social Counter
Plugin URI: http://akbilisim.com
Description: Social counter for Newsy. Add functionality for showing social pages and follower counts.
Version: 1.5.0
Author: akbilisim
Author URI: http://akbilisim.com
License: GPL2
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

defined( 'NEWSY_SOCIAL_COUNTER' ) or define( 'NEWSY_SOCIAL_COUNTER', 'newsy-social-counter' );
defined( 'NEWSY_SOCIAL_COUNTER_VERSION' ) or define( 'NEWSY_SOCIAL_COUNTER_VERSION', '1.5.0' );
defined( 'NEWSY_SOCIAL_COUNTER_URI' ) or define( 'NEWSY_SOCIAL_COUNTER_URI', plugin_dir_url( __FILE__ ) );
defined( 'NEWSY_SOCIAL_COUNTER_PATH' ) or define( 'NEWSY_SOCIAL_COUNTER_PATH', plugin_dir_path( __FILE__ ) );

require_once 'class.newsy-social-counter.php';

// Initialize Newsy Social Counter
if ( ! function_exists( 'newsy_social_counter_load' ) ) {
	function newsy_social_counter_load() {
		require_once 'class.newsy-social-counter-hooks.php';
		Newsy_Social_Counter_Hooks::get_instance();

		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( NEWSY_SOCIAL_COUNTER, false, basename( __DIR__ ) . '/languages/' );
	}
}

add_action( 'plugins_loaded', 'newsy_social_counter_load' );


if ( ! function_exists( 'newsy_social_counter_render' ) ) {
	/**
	 * Used for rendering social counters.
	 *
	 * @return mixed|null
	 */
	function newsy_social_counter_render( $social_sites, $style = 'style-1', $color_style = 'colored', $simple = false ) {
		$output = '';

		if ( ! empty( $social_sites ) ) {

			if ( is_string( $social_sites ) ) {
				$social_sites = array_flip( explode( ',', $social_sites ) );
			}

			$output .= '<ul class="ak-social-counter social-counter-' . esc_attr( $style ) . ' social-counter-' . esc_attr( $color_style ) . ' clearfix">';
			foreach ( (array) $social_sites as $site => $val ) {

				$fetch_count = ( 'style-1' === $style || 'style-2' === $style );

				$data = Newsy_Social_Counter::get_instance()->get_social_data( $site, $fetch_count );

				if ( $data && is_array( $data ) ) {
					$output .= '<li class="social-item">';

					$output .= '<a href="' . $data['url'] . ' " class=" ' . $site . '" target="_blank" rel="external noopener nofollow">';
					$output .= '<i class="item-icon fa fa-' . $site . '"></i>';
					if ( ! $simple ) {
						$output .= '<span class="item-count">' . $data['count'] . '</span>';
						$output .= '<span class="item-name">' . $data['name'] . '</span>';
						$output .= '<span class="item-title">' . $data['title'] . '</span>';
						$output .= '<span class="item-join">' . $data['title_join'] . '</span>';
						$output .= '<span class="item-button">' . $data['button'] . '</span>';
					}
					$output .= '</a>';

					$output .= '</li>';
				}
			}

			$output .= '</ul>';
		}

		return $output;
	}
}

if ( ! function_exists( 'newsy_get_social_site_options' ) ) {
	/**
	 * Get the social sites field options.
	 *
	 * @return array
	 */
	function newsy_get_social_site_options() {
		return array(
			'facebook'   => '<i class="fa fa-facebook"></i> ' . __( 'Facebook', 'newsy-social-counter' ),
			'twitter'    => '<i class="fa fa-twitter"></i> ' . __( 'Twitter', 'newsy-social-counter' ),
			'youtube'    => '<i class="fa fa-youtube"></i> ' . __( 'Youtube', 'newsy-social-counter' ),
			'instagram'  => '<i class="fa fa-instagram"></i> ' . __( 'Instagram', 'newsy-social-counter' ),
			'soundcloud' => '<i class="fa fa-soundcloud"></i> ' . __( 'Soundcloud', 'newsy-social-counter' ),
			'twitch'     => '<i class="fa fa-twitch"></i> ' . __( 'Twitch', 'newsy-social-counter' ),
			'steam'      => '<i class="fa fa-steam"></i> ' . __( 'Steam', 'newsy-social-counter' ),
			'flickr'     => '<i class="fa fa-flickr"></i> ' . __( 'Flickr', 'newsy-social-counter' ),
			'foursquare' => '<i class="fa fa-foursquare"></i> ' . __( 'Foursquare', 'newsy-social-counter' ),
			'pinterest'  => '<i class="fa fa-pinterest"></i> ' . __( 'Pinterest', 'newsy-social-counter' ),
			'linkedin'   => '<i class="fa fa-linkedin"></i> ' . __( 'LinkedIn', 'newsy-social-counter' ),
			'vk'         => '<i class="fa fa-vk"></i> ' . __( 'Vk', 'newsy-social-counter' ),
			'rss'        => '<i class="fa fa-rss"></i> ' . __( 'Rss', 'newsy-social-counter' ),
		);
	}
}
