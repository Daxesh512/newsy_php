<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Newsy Social Counter Hooks
 */
class Newsy_Social_Counter_Hooks {

	/**
	 * @var Newsy_Social_Counter_Hooks
	 */
	private static $instance;

	/**
	 * @return Newsy_Social_Counter_Hooks
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * Newsy_Reaction_Hooks constructor.
	 */
	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 999 );

		add_filter( 'ak-framework/product/pages', array( $this, 'register_product_pages' ), 11 );
		add_filter( 'ak-framework/register/translation', array( $this, 'register_translation_fields' ), 15 );
		add_filter( 'ak-framework/options/std', array( $this, 'register_options_std' ), 11, 2 );
		add_action( 'ak-framework/option-panel/save/after', array( $this, 'handle_reset_cache' ), 999, 1 );
		add_filter( 'ak-framework/shortcode', array( $this, 'register_shortcode' ), 11 );
	}

	/**
	 * Load plugin assest
	 */
	public function register_assets() {
		// styles
		wp_enqueue_style( 'newsy-social-counter', NEWSY_SOCIAL_COUNTER_URI . 'css/style.css', array(), NEWSY_SOCIAL_COUNTER_VERSION );
		wp_style_add_data( 'newsy-social-counter', 'rtl', 'replace' );
	}

	public function register_product_pages( $pages ) {
		$pages['newsy-social-counter'] = array(
			'product'    => 'newsy',
			'page_title' => __( 'Social Counter Options', 'newsy-social-counter' ),
			'capability' => 'manage_options',
			'module'     => 'option-panel',
			'hide_tab'   => true,
			'position'   => 152,
			'config'     => array(
				'panel_title'   => __( 'Social Counter Options', 'newsy-social-counter' ),
				'panel_options' => array(
					'file'        => NEWSY_SOCIAL_COUNTER_PATH . 'inc/options/panel.php',
					'panel_class' => 'ak-panel-menu-top ',
					'option_id'   => NEWSY_SOCIAL_COUNTER,
				),
			),
		);

		return $pages;
	}

	public function register_translation_fields( $fields ) {
		$fields['newsy-social-counter'] = array(
			'name' => __( 'Newsy Social Counter', 'newsy-social-counter' ),
			'file' => NEWSY_SOCIAL_COUNTER_PATH . 'inc/options/translation.php',
		);

		return $fields;
	}

	public function register_options_std( $options, $option_id ) {
		if ( NEWSY_SOCIAL_COUNTER === $option_id ) {
			$options['facebook_id']   = 'envato';
			$options['twitter_id']    = 'envato';
			$options['instagram_id']  = 'envato';
			$options['pinterest_id']  = 'envato';
			$options['youtube_id']    = 'envato';
			$options['soundcloud_id'] = 'envato';
		}

		return $options;
	}

	public function handle_reset_cache( $option_id ) {
		if ( NEWSY_SOCIAL_COUNTER === $option_id ) {
			Newsy_Social_Counter::clear_cache();
		}
	}

	public function register_shortcode( $shortcodes ) {
		if ( class_exists( 'NewsyElements\Shortcode\BlockAbstract' ) ) {
			$shortcodes['newsy_social_counter'] = array(
				'have_map_for_vc' => true,
				'have_widget'     => true,
				'name'            => 'Newsy Social Counter',
				'class'           => 'Newsy_Social_Counter_Shortcode',
				'file'            => NEWSY_SOCIAL_COUNTER_PATH . 'inc/shortcodes/newsy_social_counter.php',
				'category'        => array( 'Newsy', 'Newsy Widgets' ),
				'icon'            => NEWSY_SOCIAL_COUNTER_URI . 'images/sc-shortcode-icon.png',
			);
		}

		return $shortcodes;
	}
}
