<?php

$fields[] = array(
	'heading' => __( 'Settings', 'newsy-social-counter' ),
	'id'      => 'settings',
	'type'    => 'section',
);

//
// Facebook
//
$fields[] = array(
	'heading' => __( 'Facebook', 'newsy-social-counter' ),
	'id'      => 'facebook_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);
$fields[] = array(
	'heading'     => __( 'Facebook', 'newsy-social-counter' ),
	'description' => __( 'App must have the "manage_pages" or "pages_read_engagement" permission or the "Page Public Content Access" feature or the "Page Public Metadata Access" feature. Refer to https://developers.facebook.com/docs/apps/review/login-permissions#manage-pages, https://developers.facebook.com/docs/apps/review/feature#reference-PAGES_ACCESS and https://developers.facebook.com/docs/apps/review/feature#page-public-metadata-access for details.', 'newsy-social-counter' ),
	'id'          => 'facebook_info',
	'type'        => 'info',
	'section'     => 'settings',
);
$fields[] = array(
	'heading' => __( 'Facebook ID', 'newsy-social-counter' ),
	'id'      => 'facebook_id',
	'type'    => 'text',
	'section' => 'settings',
);
$fields[] = array(
	'heading'     => __( 'Facebook App ID', 'newsy-social-counter' ),
	'description' => sprintf( __( 'You can create an application and get Facebook App ID <a href="%s" target="_blank">here</a>.', 'newsy-social-counter' ), 'https://developers.facebook.com/docs/apps/register' ),
	'id'          => 'facebook_app_id',
	'type'        => 'text',
	'section'     => 'settings',
);
$fields[] = array(
	'heading'     => __( 'Facebook Security Key', 'newsy-social-counter' ),
	'description' => sprintf( __( 'You can create an application and get Facebook App Secret <a href="%s" target="_blank">here</a>.', 'newsy-social-counter' ), 'https://developers.facebook.com/docs/apps/register' ),
	'id'          => 'facebook_security_key',
	'type'        => 'text',
	'section'     => 'settings',
);
$fields[] = array(
	'heading'     => __( 'Facebook Access Token', 'newsy-social-counter' ),
	'description' => sprintf( __( 'Get your Facebook Access Token by clicking this <a class="%1$s" href="%2$s" target="_blank">link</a>.', 'newsy-social-counter' ), 'newsy_access_token facebook', '#' ),
	'id'          => 'facebook_access_token',
	'type'        => 'text',
	'section'     => 'settings',
);

//
// Twitter
//
$fields[] = array(
	'heading' => __( 'Twitter', 'newsy-social-counter' ),
	'id'      => 'twitter_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Twitter ID', 'newsy-social-counter' ),
	'id'      => 'twitter_id',
	'type'    => 'text',
	'section' => 'settings',
);
$fields[] = array(
	'heading' => __( 'Twitter Access Token', 'newsy-social-counter' ),
	'id'      => 'twitter_key',
	'type'    => 'text',
	'section' => 'settings',
);

$fields[] = array(
	'heading' => __( 'Youtube', 'newsy-social-counter' ),
	'id'      => 'youtube_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);
$fields[] = array(
	'heading'     => __( 'Youtube ID', 'newsy-social-counter' ),
	'description' => "User: www.youtube.com/user/<b style='color: #000'>ENVATO</b><br/>Channel: www.youtube.com/ <b style='color: #000'>channel/UCJr72fY4cTaNZv7WPbvjaSw</b>",
	'id'          => 'youtube_id',
	'type'        => 'text',
	'section'     => 'settings',
);
$fields[] = array(
	'heading'     => __( 'Youtube Key', 'newsy-social-counter' ),
	'description' => sprintf( __( 'You can register Google API Key here for <a href="%s" target="_blank">YouTube</a>.', 'newsy-social-counter' ), 'https://developers.google.com/youtube/v3/getting-started' ),
	'id'          => 'youtube_key',
	'type'        => 'text',
	'section'     => 'settings',
);

$fields[] = array(
	'heading' => __( 'Instagram', 'newsy-social-counter' ),
	'id'      => 'instagram_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Instagram ID', 'newsy-social-counter' ),
	'id'      => 'instagram_id',
	'type'    => 'text',
	'section' => 'settings',
);
$fields[] = array(
	'heading'     => __( 'Instagram Access Token', 'newsy-social-counter' ),
	'description' => sprintf( __( 'Get your Instagram Access Token by clicking this <a class="%1$s" href="%2$s" target="_blank">link</a>.', 'newsy-social-counter' ), 'newsy_access_token instagram', '#' ),
	'id'          => 'instagram_access_token',
	'type'        => 'text',
	'section'     => 'settings',
);

$fields[] = array(
	'heading' => __( 'Soundcloud', 'newsy-social-counter' ),
	'id'      => 'soundcloud_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);

$fields[] = array(
	'heading' => __( 'Soundcloud ID', 'newsy-social-counter' ),
	'id'      => 'soundcloud_id',
	'type'    => 'text',
	'section' => 'settings',
);


$fields[] = array(
	'heading' => __( 'Pinterest', 'newsy-social-counter' ),
	'id'      => 'pinterest_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Pinterest ID', 'newsy-social-counter' ),
	'id'      => 'pinterest_id',
	'type'    => 'text',
	'section' => 'settings',
);

$fields[] = array(
	'heading' => __( 'Steam', 'newsy-social-counter' ),
	'id'      => 'steam_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Steam Group Id', 'newsy-social-counter' ),
	'id'      => 'steam_id',
	'type'    => 'text',
	'section' => 'settings',
);

$fields[] = array(
	'heading' => __( 'Flickr', 'newsy-social-counter' ),
	'id'      => 'flickr_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Flickr Group ID', 'newsy-social-counter' ),
	'id'      => 'flickr_id',
	'type'    => 'text',
	'section' => 'settings',
);
$fields[] = array(
	'heading' => __( 'Flickr Access Key', 'newsy-social-counter' ),
	'id'      => 'flickr_key',
	'type'    => 'text',
	'section' => 'settings',
);
$fields[] = array(
	'heading' => __( 'Foursquare', 'newsy-social-counter' ),
	'id'      => 'foursquare_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Foursquare User ID', 'newsy-social-counter' ),
	'id'      => 'foursquare_id',
	'type'    => 'text',
	'section' => 'settings',
);
$fields[] = array(
	'heading' => __( 'Foursquare Access Key', 'newsy-social-counter' ),
	'id'      => 'foursquare_key',
	'type'    => 'text',
	'section' => 'settings',
);

$fields[] = array(
	'heading' => __( 'LinkedIn', 'newsy-social-counter' ),
	'id'      => 'linkedin_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);

$fields[] = array(
	'heading'     => __( 'LinkedIn URL', 'newsy-social-counter' ),
	'description' => __( 'Enter FULL Page URL. Example:  https://www.linkedin.com/company/envato/', 'newsy-social-counter' ),
	'id'          => 'linkedin_id',
	'type'        => 'text',
	'section'     => 'settings',
);

$fields[] = array(
	'heading' => __( 'Vk', 'newsy-social-counter' ),
	'id'      => 'vk_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);

$fields[] = array(
	'heading' => __( 'Vk ID', 'newsy-social-counter' ),
	'id'      => 'vk_id',
	'type'    => 'text',
	'section' => 'settings',
);
$fields[] = array(
	'heading' => __( 'Vk Access Key', 'newsy-social-counter' ),
	'id'      => 'vk_key',
	'type'    => 'text',
	'section' => 'settings',
);



$fields[] = array(
	'heading' => __( 'Twitch', 'newsy-social-counter' ),
	'id'      => 'twitch_head',
	'type'    => 'group_start',
	'section' => 'settings',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Twitch ID', 'newsy-social-counter' ),
	'id'      => 'twitch_id',
	'type'    => 'text',
	'section' => 'settings',
);
$fields[] = array(
	'heading' => __( 'Twitch Channel ID', 'newsy-social-counter' ),
	'id'      => 'twitch_channel_id',
	'type'    => 'text',
	'section' => 'settings',
);
$fields[] = array(
	'heading'     => __( 'Twitch Client ID', 'newsy-social-counter' ),
	'description' => sprintf( __( 'You can create an application and get Twitch Client ID <a href="%s" target="_blank">here</a>.', 'newsy-social-counter' ), 'https://dev.twitch.tv/docs/v5/guides/authentication/' ),
	'id'          => 'twitch_key',
	'type'        => 'text',
	'section'     => 'settings',
);

$fields[] = array(
	'heading' => __( 'Default Counts', 'newsy-social-counter' ),
	'id'      => 'default_counts',
	'type'    => 'section',
);
$fields[] = array(
	'heading'     => __( 'Info', 'newsy-social-counter' ),
	'description' => __( 'Here you can manually set default counts for providers. This options allows you to add your own counts if you don\'t want to use api keys.', 'newsy-social-counter' ),
	'id'          => 'default_counts_info',
	'type'        => 'info',
	'section'     => 'default_counts',
);
$fields[] = array(
	'heading' => __( 'Facebook', 'newsy-social-counter' ),
	'id'      => 'facebook_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);
$fields[] = array(
	'heading' => __( 'Twitter', 'newsy-social-counter' ),
	'id'      => 'twitter_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);
$fields[] = array(
	'heading' => __( 'Youtube', 'newsy-social-counter' ),
	'id'      => 'youtube_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);
$fields[] = array(
	'heading' => __( 'Instagram', 'newsy-social-counter' ),
	'id'      => 'instagram_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);
$fields[] = array(
	'heading' => __( 'Soundcloud', 'newsy-social-counter' ),
	'id'      => 'soundcloud_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);
$fields[] = array(
	'heading' => __( 'Pinterest', 'newsy-social-counter' ),
	'id'      => 'pinterest_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);
$fields[] = array(
	'heading' => __( 'VK', 'newsy-social-counter' ),
	'id'      => 'vk_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);
$fields[] = array(
	'heading' => __( 'LinkedIn', 'newsy-social-counter' ),
	'id'      => 'linkedin_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);
$fields[] = array(
	'heading' => __( 'Steam', 'newsy-social-counter' ),
	'id'      => 'steam_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);

$fields[] = array(
	'heading' => __( 'Flickr', 'newsy-social-counter' ),
	'id'      => 'flickr_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);
$fields[] = array(
	'heading' => __( 'Foursquare', 'newsy-social-counter' ),
	'id'      => 'foursquare_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);

$fields[] = array(
	'heading' => __( 'Twitch', 'newsy-social-counter' ),
	'id'      => 'twitch_default_count',
	'type'    => 'number',
	'section' => 'default_counts',
);

//
// Cache Time
//
$fields[] = array(
	'heading' => __( 'Advanced', 'newsy-social-counter' ),
	'id'      => 'advance',
	'type'    => 'section',
);
$fields[] = array(
	'heading' => __( 'Cache Time (in hours)', 'newsy-social-counter' ),
	'id'      => 'cache_time',
	'type'    => 'number',
	'default' => '12',
	'section' => 'advance',
);
