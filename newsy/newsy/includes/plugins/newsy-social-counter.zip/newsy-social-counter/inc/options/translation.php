<?php

//
// Facebook
//
$fields[] = array(
	'heading' => __( 'Facebook', 'newsy-social-counter' ),
	'id'      => 'facebook_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);

$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'facebook_name',
	'type'    => 'text',
	'default' => __( 'Facebook', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'facebook_title',
	'type'    => 'text',
	'default' => __( 'Likes', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'facebook_title_join',
	'type'    => 'text',
	'default' => __( 'Join us on Facebook', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'facebook_button',
	'type'    => 'text',
	'default' => __( 'Like our page', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// Twitter
//
$fields[] = array(
	'heading' => __( 'Twitter', 'newsy-social-counter' ),
	'id'      => 'twitter_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);

$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'twitter_name',
	'type'    => 'text',
	'default' => __( 'Twitter', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'twitter_title',
	'type'    => 'text',
	'default' => __( 'Followers', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'twitter_title_join',
	'type'    => 'text',
	'default' => __( 'Join us on Twitter', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'twitter_button',
	'type'    => 'text',
	'default' => __( 'Follow Us', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// Youtube
//
$fields[] = array(
	'heading' => __( 'Youtube', 'newsy-social-counter' ),
	'id'      => 'youtube_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'youtube_name',
	'type'    => 'text',
	'default' => __( 'Youtube', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'youtube_title',
	'type'    => 'text',
	'default' => __( 'Subscribers', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'youtube_title_join',
	'type'    => 'text',
	'default' => __( 'Join us on Youtube', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'youtube_button',
	'type'    => 'text',
	'default' => __( 'Subscribe', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// Instagram
//

$fields[] = array(
	'heading' => __( 'Instagram', 'newsy-social-counter' ),
	'id'      => 'instagram_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'instagram_name',
	'type'    => 'text',
	'default' => __( 'Instagram', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'instagram_title',
	'type'    => 'text',
	'default' => __( 'Followers', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'instagram_title_join',
	'type'    => 'text',
	'default' => __( 'Join us on Instagram', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'instagram_button',
	'type'    => 'text',
	'default' => __( 'Follow Us', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// Soundcloud
//

$fields[] = array(
	'heading' => __( 'Soundcloud', 'newsy-social-counter' ),
	'id'      => 'soundcloud_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'soundcloud_name',
	'type'    => 'text',
	'default' => __( 'SoundCloud', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'soundcloud_title',
	'type'    => 'text',
	'default' => __( 'Followers', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'soundcloud_title_join',
	'type'    => 'text',
	'default' => __( 'Join us on SoundCloud', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'soundcloud_button',
	'type'    => 'text',
	'default' => __( 'Follow Us', 'newsy-social-counter' ),
	'section' => 'translation',
);


//
// Pinterest
//

$fields[] = array(
	'heading' => __( 'Pinterest', 'newsy-social-counter' ),
	'id'      => 'pinterest_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'pinterest_name',
	'type'    => 'text',
	'default' => __( 'Pinterest', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'pinterest_title',
	'type'    => 'text',
	'default' => __( 'Followers', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'pinterest_title_join',
	'type'    => 'text',
	'default' => __( 'Join us on Pinterest', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'pinterest_button',
	'type'    => 'text',
	'default' => __( 'Follow Us', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// Twitch
//
$fields[] = array(
	'heading' => __( 'Twitch', 'newsy-social-counter' ),
	'id'      => 'twitch_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'twitch_name',
	'type'    => 'text',
	'default' => __( 'Twitch', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'twitch_title',
	'type'    => 'text',
	'default' => __( 'Followers', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'twitch_title_join',
	'type'    => 'text',
	'default' => __( 'Join us on Twitch', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'twitch_button',
	'type'    => 'text',
	'default' => __( 'Follow Us', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// Steam
//
$fields[] = array(
	'heading' => __( 'Steam', 'newsy-social-counter' ),
	'id'      => 'steam_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'steam_name',
	'type'    => 'text',
	'default' => __( 'Steam', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'steam_title',
	'type'    => 'text',
	'default' => __( 'Members', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'steam_title_join',
	'type'    => 'text',
	'default' => __( 'Join us on Steam', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'steam_button',
	'type'    => 'text',
	'default' => __( 'Join Us', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// Flickr
//
$fields[] = array(
	'heading' => __( 'Flickr', 'newsy-social-counter' ),
	'id'      => 'flickr_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'flickr_name',
	'type'    => 'text',
	'default' => __( 'Flickr', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'flickr_title',
	'type'    => 'text',
	'default' => __( 'Followers', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'flickr_title_join',
	'type'    => 'text',
	'default' => __( 'Follow us on Flickr', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'flickr_button',
	'type'    => 'text',
	'default' => __( 'Follow Us', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// Foursquare
//
$fields[] = array(
	'heading' => __( 'Foursquare', 'newsy-social-counter' ),
	'id'      => 'foursquare_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'foursquare_name',
	'type'    => 'text',
	'default' => __( 'Foursquare', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'foursquare_title',
	'type'    => 'text',
	'default' => __( 'Followers', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'foursquare_title_join',
	'type'    => 'text',
	'default' => __( 'Follow us on Foursquare', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'foursquare_button',
	'type'    => 'text',
	'default' => __( 'Follow Us', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// LinkedIn
//
$fields[] = array(
	'heading' => __( 'LinkedIn', 'newsy-social-counter' ),
	'id'      => 'linkedin_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'linkedin_name',
	'type'    => 'text',
	'default' => __( 'LinkedIn', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'linkedin_title',
	'type'    => 'text',
	'default' => __( 'Followers', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'linkedin_title_join',
	'type'    => 'text',
	'default' => __( 'Follow us on LinkedIn', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'linkedin_button',
	'type'    => 'text',
	'default' => __( 'Follow Us', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// Vk
//
$fields[] = array(
	'heading' => __( 'Vk', 'newsy-social-counter' ),
	'id'      => 'vk_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'vk_name',
	'type'    => 'text',
	'default' => __( 'Vk', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'vk_title',
	'type'    => 'text',
	'default' => __( 'Members', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'vk_title_join',
	'type'    => 'text',
	'default' => __( 'Join us on Vk', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'vk_button',
	'type'    => 'text',
	'default' => __( 'Join Us', 'newsy-social-counter' ),
	'section' => 'translation',
);

//
// RSS
//

$fields[] = array(
	'heading' => __( 'RSS', 'newsy-social-counter' ),
	'id'      => 'rss_heading',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => __( 'Name', 'newsy-social-counter' ),
	'id'      => 'rss_name',
	'type'    => 'text',
	'default' => __( 'RSS', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Text Below The Number', 'newsy-social-counter' ),
	'id'      => 'rss_title',
	'type'    => 'text',
	'default' => __( 'Subscribe', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Join Text', 'newsy-social-counter' ),
	'id'      => 'rss_title_join',
	'type'    => 'text',
	'default' => __( 'Subscribe our RSS', 'newsy-social-counter' ),
	'section' => 'translation',
);
$fields[] = array(
	'heading' => __( 'Button Text', 'newsy-social-counter' ),
	'id'      => 'rss_button',
	'type'    => 'text',
	'default' => __( 'Subscribe', 'newsy-social-counter' ),
	'section' => 'translation',
);

