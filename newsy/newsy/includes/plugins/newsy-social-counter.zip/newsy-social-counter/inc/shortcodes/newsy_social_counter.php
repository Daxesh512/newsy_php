<?php
/**
 * Newsy Social Counter Shortcode
 */
class Newsy_Social_Counter_Shortcode extends NewsyElements\Shortcode\BlockAbstract {

	public function __construct( $id, $params ) {

		$_defaults = array(
			'style'        => 'style-1',
			'color_style'  => 'colored',
			'social_sites' => 'facebook,twitter,instagram,rss',
		);

		$this->defaults = array_merge( $this->defaults, $_defaults );

		parent::__construct( $id, $params );
	}

	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 *
	 * @return string
	 */
	function render_inner() {
		return newsy_social_counter_render( $this->atts['social_sites'], $this->atts['style'], $this->atts['color_style'] );
	}

	/**
	 * Visual Composer Fields Map for Shortcode
	 */
	function fields() {
		return array_merge(
			$this->block_inner_options(),
			$this->block_header_options(),
			$this->block_design_options()
		);
	}

	function block_inner_options() {
		return array(
			array(
				'heading'       => __( 'Social Sites', 'newsy-social-counter' ),
				'description'   => __( 'Select active social share links and sort them.', 'newsy-social-counter' ),
				'type'          => 'visual_checkbox',
				'id'            => 'social_sites',
				'admin_label'   => true,
				'options'       => $this->social_sites_option_list(),
				'sorter'        => true,
				'social_fields' => true,
				'return_string' => true,
				'section'       => __( 'General', 'newsy-social-counter' ),
			),
			array(
				'heading' => __( 'Style', 'newsy-social-counter' ),
				'type'    => 'select',
				'id'      => 'style',
				'options' => array(
					'style-1' => __( 'Style 1', 'newsy-social-counter' ),
					'style-2' => __( 'Style 2', 'newsy-social-counter' ),
					'style-3' => __( 'Style 3', 'newsy-social-counter' ),
					'style-4' => __( 'Style 4', 'newsy-social-counter' ),
				),
				'default' => 'style-1',
				'section' => __( 'General', 'newsy-social-counter' ),
			),
			array(
				'heading'  => __( 'Color style?', 'newsy-social-counter' ),
				'type'     => 'select',
				'id'       => 'color_style',
				'vertical' => true,
				'options'  => array(
					'colored'      => __( 'Colored', 'newsy-social-counter' ),
					'dark'         => __( 'Dark', 'newsy-social-counter' ),
					'light'        => __( 'Light', 'newsy-social-counter' ),
					'light-box'    => __( 'Light Box', 'newsy-social-counter' ),
					'light-square' => __( 'Light Square', 'newsy-social-counter' ),
					'light-circle' => __( 'Light Circle', 'newsy-social-counter' ),
				),
				'default'  => 'colored',
				'section'  => __( 'General', 'newsy-social-counter' ),
			),
		);
	}

	/**
	 * Handy callback to set all social sites list
	 *
	 * @return array
	 */
	function social_sites_option_list() {
		$sites = array(
			'facebook'   => '<i class="fa fa-facebook"></i> ' . __( 'Facebook', 'newsy-social-counter' ),
			'twitter'    => '<i class="fa fa-twitter"></i> ' . __( 'Twitter', 'newsy-social-counter' ),
			'youtube'    => '<i class="fa fa-youtube"></i> ' . __( 'Youtube', 'newsy-social-counter' ),
			'instagram'  => '<i class="fa fa-instagram"></i> ' . __( 'Instagram', 'newsy-social-counter' ),
			'soundcloud' => '<i class="fa fa-soundcloud"></i> ' . __( 'Soundcloud', 'newsy-social-counter' ),
			'pinterest'  => '<i class="fa fa-pinterest"></i> ' . __( 'Pinterest', 'newsy-social-counter' ),
			'vk'         => '<i class="fa fa-vk"></i> ' . __( 'Vk', 'newsy-social-counter' ),
			'twitch'     => '<i class="fa fa-twitch"></i> ' . __( 'Twitch', 'newsy-social-counter' ),
			'steam'      => '<i class="fa fa-steam"></i> ' . __( 'Steam', 'newsy-social-counter' ),
			'foursquare' => '<i class="fa fa-foursquare"></i> ' . __( 'Foursquare', 'newsy-social-counter' ),
			'flickr'     => '<i class="fa fa-flickr"></i> ' . __( 'Flickr', 'newsy-social-counter' ),
			'rss'        => '<i class="fa fa-rss"></i> ' . __( 'RSS', 'newsy-social-counter' ),
		);

		return $sites;
	}
}
