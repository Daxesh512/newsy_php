<?php
/**
 * Used for retrieving social data from social sites and caching them
 */
class BuzzEditor_Post_Parser {

	/**
	 * Contain live instance object class
	 *
	 * @var BuzzEditor_Post_Parser
	 */
	private static $instance;

	/**
	 * @return BuzzEditor_Post_Parser
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	public function fetch( $url ) {
		$get_request = wp_remote_get(
			$url, array(
				'timeout'   => 18,
				'sslverify' => false,
			)
		);

		$html = wp_remote_retrieve_body( $get_request );

		$result = array();
		if ( class_exists( 'DOMDocument' ) && $html ) {
			$prev = libxml_use_internal_errors( true );
			$doc  = new DOMDocument();

			$doc->loadHTML( $html );
			libxml_use_internal_errors( $prev );

			$metas = $doc->getElementsByTagName( 'meta' );

			for ( $i = 0; $i < $metas->length; $i ++ ) {

				$meta = $metas->item( $i );

				if ( $meta->getAttribute( 'name' ) === 'title' ) {
					$result['title'] = $this->parse_title( $meta->getAttribute( 'content' ) );
				}

				if ( $meta->getAttribute( 'name' ) === 'description' ) {
					$result['description'] = $this->parse_description( $meta->getAttribute( 'content' ) );
				}

				if ( $meta->getAttribute( 'property' ) === 'bf:buzzid' ) {
					$result['id'] = $meta->getAttribute( 'content' );
				}

				if ( $meta->getAttribute( 'property' ) === 'og:image' ) {
					$result['image'] = $this->parse_image( $meta->getAttribute( 'content' ) );
				}
			}

			$metas = $doc->getElementsByTagName( 'script' );
			for ( $i = 0; $i < $metas->length; $i ++ ) {
				$meta = $metas->item( $i );
				if ( $meta->getAttribute( 'type' ) === 'text/x-config' ) {
					if ( strpos( $meta->nodeValue, '"questions"' ) !== -1 ) {
						$node_data = json_decode( $meta->nodeValue, true );

						$result['data'][] = $this->parse_data( $node_data );
					}
				}
			}
		}

		return $result;
	}

	public function parse_data( $node_data ) {
		$data = array(
			'id'        => '',
			'type'      => '',
			'questions' => array(),
			'results'   => array(),
		);

		if ( isset( $node_data['subbuzz'] ) ) {
			$_data = $node_data['subbuzz'];

			$type         = $this->parse_type( $_data );
			$data['type'] = $type;
			$data['id']   = $_data['id'];

			if ( 'poll' !== $type ) {
				foreach ( $_data['results'] as $result ) {
					$_result = array(
						'id'          => isset( $result['id'] ) ? $result['id'] : '',
						'heading'     => isset( $result['header'] ) ? $this->parse_title( $result['header'] ) : '',
						'description' => isset( $result['description'] ) ? $this->parse_description( $result['description'] ) : '',
					);

					$_result = array_merge(
						$_result, $this->parse_cover( $result, 'result', 'style-1' )
					);

					if ( 'trivia' === $type || 'checklist' === $type ) {
						$_result = array_merge(
							$_result, array(
								'rangeMin' => isset( $result['range_start'] ) ? $result['range_start'] : '',
								'rangeMax' => isset( $result['range_end'] ) ? $result['range_end'] : '',
							)
						);
					}

					$data['results'][] = $_result;
				}
			}

			if ( 'checklist' === $type ) {
				$data['metadata'] = $_data['metadata'];
			}

			foreach ( $_data['questions'] as $question ) {
				$answers = array();
				foreach ( $question['answers'] as $answer ) {
					$_answer = array(
						'id'    => isset( $answer['id'] ) ? $answer['id'] : '',
						'title' => $this->parse_title( $answer['header'] ),
					);

					$_answer = array_merge(
						$_answer, $this->parse_cover( $answer, 'answer', 'style-1' )
					);

					if ( 'personality' === $type ) {
						$_answer = array_merge(
							$_answer, array(
								'result' => $data['results'][ $answer['personality_index'] ]['id'],
							)
						);
					} elseif ( 'trivia' === $type ) {
						$_answer = array_merge(
							$_answer, array(
								'result' => '0' != $answer['correct'] ? 'true' : 'false',
							)
						);
					}

					$answers[] = $_answer;
				};

				$data['questions'][ $question['id'] ] = array_merge(
					array(
						'id'          => isset( $question['id'] ) ? $question['id'] : '',
						'heading'     => isset( $question['header'] ) ? $this->parse_title( $question['header'] ) : '',
						'answers_col' => isset( $question['format'] ) ? $this->parse_answer_format( $question['format'] ) : 'col-2',
						'answers'     => $answers,
						'reveal_head' => isset( $question['reveal']['header'] ) ? $this->parse_title( $question['reveal']['header'] ) : '',
						'reveal_desc' => isset( $question['reveal']['description'] ) ? $this->parse_title( $question['reveal']['description'] ) : '',
					), $this->parse_cover( $question, 'question', 'style-1' )
				);
			}
		} elseif ( isset( $node_data['data']['content'] ) ) {
			$_data = $node_data['data']['content'];

			$type         = $this->parse_type( $_data );
			$data['type'] = $type;
			$data['id']   = isset( $node_data['context']['subbuzzId'] ) ? $node_data['context']['subbuzzId'] : uniqid();

			foreach ( $_data['results'] as $result ) {
				$r_id = isset( $result['pid'] ) ? $result['pid'] : $result['id'];

				$_result = array(
					'id'          => $r_id,
					'heading'     => isset( $result['title'] ) ? $this->parse_title( $result['title'] ) : '',
					'description' => isset( $result['description'] ) ? $this->parse_description( $result['description'] ) : '',
				);
				$_result = array_merge(
					$_result, $this->parse_cover( $result, 'result', 'style-2' )
				);

				if ( 'trivia' === $type || 'checklist' === $type ) {
					$_result = array_merge(
						$_result, array(
							'rangeMin' => isset( $result['range_start'] ) ? $result['range_start'] : '',
							'rangeMax' => isset( $result['range_end'] ) ? $result['range_end'] : '',
						)
					);
				}

				$data['results'][ $r_id ] = $_result;
			}

			foreach ( $_data['questions'] as $question ) {
				$answers   = array();
				$has_image = false;
				foreach ( $question['answers'] as $answer ) {
					$_answer = array(
						'id'     => isset( $answer['pid'] ) ? $answer['pid'] : $answer['id'],
						'title'  => $this->parse_title( $answer['text'] ),
						'result' => $answer['resultId'],
					);

					$_answer = array_merge(
						$_answer, $this->parse_cover( $answer, 'answer', 'style-2' )
					);

					$answers[] = $_answer;
					if ( ! $has_image && isset( $answer['image']['src'] ) ) {
						$has_image = true;
					}
				}
				$q_id = isset( $question['pid'] ) ? $question['pid'] : $question['id'];

				$data['questions'][ $q_id ] = array_merge(
					array(
						'id'          => $q_id,
						'heading'     => isset( $question['title'] ) ? $this->parse_title( $question['title'] ) : '',
						'answers_col' => $has_image ? 'col-2' : 'text',
						'answers'     => $answers,
						'reveal_head' => isset( $question['reveal']['title'] ) ? $this->parse_title( $question['reveal']['title'] ) : '',
						'reveal_desc' => isset( $question['reveal']['description'] ) ? $this->parse_title( $question['reveal']['description'] ) : '',
					), $this->parse_cover( $question, 'question', 'style-2' )
				);
			}
		} elseif ( isset( $node_data['data'] ) ) {
			$_data = $node_data['data'];

			$type         = $this->parse_type( $_data );
			$data['type'] = $type;
			$data['id']   = isset( $node_data['context']['subbuzzId'] ) ? $node_data['context']['subbuzzId'] : uniqid();

			foreach ( $_data['results'] as $result ) {
				$r_id = isset( $result['id'] ) ? $result['id'] : uniqid();

				$_result = array(
					'id'          => $r_id,
					'heading'     => isset( $result['title'] ) ? $this->parse_title( $result['title'] ) : '',
					'description' => isset( $result['description'] ) ? $this->parse_description( $result['description'] ) : '',
				);

				$_result = array_merge(
					$_result, $this->parse_cover( $result, 'result', 'style-3' )
				);

				if ( 'trivia' === $type || 'checklist' === $type ) {
					$_result = array_merge(
						$_result, array(
							'rangeMin' => isset( $result['score_min'] ) ? $result['score_min'] : '',
							'rangeMax' => isset( $result['score_max'] ) ? $result['score_max'] : '',
						)
					);
				}

				$data['results'][ $r_id ] = $_result;
			}

			foreach ( $_data['questions'] as $question ) {
				$answers = array();
				foreach ( $question['answers'] as $answer ) {
					$_answer = array(
						'id'    => isset( $answer['id'] ) ? $answer['id'] : uniqid(),
						'title' => $this->parse_title( $answer['text'] ),
					);

					$_answer = array_merge(
						$_answer, $this->parse_cover( $answer, 'answer', 'style-3' )
					);

					if ( 'personality' === $type ) {
						$_answer = array_merge(
							$_answer, array(
								'result' => $data['results'][ reset( $answer['result_ids'] ) ]['id'],
							)
						);
					} elseif ( 'trivia' === $type ) {
						$_answer = array_merge(
							$_answer, array(
								'result' => $answer['correct'] ? 'true' : 'false',
							)
						);
					}
					$answers[] = $_answer;
				}
				$q_id = isset( $question['id'] ) ? $question['id'] : uniqid();

				$data['questions'][ $q_id ] = array_merge(
					array(
						'id'          => $q_id,
						'heading'     => isset( $question['title'] ) ? $this->parse_title( $question['title'] ) : '',
						'answers'     => $answers,
						'answers_col' => isset( $question['format'] ) ? $this->parse_answer_format( $question['format'] ) : 'col-2',
						'reveal_head' => isset( $question['reveal']['title'] ) ? $this->parse_title( $question['reveal']['title'] ) : '',
						'reveal_desc' => isset( $question['reveal']['description'] ) ? $this->parse_description( $question['reveal']['description'] ) : '',
					), $this->parse_cover( $question, 'question', 'style-3' )
				);
			}
		}

		return $data;
	}

	public function parse_cover( $item, $type, $style ) {
		$cover_overlay_bg  = '';
		$default_text_size = 'answer' === $type ? 36 : 56;
		if ( 'style-1' === $style ) {
			$title               = isset( $item['header'] ) ? $this->parse_title( $item['header'] ) : '';
			$image               = isset( $item['image'] ) ? $this->parse_image( $item['image'] ) : '';
			$image_alt           = isset( $item['alt_text'] ) ? $this->parse_description( $item['alt_text'] ) : '';
			$image_credit        = isset( $item['attribution'] ) ? $this->parse_title( $item['attribution'] ) : '';
			$image_height        = isset( $item['image_height'] ) ? $this->parse_image_height( $item['image_width'], $item['image_height'] ) : '275';
			$cover_overlay       = isset( $item['tile_metadata']['overlayText'] ) ? $item['tile_metadata']['overlayText'] : false;
			$cover_text          = isset( $item['tile_metadata']['tileText'] ) ? $this->parse_title( $item['tile_metadata']['tileText'] ) : '';
			$cover_text_size     = isset( $item['tile_metadata']['tileStyles']['fontSize'] ) ? $item['tile_metadata']['tileStyles']['fontSize'] : $default_text_size;
			$cover_overlay_color = isset( $item['tile_metadata']['tileStyles']['backgroundColor'] ) ? $item['tile_metadata']['tileStyles']['backgroundColor'] : '';
			$cover_text_color    = isset( $item['tile_metadata']['tileStyles']['color'] ) ? $item['tile_metadata']['tileStyles']['color'] : '';

			if ( isset( $item['tile_metadata']['tileStyles']['backgroundImage'] ) ) {
				$cover_overlay_bg = 'https://img.buzzfeed.com/buzzfeed-static' . $item['tile_metadata']['tileStyles']['backgroundImage']['url'];
				$image_height     = $this->parse_image_height( $item['tile_metadata']['tileStyles']['backgroundImage']['width'], $item['tile_metadata']['tileStyles']['backgroundImage']['height'] );
			}
		} elseif ( 'style-2' === $style ) {
			$title               = isset( $item['text'] ) ? $this->parse_title( $item['text'] ) : '';
			$image               = isset( $item['image']['src'] ) ? $this->parse_image( $item['image']['src'] ) : '';
			$image_alt           = isset( $item['image']['alt'] ) ? $this->parse_description( $item['image']['alt'] ) : '';
			$image_credit        = isset( $item['image']['credit'] ) ? $this->parse_description( $item['image']['credit'] ) : '';
			$image_height        = isset( $item['image']['meta']['height'] ) ? $this->parse_image_height( $item['image']['meta']['width'], $item['image']['meta']['height'] ) : '250';
			$cover_overlay       = isset( $item['tile_metadata']['overlay_text'] ) ? $item['tile_metadata']['overlay_text'] : false;
			$cover_text          = isset( $item['tile_metadata']['tile_text'] ) ? $this->parse_title( $item['tile_metadata']['tile_text'] ) : '';
			$cover_text_size     = isset( $item['tile_metadata']['tile_styles']['font_size'] ) ? $item['tile_metadata']['tile_styles']['font_size'] : $default_text_size;
			$cover_overlay_color = isset( $item['color'] ) ? $item['color'] : '';
			$cover_text_color    = '';

		} elseif ( 'style-3' === $style ) {
			$media = isset( $item['tile_metadata']['tile_styles']['media'] ) ? $item['tile_metadata']['tile_styles']['media'] : $item['media'];

			$text                = isset( $item['text'] ) ? $this->parse_title( $item['text'] ) : '';
			$title               = ! empty( $item['title'] ) ? $this->parse_title( $item['title'] ) : $text;
			$image               = isset( $media['url'] ) ? $this->parse_image( $media['url'] ) : '';
			$image_alt           = isset( $media['alt_text'] ) ? $this->parse_description( $media['alt_text'] ) : '';
			$image_credit        = isset( $media['credit'] ) ? $this->parse_description( $media['credit'] ) : '';
			$image_height        = isset( $media['meta']['height'] ) ? $this->parse_image_height( $media['meta']['width'], $media['meta']['height'] ) : '250';
			$cover_overlay       = isset( $item['tile_metadata']['overlay_text'] ) ? $item['tile_metadata']['overlay_text'] : false;
			$cover_text          = isset( $item['tile_metadata']['tile_text'] ) ? $this->parse_title( $item['tile_metadata']['tile_text'] ) : '';
			$cover_text_size     = isset( $item['tile_metadata']['tile_styles']['font_size'] ) ? $item['tile_metadata']['tile_styles']['font_size'] : $default_text_size;
			$cover_overlay_color = isset( $item['tile_metadata']['tile_styles']['background_color'] ) ? $item['tile_metadata']['tile_styles']['background_color'] : '';
			$cover_text_color    = isset( $item['tile_metadata']['tile_styles']['color'] ) ? $item['tile_metadata']['tile_styles']['color'] : '';

			if ( isset( $item['tile_metadata']['tile_styles']['media'] ) ) {
				$cover_overlay_bg = $item['tile_metadata']['tile_styles']['media']['url'];
				$image_height     = $this->parse_image_height( $item['tile_metadata']['tile_styles']['meta']['width'], $item['tile_metadata']['tile_styles']['meta']['height'] );
			}
		} else {
			return array();
		}

		if ( $cover_overlay ) {
			$cover = array(
				'image'               => $cover_overlay_bg,
				'image_alt'           => '',
				'image_credit'        => '',
				'image_height'        => 'answer' === $type ? 'answer' : $image_height,
				'cover_overlay'       => true,
				'cover_text'          => $cover_text,
				'cover_text_size'     => $cover_text_size,
				'cover_overlay_color' => $cover_overlay_color,
				'cover_text_color'    => $cover_text_color,
			);

			if ( empty( $cover_text ) ) {
				$cover = array_merge(
					$cover, array(
						'heading'    => '',
						'title'      => '',
						'cover_text' => $title,
					)
				);
			}
		} else {
			$cover = array(
				'image'               => $image,
				'image_alt'           => $image_alt,
				'image_credit'        => $image_credit,
				'image_height'        => 'answer' === $type ? 'answer' : $image_height,
				'cover_overlay'       => false,
				'cover_text'          => '',
				'cover_text_size'     => '',
				'cover_overlay_color' => '',
				'cover_text_color'    => '',
			);
		}

		return $cover;
	}


	public function parse_title( $title ) {
		return str_replace(
			array(
				'’',
				'"',
				'\\',
			), array(
				"'",
				"'",
				'',
			), strip_tags( $title )
		);
	}

	public function parse_description( $description ) {
		return strip_tags( $description );
	}

	public function parse_image_height( $width, $height ) {
		return $width > 900 ? intval( $height ) / 1.4 : $height;
	}

	public function parse_type( $_data ) {
		$type = isset( $_data['type'] ) ? $_data['type'] : 'personality';

		if ( 'standard' === $type ) {
			return 'trivia';
		}

		return $type;
	}


	public function parse_image( $image ) {
		if ( strpos( $image, 'unsplash' ) !== false ) {
			return $image . '&fit=crop&w=1400&q=80';
		}

		$img = explode( '?', $image );

		return $img[0];
	}

	public function parse_answer_format( $format ) {
		if ( '2-UP' === $format ) {
			return 'col-2';
		} elseif ( '3-UP' === $format ) {
			return 'col-3';
		}

		return 'text';
	}
}
