<?php
/**
 * Used for retrieving social data from social sites and caching them
 */
class BuzzEditor_Post_Importer {

	/**
	 * Contain live instance object class
	 *
	 * @var BuzzEditor_Post_Importer
	 */
	private static $instance;


	/**
	 * @return BuzzEditor_Post_Importer
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * Build
	 *
	 * @param array $urls
	 * @param string $pack
	 * @return mixed
	 */
	public function run( $urls, $args = array() ) {
		$demo    = array(
			'media' => array(),
			'post'  => array(),
		);
		$parser  = BuzzEditor_Post_Parser::get_instance();
		$builder = BuzzEditor_Post_Builder::get_instance();

		foreach ( $urls as $url ) {
			$result = $parser->fetch( $url );

			if ( ! isset( $result['data'] ) && empty( $result['data'] ) ) {
				wp_send_json( $result );
			}

			$id          = $result['id'];
			$title       = $result['title'];
			$description = $result['description'];
			$data        = $result['data'];

			// add preview image to tree
			$demo['media'] = $this->build_media( $result );

			$post_template = $builder->run( $data );

			$demo['post'][] = array_merge(
				array(
					'the_ID'            => 'ak-post-' . $id,
					'post_title'        => $title,
					'post_excerpt'      => $description,
					'post_content_file' => $this->generate_content_file( 'post-' . $id . '-content.txt', $post_template ),
					'thumbnail_id'      => '%%ak-quiz-post-' . $id . '%%',
					'post_format'       => 'post',
					'post_date'         => '-1 months',
				), $args
			);
		}

		return $demo;
	}

	/**
	 * Undocumented function
	 *
	 * @param [type] $id
	 * @param [type] $questions
	 * @param [type] $results
	 * @return array
	 */
	public function build_media( $result ) {
		$id    = $result['id'];
		$image = $result['image'];
		$data  = $result['data'];
		$media = array();

		$media[] = $this->maybe_fetch_image(
			array(
				'the_ID' => 'ak-quiz-post-' . $id,
				'file'   => $image,
			), $id
		);

		foreach ( $data as $_data ) {
			$id        = $_data['id'];
			$questions = $_data['questions'];
			$results   = $_data['results'];

			if ( $questions ) {
				foreach ( $questions as $question ) {
					if ( ! empty( $question['image'] ) ) {
						$media[] = $this->maybe_fetch_image(
							array(
								'the_ID' => 'ak-quiz-post-' . $id . '-q' . $question['id'],
								'file'   => $question['image'],
							), $id
						);
					}

					if ( $question['answers'] ) {
						foreach ( $question['answers'] as $answer ) {
							if ( ! empty( $answer['image'] ) ) {
								$media[] = $this->maybe_fetch_image(
									array(
										'the_ID' => 'ak-quiz-post-' . $id . '-q' . $question['id'] . '-a' . $answer['id'],
										'file'   => $answer['image'],
									), $id
								);
							}
						}
					}
				}
			}

			if ( $results ) {
				foreach ( $results as $result ) {
					if ( ! empty( $result['image'] ) ) {
						$media[] = $this->maybe_fetch_image(
							array(
								'the_ID' => 'ak-quiz-post-' . $id . '-r' . $result['id'],
								'file'   => $result['image'],
							), $id
						);
					}
				}
			}
		}

		return $media;
	}

	public function maybe_fetch_image( $media, $post_id ) {
			return $media;
	}

	public function generate_content_file( $filename, $content ) {
		global $wp_filesystem;

		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . '/wp-admin/includes/file.php';

			WP_Filesystem();
		}

		$wp_upload_dir = wp_upload_dir();
		$path          = '/ak_framework/tmp/post_content';
		$basedir       = $wp_upload_dir['basedir'] . $path;
		$baseurl       = $wp_upload_dir['baseurl'] . $path;

		if ( ! is_dir( $basedir ) ) {
			if ( ! wp_mkdir_p( $basedir ) ) {
				return false;
			}
		}

		if ( $wp_filesystem->put_contents( $basedir . '/' . $filename, $content, 0777 ) ) {
			return $basedir . '/' . $filename;
		}

		return false;
	}
}
