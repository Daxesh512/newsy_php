<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Class BuzzEditor Post Importer Hooks
 */
class BuzzEditor_Post_Importer_Hooks {

	/**
	 * @var BuzzEditor_Post_Importer_Hooks
	 */
	private static $instance;

	/**
	 * @return BuzzEditor_Post_Importer_Hooks
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * BuzzEditor_Post_Importer_Hooks constructor.
	 */
	private function __construct() {
		add_action( 'ak-framework/setup/after', array( $this, 'setup' ), 111 );
		add_filter( 'ak-framework/product/pages', array( $this, 'register_product_pages' ), 11 );
	}

	public function setup() {
		require_once BUZZEDITOR_POST_IMPORTER_PATH . 'class.buzzeditor-post-importer-panel.php';
		require_once BUZZEDITOR_POST_IMPORTER_PATH . 'class.buzzeditor-post-importer.php';
		require_once BUZZEDITOR_POST_IMPORTER_PATH . 'class.buzzeditor-post-builder.php';
		require_once BUZZEDITOR_POST_IMPORTER_PATH . 'class.buzzeditor-post-parser.php';
	}

	public function register_product_pages( $pages ) {
		$pages['buzzeditor-post-importer'] = array(
			'product'    => 'newsy',
			'page_title' => __( 'BuzzEditor Post Importer', 'buzzeditor-post-importer' ),
			'capability' => 'manage_options',
			'module'     => 'BuzzEditor_Post_Importer_Panel',
			'hide_tab'   => true,
			'position'   => 120,
			'config'     => array(
				'panel_title' => __( 'BuzzEditor Post Importer', 'buzzeditor-post-importer' ),
			),
		);

		return $pages;
	}
}
