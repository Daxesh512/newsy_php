<?php

use Ak\Form\FormBuilder;
use Ak\Importer\ImporterManager;

class BuzzEditor_Post_Importer_Panel extends Ak\Product\Panel\ProductPanelAbstract {

	public $id = 'post-importer';

	public function enqueue() {
		wp_enqueue_style( 'buzzeditor-post-importer-panel', BUZZEDITOR_POST_IMPORTER_URI . 'css/panel.css', array(), BUZZEDITOR_POST_IMPORTER_VERSION );
		wp_enqueue_script( 'buzzeditor-post-importer-panel', BUZZEDITOR_POST_IMPORTER_URI . 'js/panel.js', array( 'jquery', 'sweetalert', 'wp-i18n' ), BUZZEDITOR_POST_IMPORTER_VERSION, true );
		wp_set_script_translations( 'buzzeditor-post-importer-panel', 'buzzeditor-post-importer', BUZZEDITOR_POST_IMPORTER_PATH . 'languages/' );
	}

	public function render_content() {
		?>
		<div class="ak_user_import_post_form">
			<div class="ak-activate-wrap">
				<form action="" id="ak-post-import-form" onsubmit="return false">
					<?php
					echo FormBuilder::render_field(
						array(
							'heading'     => __( 'URL to Buzzfeed Post', 'buzzeditor-post-importer' ),
							'description' => __( 'Add full URL to Buzzfeed quiz, poll posts. Note: This import system may not work with some posts, or you may need to manually edit some parts of the imported post.', 'buzzeditor-post-importer' ),
							'input_desc'  => '<a href="https://www.buzzfeed.com/tinablech/valentines-day-is-a-coming" target=_blank>Personality Quiz Example</a> - <a href="https://www.buzzfeed.com/eeerin/can-you-guess-the-population-of-these-countries-3407t" target=_blank>Trivia Quiz Examle</a> - <a href="https://www.buzzfeed.com/morgansloss1/fruity-desserts-poll-quiz" target=_blank>Poll Example</a>',
							'id'          => 'url',
							'type'        => 'text',
						), false
					);
					echo FormBuilder::render_field(
						array(
							'heading'          => __( 'Post Category', 'buzzeditor-post-importer' ),
							'description'      => __( 'Select categories for the post. You can select multiple categories for the post', 'buzzeditor-post-importer' ),
							'id'               => 'category',
							'type'             => 'select',
							'multiple'         => 500,
							'return_string'    => true,
							'options_callback' => 'Ak\Form\FormCallback::get_categories',
						), false
					);
					echo FormBuilder::render_field(
						array(
							'heading'       => __( 'Post Author', 'buzzeditor-post-importer' ),
							'description'   => __( 'Select author for the post. You can leave empty for random user', 'buzzeditor-post-importer' ),
							'id'            => 'user',
							'type'          => 'ajax_select',
							'max_items'     => 1,
							'return_string' => true,
							'ajax_callback' => 'Ak\Form\FormCallback::get_users',
						), false
					);
					?>
					<div class="ak-form-button-wrap">
					<button class="ak-btn ak-primary-btn ak-fetch-post-button"><?php esc_html_e( 'Import Post', 'buzzeditor-post-importer' ); ?></button>
					</div>
				</form>
			</div>
		</div>
		<?php
		$group_data = array_reverse( $this->get_imported_posts() );

		if ( ! empty( $group_data ) ) :
			?>
		<table class="ak_user_imported_posts">
			<thead class="thread_header">
				<tr>
					<th class="thread-body-header">
					<?php _e( 'Post', 'buzzeditor-post-importer' ); ?>
					</th>
					<th class="thread-date-header">
					<?php _e( 'Post Date', 'buzzeditor-post-importer' ); ?>
					</th>
					<th><?php _e( 'Actions', 'buzzeditor-post-importer' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php

			foreach ( $group_data as $key => $data ) {
				$title = '';
				$date  = '';
				$link  = '';
				if ( isset( $data['post'] ) ) {
					$title = get_the_title( end( $data['post'] ) );
					$date  = get_the_date( 'l F j, Y', end( $data['post'] ) );
					$link  = get_permalink( end( $data['post'] ) );
				}
				?>
				<tr class="thread ">
					<td class="thread-body">
						<div class="thread-heading">
							<a href="<?php echo esc_url( $link ); ?>" target="_blank">
								<?php echo esc_html( $title ); ?>
							</a>
						</div>
						<p><?php echo esc_html( $key ); ?></p>
					</td>
					<td class="thread-date"><?php echo esc_html( $date ); ?></td>
					<td class="thread-actions">
						<a href="javascript:void(0)" class="ak-btn ak-primary-btn ak-delete-post-button" data-id="<?php echo esc_attr( $key ); ?>"><?php _e( 'Delete', 'buzzeditor-post-importer' ); ?></a>
					</td>
				</tr>
				<?php

			}
			?>
			</tbody>
		</table>
			<?php
		endif;
	}

	private function get_imported_posts() {
		return ImporterManager::get_instance()->get_group_data( 'buzzeditor-post-importer' );
	}

	public function ajax_request() {
		if ( ! isset( $_POST['page_action'] ) || ! isset( $_REQUEST['data'] ) ) {
			return false;
		}

		$response = false;

		try {
			switch ( $_POST['page_action'] ) {
				case 'fetch':
					$args = ak_parse_str( ltrim( rtrim( stripslashes( $_REQUEST['data'] ), '&' ), '&' ) );

					if ( empty( $args['url'] ) || empty( $args['category'] ) ) {
						return new \WP_Error( 'error', __( 'Please add valid info!', 'buzzeditor-post-importer' ) );
					}

					$importer    = BuzzEditor_Post_Importer::get_instance();
					$import_data = $importer->run(
						array(
							$args['url'],
						),
						array(
							'post_terms'  => array(
								'category' => $args['category'],
							),
							'post_author' => ! empty( $args['user'] ) ? $args['user'] : 'random',
						)
					);

					$response = $import_data;
					break;
				case 'import':
					if ( ! isset( $_POST['data']['import_data'] ) ) {
						return false;
					}
					$import_data = $_POST['data']['import_data'];

					$importer = ImporterManager::get_instance();
					$importer->set_import_group( 'buzzeditor-post-importer' );
					$importer->set_import_id( $import_data['post'][0]['the_ID'] );

					$response = $importer->get_steps(
						array(
							'import_status' => 'install',
							'import_clear'  => false,
						), $import_data
					);
					break;
				case 'delete':
					if ( ! isset( $_POST['data']['import_id'] ) ) {
						return false;
					}
					$import_id = $_POST['data']['import_id'];

					$importer = ImporterManager::get_instance();
					$importer->set_import_group( 'buzzeditor-post-importer' );
					$importer->set_import_id( $import_id );

					$response = $importer->get_steps(
						array(
							'import_status' => 'uninstall',
							'import_clear'  => false,
						)
					);
					break;
			}
		} catch ( \Exception $e ) {
			$response = new \WP_Error( $e->getCode(), $e->getMessage() );
		}

		return $response;
	}
}
