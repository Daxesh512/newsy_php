<?php

use Ak\Customizer\Control\ControlAbstract;

class PartBuilderCustomizer extends ControlAbstract {
	public $_type = 'part_builder';

		/**
	 * Enqueue control related scripts/styles.
	*/
	public function enqueue() {
		parent::enqueue();
		wp_enqueue_style( 'ak-customizer-control-part-builder', NEWSY_CUSTOMIZER_URI . '/css/part-builder-customizer.css', null, null );
	}
}
