<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Newsy Customizer Hooks
 */
class Newsy_Customizer_Hooks {

	/**
	 * @var Newsy_Customizer_Hooks
	 */
	private static $instance;

	/**
	 * @return Newsy_Customizer_Hooks
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * Newsy_Voting_Hooks constructor.
	 */
	public function __construct() {
		add_filter( 'ak-framework/customizer/field/before', array( $this, 'customizer_field' ), 11 );

		add_filter( 'newsy_layout_fields', array( $this, 'layout_fields' ), 10, 3 );
		add_filter( 'newsy_grid_fields', array( $this, 'grid_fields' ), 10, 3 );
		add_filter( 'newsy_list_fields', array( $this, 'list_fields' ), 10, 3 );
		add_filter( 'newsy_builder_row_column_fields', array( $this, 'builder_row_fields' ), 10, 3 );
	}

	public function customizer_field( $field ) {
		switch ( $field['id'] ) {
			case 'builder_header_desktop':
				$field['partial_refresh'] = array(
					'builder_header_desktop' => array(
						'selector'        => '.ak-header-wrap .ak-container',
						'render_callback' => array(
							'function' => 'get_template_part',
							'args'     => 'views/builder/header-builder',
						),
					),
				);
				break;
			case 'builder_header_mobile':
				$field['partial_refresh'] = array(
					'builder_header_mobile' => array(
						'selector'        => '.ak-header-mobile-wrap .ak-container',
						'render_callback' => array(
							'function' => 'get_template_part',
							'args'     => 'views/builder/mobile-builder',
						),
					),
				);
				break;
			case 'builder_header_sticky':
				$field['partial_refresh'] = array(
					'builder_header_sticky' => array(
						'selector'        => '.ak-header-sticky-wrap .ak-container',
						'render_callback' => array(
							'function' => 'get_template_part',
							'args'     => 'views/builder/sticky-builder',
						),
					),
				);
				break;
			case 'builder_footer':
				$field['partial_refresh'] = array(
					'builder_footer' => array(
						'selector'        => '.ak-footer-wrap .ak-container',
						'render_callback' => array(
							'function' => 'get_template_part',
							'args'     => 'views/builder/footer-builder',
						),
					),
				);
				break;
			case 'builder_post_sticky':
				$field['partial_refresh'] = array(
					'builder_post_sticky' => array(
						'selector'        => '.ak-post-sticky-wrap .ak-container',
						'render_callback' => array(
							'function' => 'get_template_part',
							'args'     => 'views/builder/post-sticky-builder',
						),
					),
				);
				break;
			case 'logo_type':
			case 'logo_text':
			case 'logo_image':
			case 'logo2x_image':
			case 'logo_dark_image':
			case 'logo2x_dark_image':
				$field['partial_refresh'] = array(
					$field['id'] => array(
						'selector'        => '.ak-logo-main a',
						'render_callback' => array(
							'function' => 'newsy_generate_logo',
							'args'     => array( '' ),
						),
					),
				);
				break;
			case 'mobile_logo_type':
			case 'mobile_logo_text':
			case 'mobile_logo_image':
			case 'mobile_logo2x_image':
			case 'mobile_logo_dark_image':
			case 'mobile_logo2x_dark_image':
				$field['partial_refresh'] = array(
					$field['id'] => array(
						'selector'        => '.ak-logo-mobile a',
						'render_callback' => array(
							'function' => 'newsy_generate_logo',
							'args'     => array( 'mobile' ),
						),
					),
				);
				break;
			case 'sticky_logo_type':
			case 'sticky_logo_text':
			case 'sticky_logo_image':
			case 'sticky_logo2x_image':
			case 'sticky_logo_dark_image':
			case 'sticky_logo2x_dark_image':
				$field['partial_refresh'] = array(
					$field['id'] => array(
						'selector'        => '.ak-logo-sticky a',
						'render_callback' => array(
							'function' => 'newsy_generate_logo',
							'args'     => array( 'sticky' ),
						),
					),
				);
				break;
			case 'footer_logo_type':
			case 'footer_logo_text':
			case 'footer_logo_image':
			case 'footer_logo2x_image':
			case 'footer_logo_dark_image':
			case 'footer_logo2x_dark_image':
				$field['partial_refresh'] = array(
					$field['id'] => array(
						'selector'        => '.ak-logo-footer a',
						'render_callback' => array(
							'function' => 'newsy_generate_logo',
							'args'     => array( 'footer' ),
						),
					),
				);
				break;
			default:
				if ( substr( $field['id'], 0, 5 ) === 'post_' ) {
					$field['js_vars'] = array(
						$field['id'] => array(
							'redirect' => 'post',
							'refresh'  => true,
						),
					);
				}
				break;

		}

		return $field;
	}

	public function layout_fields( $fields, $template, $body_class ) {
		foreach ( $fields as $key => $field ) {
			if ( in_array(
				$field['id'],
				array(
					$template . 'layout',
					$template . 'primary_sidebar',
					$template . 'secondary_sidebar',
					$template . 'sidebar_content_gap',
				),
				true
			) ) {
				$fields[ $key ]['js_vars'] = array(
					array(
						'redirect' => 'site_' === $template ? 'category' : rtrim( $template, '_' ),
						'refresh'  => true,
					),
				);
			}
		}

		$fields = $this->field_merge_output(
			$fields, $template . 'layout_style', array(
				'output' => array(
					array(
						'type'     => 'class-masking',
						'element'  => $body_class,
						'property' => array(
							'full-width'    => 'full-width',
							'boxed'         => 'boxed',
							'content-boxed' => 'content-boxed',
						),
					),
				),
			)
		);

		return $fields;
	}

	public function grid_fields( $fields, $template, $section ) {
		foreach ( $fields as $key => $field ) {
			if ( $template . 'grid_gradient' !== $field['id'] ) {
				$fields[ $key ]['js_vars'] = array(
					array(
						'redirect' => 'site_' === $template ? 'category' : rtrim( $template, '_' ),
						'refresh'  => true,
					),
				);
			}
		}

		$fields = $this->field_merge_output(
			$fields, $template . 'grid_gradient', array(
				'output' => array(
					array(
						'type'     => 'class-masking',
						'element'  => '.archive .ak-block-grid',
						'property' => array(
							'tg-gradient'                 => 'tg-gradient',
							'tg-center'                   => 'tg-center',
							'tg-center-left'              => 'tg-center-left',
							'tg-focus'                    => 'tg-focus',
							'tg-gradient tg-focus'        => 'tg-gradient tg-focus',
							'tg-focus tg-center'          => 'tg-focus tg-center',
							'tg-focus tg-center-left'     => 'tg-focus tg-center-left',
							'tg-colored'                  => 'tg-colored',
							'tg-colored tg-focus'         => 'tg-colored tg-focus',
							'tg-colored tg-center'        => 'tg-colored tg-center',
							'tg-colored tg-center tg-focus' => 'tg-colored tg-center tg-focus',
							'tg-colored tg-center-left'   => 'tg-colored tg-center-left',
							'tg-colored tg-center-left tg-focus' => 'tg-colored tg-center-left tg-focus',
							'tg-colored-single'           => 'tg-colored-single',
							'tg-colored-single tg-focus'  => 'tg-colored-single tg-focus',
							'tg-box'                      => 'tg-box',
							'tg-box tg-focus'             => 'tg-box tg-focus',
							'tg-box tg-center'            => 'tg-box tg-center',
							'tg-box tg-center tg-focus'   => 'tg-box tg-center tg-focus',
							'tg-highlight'                => 'tg-highlight',
							'tg-highlight tg-focus'       => 'tg-highlight tg-focus',
							'tg-highlight tg-center'      => 'tg-highlight tg-center',
							'tg-highlight tg-center tg-focus' => 'tg-highlight tg-center tg-focus',
							'tg-highlight tg-center-left' => 'tg-highlight tg-center-left',
							'tg-highlight tg-center-left tg-focus' => 'tg-highlight tg-center-left tg-focus',
						),
					),
				),
			)
		);

		return $fields;
	}


	public function list_fields( $fields, $template, $section ) {
		foreach ( $fields as $key => $field ) {
				$fields[ $key ]['js_vars'] = array(
					array(
						'redirect' => 'site_' === $template ? 'category' : rtrim( $template, '_' ),
						'refresh'  => true,
					),
				);
		}

		return $fields;
	}

	public function builder_row_fields( $fields, $row, $column ) {
		$fields = $this->field_merge_output(
			$fields, 'layout', array(
				'output' => array(
					array(
						'type'     => 'class-masking',
						'element'  => ".ak-{$row}-bar .ak-column-{$column}",
						'property' => array(
							'grow'   => 'ak-column-grow',
							'normal' => 'ak-column-normal',
						),
					),
				),
			)
		);
		$fields = $this->field_merge_output(
			$fields, 'layout', array(
				'output' => array(
					array(
						'type'     => 'class-masking',
						'element'  => ".ak-{$row}-bar .ak-column-{$column} .ak-inner-row",
						'property' => array(
							'left'   => 'ak-justify-content-left',
							'center' => 'ak-justify-content-center',
							'right'  => 'ak-justify-content-right',
						),
					),
				),
			)
		);

		return $fields;
	}

	/**
	 * @param $fields
	 * @param $template
	 * @param $args
	 *
	 * @return mixed
	 */
	private function field_merge_output( $array, $search, $merge ) {
		foreach ( $array as $key => $value ) {
			if ( $search === $value['id'] ) {
				foreach ( $merge as $m_key => $m_value ) {
					if ( isset( $array[ $key ][ $m_key ] ) ) {
						$array[ $key ][ $m_key ] = array_merge( $array[ $key ][ $m_key ], $m_value );
					} else {
						$array[ $key ] = array_merge( $array[ $key ], $merge );
					}
				}
				return $array;
				break;
			}
		}

		return $array;
	}
}
