<?php
/*
Plugin Name: Newsy Customizer
Plugin URI: http://akbilisim.com
Description: Newsy Customizer is a plugin that allows you to use theme options in WordPress Customizer..
Version: 1.0.0
Author: akbilisim
Author URI: http://akbilisim.com
License: GPL2
*/

defined( 'NEWSY_CUSTOMIZER_URI' ) or define( 'NEWSY_CUSTOMIZER_URI', plugins_url( 'newsy-customizer' ) );
defined( 'NEWSY_CUSTOMIZER_PATH' ) or define( 'NEWSY_CUSTOMIZER_PATH', plugin_dir_path( __FILE__ ) );

if ( ! function_exists( 'newsy_customizer_load' ) ) {
	function newsy_customizer_load() {
		require_once NEWSY_CUSTOMIZER_PATH . '/class.newsy-customizer-hooks.php';
		Newsy_Customizer_Hooks::get_instance();
		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( 'newsy-customizer', false, basename( __DIR__ ) . '/languages/' );
	}
}

add_action( 'plugins_loaded', 'newsy_customizer_load' );

if ( ! function_exists( 'newsy_register_customizer_fields' ) ) {
	/**
	 * Register the Newsy option fields to framework.
	 *
	 * @return array
	 */
	function newsy_register_customizer_fields( $fields ) {
		$fields[ NEWSY_THEME_OPTIONS ] = array(
			'option_name' => NEWSY_THEME_OPTIONS,
			'option_type' => 'option',
			'file'        => NEWSY_CUSTOMIZER_PATH . 'includes/customizer-options.php',
		);

		return $fields;
	}
}

add_filter( 'ak-framework/customizer', 'newsy_register_customizer_fields', 11 );


if ( ! function_exists( 'newsy_custom_customizer_controls' ) ) {
	/**
	 * Register the Newsy part builder fields to framework.
	 *
	 * @return array
	 */
	function newsy_custom_customizer_controls( $controls ) {
		if ( ! class_exists( 'PartBuilderCustomizer' ) ) {
			require_once 'class.customizer-part-builder.php';
		}

		$controls['part_builder'] = 'PartBuilderCustomizer';

		return $controls;
	}
}

add_filter( 'ak-framework/customizer/controls', 'newsy_custom_customizer_controls', 11 );
