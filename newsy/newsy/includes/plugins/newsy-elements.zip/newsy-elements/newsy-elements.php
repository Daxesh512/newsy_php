<?php

/*
Plugin Name: Newsy Elements
Plugin URI: http://akbilisim.com
Description: Newsy Widgets and Shortcodes for WPBakery Page Builder and Elementor.
Version: 1.5.0
Author: akbilisim
Author URI: http://akbilisim.com
License: GPL2
*/

defined( 'NEWSY_ELEMENTS' ) or define( 'NEWSY_ELEMENTS', 'newsy-elements' );
defined( 'NEWSY_ELEMENTS_URI' ) or define( 'NEWSY_ELEMENTS_URI', plugins_url( NEWSY_ELEMENTS ) );
defined( 'NEWSY_ELEMENTS_PATH' ) or define( 'NEWSY_ELEMENTS_PATH', plugin_dir_path( __FILE__ ) );
defined( 'NEWSY_ELEMENTS_VERSION' ) or define( 'NEWSY_ELEMENTS_VERSION', '1.5.0' );

require NEWSY_ELEMENTS_PATH . 'class/autoload.php';

NewsyElements\Init::get_instance();
