<?php

namespace NewsyElements\Shortcode\Grid;

use NewsyElements\Module\Module_Grid_Big;

/**
 * Newsy Grid 9.
 */
class Grid_9 extends GridAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['count']       = '1';
		$this->defaults['grid_height'] = '500';
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$column_number = $atts['block_width'];

		$module_atts = array();

		if ( 3 === $column_number ) {
			$module_atts['image-size'] = 'newsy_1140x570';
		}

		$post_count = 0;

		$buffy = '';
		foreach ( $query_posts as $post ) {
			$post_count++;

			$the_post = new Module_Grid_Big( $post, $module_atts );
			$buffy   .= $the_post->display( $post_count );
		}

		unset( $module_atts, $query_posts );

		return $buffy;
	}

}
