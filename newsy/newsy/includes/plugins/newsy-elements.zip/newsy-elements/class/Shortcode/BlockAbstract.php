<?php
namespace NewsyElements\Shortcode;

use Ak\Shortcode\ShortcodeAbstract;

/**
 * Newsy Block Abstract class.
 */
abstract class BlockAbstract extends ShortcodeAbstract {

	public function __construct( $id, $params ) {
		$_defaults = array(
			//block
			'title'                 => '',
			'title_size'            => '',
			'title_line_height'     => '',
			'title_url'             => '',
			'icon'                  => '',
			'block_accent_color'    => '',

			//block_header
			'header_style'          => '',
			'header_bg_color'       => '',
			'header_line_color'     => '',
			'header_title_color'    => '',
			'header_title_bg_color' => '',
			'header_icon_color'     => '',

			//block_pagination_options
			'pagination'            => '',
			'show_pagination_label' => '',
			'infinity_break_count'  => '3',

			// 'slider_items'           => 1,

			//tabs
			'tabs'                  => '',
			'tabs_all_text'         => ak_get_translation( 'All', 'newsy-elements', 'all' ),
			'tabs_cat_filter'       => '',
			'tabs_tax_filter'       => '',
			'tabs_order_by_filter'  => '',
			'tabs_more_menu'        => '',

			//query
			'count'                 => '3',
			'offset'                => '',
			'post_type'             => '',
			'post_status'           => 'publish',
			'time_filter'           => '',
			'order_by'              => 'latest',

			'author'                => '',
			'category'              => '',
			'post'                  => '',
			'taxonomy'              => '',
			'taxonomy_relation'     => '',

			'block_width'           => '',
			'block_id'              => '',
			'block_extra_classes'   => '',

			'custom_enabled'        => '',
			'custom_parts'          => '',
			'wp_query'              => false,
			'numeric_items_style'   => '',
			'item_margin'           => '30',
			'css'                   => '',
			'show_no_result'        => true,
		);

		$this->defaults = array_merge( $_defaults, $this->defaults );

		parent::__construct( $id, $params );
	}

	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function render( $atts, $content = '' ) {

		if ( '' === $this->atts['block_width'] ) {
			$this->atts['block_width'] = apply_filters( 'newsy_block_width', 1 );
		}

		$this->prepare_inner_atts();
		$this->prepare_atts();
		$classes = apply_filters( 'newsy_block_classes', $this->get_block_classes() );

		$buffy = '<div class="ak-block ' . esc_attr( implode( ' ', $classes ) ) . '" id="' . esc_attr( $this->atts['block_id'] ) . '">';

		$buffy .= $this->render_block_css();

		$buffy .= $this->render_block_header();

		$buffy .= '<div class="ak-block-inner clearfix">';

		$buffy .= $this->render_inner();

		$buffy .= '</div>';

		$buffy .= '</div>';

		return $buffy;
	}

	/**
	 * Render the inner content of block.
	 *
	 * @return string
	 */
	public function render_inner() {
		$pagination = $this->atts['pagination'];

		if ( $this->atts['wp_query'] ) {
			global $wp_query;
			$block_query = $wp_query;
		} else {
			$block_query = ak_do_query( $this->atts );
		}

		$buffy           = '';
		$pagination_wrap = 'slider' === $pagination ? 'ak-slider-wrapper owl-carousel' : 'ak-pagination-wrapper';

		$buffy .= '<div class="ak-block-posts ' . $pagination_wrap . ' clearfix">';
		if ( ! empty( $block_query->posts ) ) {
			$buffy .= $this->inner( $this->atts, $block_query->posts );
		} elseif ( $this->atts['show_no_result'] ) {
			$buffy .= newsy_block_no_content();
		}
		$buffy .= '</div>';

		if ( '' !== $pagination || '' !== $this->atts['tabs'] ) {
			$buffy .= ak_pagination(
				array(
					'id'     => $this->atts['block_id'],
					'type'   => $pagination,
					'atts'   => $this->atts,
					'query'  => $block_query,
					'labels' => array(
						'load_more' => ak_get_translation( 'Load More Posts', 'newsy-elements', 'pagination_more_label' ),
						'no_more'   => ak_get_translation( 'No More Posts.', 'newsy-elements', 'pagination_no_more' ),
						'loading'   => ak_get_translation( 'Loading...', 'newsy-elements', 'pagination_loading_label' ),
						'next'      => ak_get_translation( 'Next', 'newsy-elements', 'pagination_next' ),
						'prev'      => ak_get_translation( 'Previous', 'newsy-elements', 'pagination_prev' ),
						'paged_of'  => ak_get_translation( '%1$s of %2$s', 'newsy-elements', 'pagination_pages_label' ),
					),
				)
			);
		}

		unset( $block_query );

		return $buffy;
	}

	/**
	 * Get block classes.
	 *
	 * @param array $classes
	 *
	 * @return array
	 */
	public function get_block_classes( $classes = array() ) {
		if ( ! empty( $this->params['style'] ) ) {
			$classes[] = esc_attr( $this->params['style'] );
		}

		if ( '' !== $this->atts['block_extra_classes'] ) {
			$classes[] = esc_attr( $this->atts['block_extra_classes'] );
		}

		if ( '' !== $this->atts['numeric_items_style'] ) {
			$classes[] = esc_attr( 'ak-block-numeric-' . $this->atts['numeric_items_style'] );
		}

		$classes[] = esc_attr( 'ak-block-width-' . $this->atts['block_width'] );

		$pagination = $this->atts['pagination'];

		if ( '' !== $pagination && 'simple' !== $pagination || '' !== $this->atts['tabs'] ) {
			$classes[] = 'slider' === $pagination ? 'ak-slider-container' : 'ak-pagination-container ' . $pagination;
		}

		$classes[] = 'clearfix';

		return $this->inner_classes( $classes );

	}

	/**
	 * Render block header.
	 *
	 * @return string
	 */
	public function render_block_header() {
		$buffy = '';

		$has_title = empty( $this->atts['title'] );
		$has_tabs  = empty( $this->atts['tabs'] );

		if ( $has_title && $has_tabs ) {
			return $buffy;
		}

		// default header style
		if ( empty( $this->atts['header_style'] ) ) {
			$this->atts['header_style'] = apply_filters( 'newsy_block_header_style', 'style-1' );
		}

		$block_header_classes = array( 'ak-block-header' );

		$block_header_classes[] = 'ak-block-header-' . $this->atts['header_style'];

		if ( $has_title ) {
			$block_header_classes[] = 'no-title';
		}

		if ( $has_tabs ) {
			$block_header_classes[] = 'no-tabs';
		}

		$buffy .= '<div class="' . esc_attr( implode( ' ', $block_header_classes ) ) . '">';

		if ( ! $has_title ) {
			$buffy .= '<h4 class="ak-block-title">';
			if ( ! empty( $this->atts['title_url'] ) ) {
				$buffy .= '<a href="' . esc_url( $this->atts['title_url'] ) . '">';
			}

			$buffy .= '<span class="title-text">';
			if ( ! empty( $this->atts['icon'] ) ) {
				$buffy .= ak_get_icon( $this->atts['icon'] );
			}
			$buffy .= esc_html( $this->atts['title'] );
			$buffy .= '</span>';

			if ( ! empty( $this->atts['title_url'] ) ) {
				$buffy .= '<i class="fa fa-angle-double-right"></i>';
				$buffy .= '</a>';
			}
			$buffy .= '</h4>';
		}

		if ( ! $has_tabs ) {
			$_tabs = $this->get_block_tabs();

			$block_tabs_classes = array( 'ak-block-tabs' );

			if ( empty( $this->atts['tabs_more_menu'] ) ) {
				$block_tabs_classes[] = 'ak-menu-more-enabled';
			}

			$buffy .= '<div class="' . esc_attr( implode( ' ', $block_tabs_classes ) ) . '">';
			$buffy .= '<ul class="ak-menu ak-menu-wide">';
			foreach ( (array) $_tabs as $tab ) {
				$buffy .= '<li class="menu-item">';
				$buffy .= '<a href="#" class="ak-tab-btn ' . esc_attr( $tab['class'] ) . '" data-tab-id="' . esc_attr( $tab['id'] ) . '" data-filter="' . esc_attr( $tab['filter'] ) . '" data-filter-value="' . esc_attr( $tab['filter_value'] ) . '">';
				$buffy .= $tab['icon'] . esc_html( $tab['title'] );
				$buffy .= '</a>';
				$buffy .= '</li>';
			}
			$buffy .= '</ul>';
			$buffy .= '</div>';
		}

		$buffy .= '</div>';

		return $buffy;
	}

	/**
	 * Render block css.
	 *
	 * @return string
	 */
	public function render_block_css() {
		$out                   = '';
		$block_id              = &$this->atts['block_id'];
		$item_margin           = &$this->atts['item_margin'];
		$title_size            = &$this->atts['title_size'];
		$title_line_height     = &$this->atts['title_line_height'];
		$header_bg_color       = &$this->atts['header_bg_color'];
		$header_line_color     = &$this->atts['header_line_color'];
		$header_title_color    = &$this->atts['header_title_color'];
		$header_icon_color     = &$this->atts['header_icon_color'];
		$header_title_bg_color = &$this->atts['header_title_bg_color'];
		$color                 = &$this->atts['block_accent_color'];

		if ( '' !== $color ) {
			$out .= "#{$block_id} {--ak-block-accent-color:{$color};}";
		}

		$output = '';

		if ( '' !== $title_size ) {
			$output .= "--ak-block-title-text-size:{$title_size};";
		}
		if ( '' !== $title_line_height ) {
			$output .= "--ak-block-title-line-height:{$title_line_height};";
		}
		if ( '' !== $header_bg_color ) {
			$output .= "--ak-block-header-bg-color:{$header_bg_color};";
		}
		if ( '' !== $header_line_color ) {
			$output .= "--ak-block-header-line-color:{$header_line_color};";
		}
		if ( '' !== $header_title_color ) {
			$output .= "--ak-block-title-text-color:{$header_title_color};";
		}
		if ( '' !== $header_icon_color ) {
			$output .= "--ak-block-title-icon-color:{$header_icon_color};";
		}
		if ( '' !== $header_title_bg_color ) {
			$output .= "--ak-block-title-bg-color:{$header_title_bg_color};";
		}
		if ( ! empty( $output ) ) {
			$out .= "#{$block_id} .ak-block-header {{$output}}";
		}

		if ( '' !== $item_margin && $this->defaults['item_margin'] !== $item_margin ) {
			if ( isset( $this->params['top_posts'] ) ) {
				$out .= "#{$block_id} .ak-block-posts{ margin: -{$item_margin}px 0 0 -{$item_margin}px; }";
				$out .= "#{$block_id} .ak-block-posts .ak-module-grid{ padding:{$item_margin}px 0 0 {$item_margin}px; }";
			} else {
				$out .= "#{$block_id}:not(.ak-block-width-1) .ak-block-posts { margin-right: -{$item_margin}px; }";
				$out .= "#{$block_id} .ak-block-posts .ak-module{ padding-right: {$item_margin}px; margin-bottom: {$item_margin}px; }";
				$out .= "#{$block_id}.ak-block-module-seperator-line .ak-module:not(:last-child){ padding-bottom: {$item_margin}px; }";
			}
		}

		$out .= $this->inner_css();

		// vc css options
		if ( ! empty( $this->atts['css'] ) && ! is_array( $this->atts['css'] ) ) {
			preg_match( '/{(.*?)}/s', $this->atts['css'], $match );
			if ( isset( $match[1] ) ) {
				$out .= "#{$block_id} { " . $match[1] . ' }';
			}
		}

		unset( $color, $item_margin, $this->atts['css'] );

		if ( empty( $out ) ) {
			return '';
		}

		return "<style scoped>{$out}</style>";
	}

	/**
	 * Render block post count.
	 *
	 * @return mixed
	 */
	public function get_post_count() {
		return absint( $this->atts['count'] );
	}

	/**
	 * Display the inner content of block.
	 * You should override display content in child of this class.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $posts ) {
		return '';
	}

	/**
	 * Get block inner css.
	 *
	 * @return string
	 */
	public function inner_css() {
		return '';
	}

	/**
	 * Get block inner classes.
	 *
	 * @param array $classes
	 * @return array
	 */
	public function inner_classes( $classes ) {
		return $classes;
	}

	/**
	 * Filter atts in child class if needed.
	 * You should override display content in child of this class.
	 *
	 * @return mixed
	 */
	public function prepare_inner_atts() {}

	/**
	 * Get block tabs.
	 *
	 * @return array
	 */
	public function get_block_tabs() {
		$tabs = array();

		if ( empty( $this->atts['tabs'] ) ) {
			return $tabs;
		}

		$terms       = array();
		$tabs['all'] = array(
			'title'        => $this->atts['tabs_all_text'],
			'filter'       => '',
			'filter_value' => '',
			'id'           => $this->atts['block_id'],
			'icon'         => '',
			'class'        => 'active',
			'active'       => true,
		);

		switch ( $this->atts['tabs'] ) {
			case 'order_filter':
				$order_by_tabs = newsy_get_block_order_by_tabs();

				if ( ! empty( $this->atts['tabs_order_by_filter'] ) ) {
					$_tabs = $this->atts['tabs_order_by_filter'];

					if ( is_string( $_tabs ) ) {
						$_tabs = explode( ',', $_tabs );
					}
				} else {
					$_tabs = $order_by_tabs;
				}

				$order_by      = $this->atts['order_by'];
				$order_by_name = isset( $order_by_tabs[ $order_by ] ) ? $order_by_tabs[ $order_by ] : $this->atts['tabs_all_text'];

				unset( $tabs['all'] );

				$tabs[] = array(
					'title'        => $order_by_name,
					'filter'       => '',
					'filter_value' => '',
					'id'           => $this->atts['block_id'],
					'icon'         => '',
					'class'        => 'active',
					'active'       => true,
				);

				foreach ( (array) $_tabs as $order_key ) {
					// Get Block is order by type and exclude from selected order by tabs cause we already load first tab
					if ( isset( $order_by_tabs[ $order_key ] ) && $order_by !== $order_key ) {
						$tabs[] = array(
							'title'        => $order_by_tabs[ $order_key ],
							'filter'       => 'order_by',
							'filter_value' => $order_key,
							'id'           => 'tab_' . ak_generate_uniqid(),
							'icon'         => '',
							'class'        => '',
							'active'       => false,
						);
					}
				}

				return $tabs;

				break;

			case 'tax_filter':
				if ( ! empty( $this->atts['tabs_tax_filter'] ) ) {
					$_tax = explode( ',', $this->atts['tabs_tax_filter'] );

					foreach ( $_tax as $val ) {
						$_val     = explode( ':', $val );
						$taxonomy = trim( $_val[0] );
						$term_id  = absint( trim( $_val[1] ) );

						if ( term_exists( $term_id, $taxonomy ) ) {
							$tabs[] = array(
								'title'        => get_term_field( 'name', $term_id ),
								//'link'         => get_term_link( $term ),
								'filter'       => 'taxonomy',
								'filter_value' => $val,
								'id'           => 'tab_' . ak_generate_uniqid(),
								'icon'         => '',
								'class'        => 'term-' . $term_id,
								'active'       => false,
							);
						}
					}
				}

				return $tabs;

			break;

			//
			// Category tabs
			//
			case 'cat_filter':
				if ( empty( $this->atts['tabs_cat_filter'] ) ) {
					break;
				} elseif ( is_string( $this->atts['tabs_cat_filter'] ) ) {
					$this->atts['tabs_cat_filter'] = explode( ',', $this->atts['tabs_cat_filter'] );
				}

				$terms = get_terms(
					array(
						'taxonomy'   => 'category',
						'hide_empty' => false,
						'include'    => $this->atts['tabs_cat_filter'],
					)
				);

				break;

			case 'sub_cat_filter':
				$main_cat = false;

				if ( ! empty( $this->atts['query-main-term'] ) ) {
					$main_cat = $this->atts['query-main-term'];
				} elseif ( ! empty( $this->atts['category'] ) ) {
					$main_cat = $this->atts['category'];
				}

				if ( $main_cat ) {
					$terms = get_categories(
						array(
							'child_of'   => $main_cat,
							'hide_empty' => false,
							'number'     => 10,
						)
					);
				}

				break;

		}

		foreach ( $terms as $term ) {
			$tabs[] = array(
				'title'        => $term->name,
				//'link'         => get_term_link( $term ),
				'filter'       => 'category',
				'filter_value' => $term->term_id,
				'id'           => 'tab_' . ak_generate_uniqid(),
				'icon'         => '',
				'class'        => 'term-' . $term->term_id,
				'active'       => false,
			);
		}

		return $tabs;
	}

	/**
	 * Handle block attributes.
	 *
	 * @return void
	 */
	protected function prepare_atts() {
		$this->atts['view'] = $this->id;

		if ( empty( $this->atts['block_id'] ) ) {
			// generate block unique id
			$block_id = 'block_' . ak_generate_uniqid();

			$this->atts['block_id'] = $block_id;
		}

		if ( ! empty( $this->atts['category'] ) ) {
			// choose first category as primary
			$match = explode( ',', $this->atts['category'] );
			if ( $match ) {
				$this->atts['query-main-term'] = $match[0];
			}
		}
	}

	/**
	 * Get block module attributes.
	 *
	 * @return void
	 */
	protected function get_module_atts( $atts, $module_prefix = '', $additional = array() ) {
		$module_atts = array();

		if ( 'yes' === $atts[ $module_prefix . 'custom_enabled' ] ) {
			$custom_parts = $atts[ $module_prefix . 'custom_parts' ];

			// vc settings
			if ( is_string( $custom_parts ) ) {
				// get default module settings
				$parts = str_replace( '&amp;', '&', $custom_parts );

				wp_parse_str( $parts, $custom_parts );
			}

			$module_atts['atts'] = $custom_parts;
		}

		if ( ! empty( $additional ) ) {
			$module_atts = array_merge( $module_atts, $additional );
		}

		return $module_atts;
	}

	/**
	 * Register block option fields.
	 *
	 * @return array
	 */
	public function fields() {
		return array_merge(
			$this->block_inner_options(),
			$this->block_header_options(),
			$this->block_filter_options(),
			$this->block_pagination_options(),
			$this->block_tab_options(),
			$this->block_module_show_parts(),
			$this->block_design_inner_options(),
			$this->block_design_options_numeric_content(),
			$this->block_design_options()
		);
	}

	/**
	 * Block inner options.
	 * Must override in child of this class.
	 *
	 * @return array
	 */
	public function block_inner_options() {
		return array();
	}

	/**
	 * Block header options.
	 *
	 * @return array
	 */
	public function block_header_options() {
		return array(
			array(
				'type'        => 'text',
				'admin_label' => true,
				'heading'     => __( 'Block Title', 'newsy-elements' ),
				'id'          => 'title',
				'section'     => __( 'Header', 'newsy-elements' ),
			),
			array(
				'type'        => 'text',
				'admin_label' => false,
				'heading'     => __( 'Block Title Url', 'newsy-elements' ),
				'id'          => 'title_url',
				'section'     => __( 'Header', 'newsy-elements' ),
				'dependency'  => array(
					'element'   => 'title',
					'not_empty' => true,
				),
			),
			array(
				'type'        => 'slider_unit',
				'admin_label' => false,
				'heading'     => __( 'Block Title Font Size', 'newsy-elements' ),
				'id'          => 'title_size',
				'unit'        => 'px',
				'max'         => 100,
				'section'     => __( 'Header', 'newsy-elements' ),
				'dependency'  => array(
					'element'   => 'title',
					'not_empty' => true,
				),
			),
			array(
				'type'        => 'slider_unit',
				'admin_label' => false,
				'heading'     => __( 'Block Title Line Height', 'newsy-elements' ),
				'id'          => 'title_line_height',
				'unit'        => 'px',
				'max'         => 100,
				'section'     => __( 'Header', 'newsy-elements' ),
				'dependency'  => array(
					'element'   => 'title',
					'not_empty' => true,
				),
			),
			array(
				'type'        => 'icon_select',
				'heading'     => __( 'Block Icon (Optional)', 'newsy-elements' ),
				'id'          => 'icon',
				'admin_label' => false,
				'description' => __( 'Select custom icon for listing.', 'newsy-elements' ),
				'section'     => __( 'Header', 'newsy-elements' ),
			),
			array(
				'type'             => 'radio_image',
				'admin_label'      => true,
				'heading'          => __( 'Block Header Style', 'newsy-elements' ),
				'id'               => 'header_style',
				'section'          => __( 'Header', 'newsy-elements' ),
				'options_callback' => array(
					'function' => 'newsy_get_block_header_styles',
					'args'     => array( true ),
				),
			),
			array(
				'type'       => 'color',
				'heading'    => __( 'Header Background Color', 'newsy-elements' ),
				'id'         => 'header_bg_color',
				'section'    => __( 'Header', 'newsy-elements' ),
				'dependency' => array(
					'element' => 'header_style',
					'value'   => array( 'style-7', 'style-10' ),
				),
			),
			array(
				'type'       => 'color',
				'heading'    => __( 'Header Line Color', 'newsy-elements' ),
				'id'         => 'header_line_color',
				'section'    => __( 'Header', 'newsy-elements' ),
				'dependency' => array(
					'element' => 'header_style',
					'value'   => array( 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'style-12', 'style-13', 'style-15' ),
				),
			),
			array(
				'type'       => 'color',
				'heading'    => __( 'Header Title Background Color', 'newsy-elements' ),
				'id'         => 'header_title_bg_color',
				'section'    => __( 'Header', 'newsy-elements' ),
				'dependency' => array(
					'element' => 'header_style',
					'value'   => array( 'style-3', 'style-6', 'style-7', 'style-8', 'style-9', 'style-10', 'style-15' ),
				),
			),
			array(
				'type'       => 'color',
				'heading'    => __( 'Header Title Color', 'newsy-elements' ),
				'id'         => 'header_title_color',
				'section'    => __( 'Header', 'newsy-elements' ),
				'dependency' => array(
					'element' => 'header_style',
					'value'   => array( 'style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7', 'style-8', 'style-9', 'style-10', 'style-11', 'style-12', 'style-13', 'style-14', 'style-15' ),
				),
			),
			array(
				'type'       => 'color',
				'heading'    => __( 'Header Icon Color', 'newsy-elements' ),
				'id'         => 'header_icon_color',
				'section'    => __( 'Header', 'newsy-elements' ),
				'dependency' => array(
					'element'   => 'icon',
					'not_empty' => true,
				),
			),
			array(
				'type'        => 'color',
				'heading'     => __( 'Block Accent Color', 'newsy-elements' ),
				'description' => __( 'Block Elements Color', 'newsy-elements' ),
				'id'          => 'block_accent_color',
				'section'     => __( 'Header', 'newsy-elements' ),
			),
		);
	}

	/**
	 * Block post count options.
	 *
	 * @return array
	 */
	public function block_post_number_options() {
		return array(
			'type'        => 'number',
			'admin_label' => true,
			'heading'     => __( 'Number of Posts', 'newsy-elements' ),
			'id'          => 'count',
			'description' => __( 'If the field is empty the limit post number will be the number from WordPress Settings -> Reading.', 'newsy-elements' ),
			'section'     => __( 'Filters', 'newsy-elements' ),
		);
	}

	/**
	 * Block post filter options.
	 *
	 * @return array
	 */
	public function block_filter_options() {
		return array(
			array(
				'id'               => 'category',
				'type'             => 'select',
				'admin_label'      => true,
				'heading'          => __( 'Categories', 'newsy-elements' ),
				'description'      => __( 'Show posts associated with certain categories.', 'newsy-elements' ),
				'multiple'         => 10,
				'options_callback' => 'Ak\Form\FormCallback::get_categories',
				'exculable'        => true,
				'return_string'    => true,
				'section'          => __( 'Filters', 'newsy-elements' ),
			),
			$this->block_post_number_options(),
			array(
				'type'        => 'number',
				'admin_label' => true,
				'heading'     => __( 'Offset posts', 'newsy-elements' ),
				'description' => __( 'Start the count with an offset. If you have a block that shows 4 posts before this one, you can make this one start from the 5\'th post (by using offset 4)', 'newsy-elements' ),
				'id'          => 'offset',
				'section'     => __( 'Filters', 'newsy-elements' ),
			),
			array(
				'type'             => 'select',
				'heading'          => __( 'Order By', 'newsy-elements' ),
				'id'               => 'order_by',
				'admin_label'      => false,
				'options_callback' => 'newsy_get_block_order_by_options',
				'section'          => __( 'Filters', 'newsy-elements' ),
			),
			array(
				'type'    => 'heading',
				'heading' => __( 'Advanced Filters', 'newsy-elements' ),
				'id'      => 'advanced_filters_heading',
				'section' => __( 'Filters', 'newsy-elements' ),
			),
			array(
				'type'        => 'select',
				'heading'     => __( 'Filter by Time', 'newsy-elements' ),
				'id'          => 'time_filter',
				'admin_label' => false,
				'options'     => array(
					''          => __( 'No Filter', 'newsy-elements' ),
					'today'     => __( 'Today Posts', 'newsy-elements' ),
					'yesterday' => __( 'Today + Yesterday Posts', 'newsy-elements' ),
					'week'      => __( 'This Week Posts', 'newsy-elements' ),
					'month'     => __( 'This Month Posts', 'newsy-elements' ),
					'year'      => __( 'This Year Posts', 'newsy-elements' ),
				),
				'section'     => __( 'Filters', 'newsy-elements' ),
			),
			array(
				'id'               => 'post_type',
				'type'             => 'select',
				'heading'          => __( 'Filter by Post Types', 'newsy-elements' ),
				'description'      => __( 'Enter here post type\'s separated by commas ( ex: book,movie,product ). Default is only (post)', 'newsy-elements' ),
				'multiple'         => 100,
				'options_callback' => 'Ak\Form\FormCallback::get_post_types',
				'section'          => __( 'Filters', 'newsy-elements' ),
			),
			array(
				'id'            => 'post',
				'type'          => 'ajax_select',
				'heading'       => __( 'Filter by Posts', 'newsy-elements' ),
				'description'   => __( 'Filter multiple posts by search. To exclude posts from this block click "-" button.', 'newsy-elements' ),
				'max_items'     => 100,
				'ajax_callback' => 'Ak\Form\FormCallback::get_posts',
				'exculable'     => true,
				'return_string' => true,
				'section'       => __( 'Filters', 'newsy-elements' ),
			),
			array(
				'id'            => 'author',
				'type'          => 'ajax_select',
				'heading'       => __( 'Filter by Authors', 'newsy-elements' ),
				'description'   => __( 'Filter multiple authors by search. To exclude authors from this block click "-" button.', 'newsy-elements' ),
				'max_items'     => 100,
				'ajax_callback' => 'Ak\Form\FormCallback::get_users',
				'exculable'     => true,
				'return_string' => true,
				'section'       => __( 'Filters', 'newsy-elements' ),
			),
			array(
				'id'                 => 'taxonomy',
				'type'               => 'ajax_select',
				'heading'            => __( 'Filter by Taxonomies', 'newsy-elements' ),
				'description'        => __( 'Filter multiple taxonomies by search. To exclude taxonomies from this block click "-" button.', 'newsy-elements' ),
				'ajax_callback'      => 'Ak\Form\FormCallback::get_taxonomies',
				'ajax_callback_args' => array(
					'by_slug' => true,
				),
				'exculable'          => true,
				'return_string'      => true,
				'section'            => __( 'Filters', 'newsy-elements' ),
			),
			array(
				'id'          => 'taxonomy_relation',
				'type'        => 'select',
				'heading'     => __( 'Taxonomies Relation', 'newsy-elements' ),
				'description' => __( 'Choose filtered by taxonomies relation type.', 'newsy-elements' ),
				'options'     => array(
					''   => 'AND',
					'OR' => 'OR',
				),
				'section'     => __( 'Filters', 'newsy-elements' ),
			),
		);
	}

	/**
	 * Block tabs options.
	 *
	 * @return array
	 */
	public function block_tab_options() {
		return array(
			array(
				'type'    => 'select',
				'heading' => __( 'Tabs', 'newsy-elements' ),
				'id'      => 'tabs',
				'options' => array(
					''               => __( 'No Tab', 'newsy-elements' ),
					'cat_filter'     => __( 'Categories as Tab', 'newsy-elements' ),
					'sub_cat_filter' => __( 'Sub Categories as Tab', 'newsy-elements' ),
					'tax_filter'     => __( 'Taxonomies as Tab', 'newsy-elements' ),
					'order_filter'   => __( 'Order by as Tab', 'newsy-elements' ),
				),
				'section' => __( 'Tabs', 'newsy-elements' ),
			),
			array(
				'type'             => 'select',
				'heading'          => __( 'Selected Categories as Tab', 'newsy-elements' ),
				'id'               => 'tabs_cat_filter',
				'options_callback' => 'Ak\Form\FormCallback::get_categories',
				'section'          => __( 'Tabs', 'newsy-elements' ),
				'multiple'         => 10,
				'return_string'    => true,
				'description'      => __( 'Select multiple categories for header tabs.', 'newsy-elements' ),
				'dependency'       => array(
					'element' => 'tabs',
					'value'   => array( 'cat_filter' ),
				),
			),
			array(
				'type'          => 'ajax_select',
				'heading'       => __( 'Taxonomies as tab', 'newsy-elements' ),
				'id'            => 'tabs_tax_filter',
				'ajax_callback' => 'Ak\Form\FormCallback::get_taxonomies',
				'return_string' => true,
				'description'   => __( 'Select multiple taxonomies for header tabs.', 'newsy-elements' ),
				'dependency'    => array(
					'element' => 'tabs',
					'value'   => array( 'tax_filter' ),
				),
				'section'       => __( 'Tabs', 'newsy-elements' ),
			),
			array(
				'type'             => 'select',
				'heading'          => __( 'Order by options as Tab', 'newsy-elements' ),
				'description'      => __( 'Choose order by options you want see or leave empty for all options.', 'newsy-elements' ),
				'id'               => 'tabs_order_by_filter',
				'options_callback' => 'newsy_get_block_order_by_tabs',
				'multiple'         => 10,
				'return_string'    => true,
				'dependency'       => array(
					'element' => 'tabs',
					'value'   => array( 'order_filter' ),
				),
				'section'          => __( 'Tabs', 'newsy-elements' ),
			),
			array(
				'type'        => 'text',
				'heading'     => __( 'Tabs "All" Text', 'newsy-elements' ),
				'id'          => 'tabs_all_text',
				'description' => __( 'Enter here custom text for block header tabs more menu.', 'newsy-elements' ),
				'dependency'  => array(
					'element'   => 'tabs',
					'not_empty' => true,
				),
				'section'     => __( 'Tabs', 'newsy-elements' ),
			),
		);
	}

	/**
	 * Block pagination options.
	 *
	 * @return array
	 */
	public function block_pagination_options() {
		return array(
			array(
				'type'        => 'select',
				'heading'     => __( 'Pagination Type', 'newsy-elements' ),
				'id'          => 'pagination',
				'admin_label' => false,
				'options'     => array(
					''                   => __( 'No Pagination', 'newsy-elements' ),
					'next_prev'          => __( 'Ajax Next Prev', 'newsy-elements' ),
					'load_more'          => __( 'Ajax Load more', 'newsy-elements' ),
					'infinity'           => __( 'Infinity loading', 'newsy-elements' ),
					'infinity_load_more' => __( 'Infinity loading + Load more button', 'newsy-elements' ),
				),
				'section'     => __( 'Pagination', 'newsy-elements' ),
				'always_show' => true,
			),
			array(
				'type'        => 'slider',
				'vertical'    => true,
				'heading'     => __( 'Infinity break page (Default 3)', 'newsy-elements' ),
				'id'          => 'infinity_break_count',
				'admin_label' => false,
				'value'       => 3,
				'min'         => 1,
				'max'         => 30,
				'section'     => __( 'Pagination', 'newsy-elements' ),
				'dependency'  => array(
					'element' => 'pagination',
					'value'   => array( 'infinity_load_more' ),
				),
			),
			array(
				'type'        => 'visual_select',
				'vertical'    => true,
				'heading'     => __( 'Show pagination number label', 'newsy-elements' ),
				'id'          => 'show_pagination_label',
				'admin_label' => false,
				'section'     => __( 'Pagination', 'newsy-elements' ),
				'options'     => array(
					''     => __( 'Yes', 'newsy-elements' ),
					'hide' => __( 'No', 'newsy-elements' ),
				),
				'dependency'  => array(
					'element' => 'pagination',
					'value'   => array( 'next_prev' ),
				),
			),
		);
	}

	/**
	 * Block module numeric styles options.
	 *
	 * @return array
	 */
	public function block_design_options_numeric_content() {
		return array(
			array(
				'type'        => 'select',
				'heading'     => __( 'Numeric Item Style', 'newsy-elements' ),
				'description' => __( 'Select block module counter numbers style.', 'newsy-elements' ),
				'id'          => 'numeric_items_style',
				'admin_label' => false,
				'options'     => array(
					''        => __( 'Don\'t Show', 'newsy-elements' ),
					'style-1' => sprintf( __( 'Style %s', 'newsy-elements' ), '1' ),
					'style-2' => sprintf( __( 'Style %s', 'newsy-elements' ), '2' ),
					'style-3' => sprintf( __( 'Style %s', 'newsy-elements' ), '3' ),
					'style-4' => sprintf( __( 'Style %s', 'newsy-elements' ), '4' ),
					'style-5' => sprintf( __( 'Style %s', 'newsy-elements' ), '5' ),
					'style-6' => sprintf( __( 'Style %s', 'newsy-elements' ), '6' ),
					'style-7' => sprintf( __( 'Style %s', 'newsy-elements' ), '7' ),
					'style-8' => sprintf( __( 'Style %s', 'newsy-elements' ), '8' ),
				),
				'section'     => __( 'Design', 'newsy-elements' ),
			),
		);
	}

	/**
	 * Block design options.
	 *
	 * @return array
	 */
	public function block_design_options() {
		return array(
			array(
				'type'             => 'text',
				'heading'          => __( 'Block Extra Class', 'newsy-elements' ),
				'description'      => __( 'Select block extra classes. Ex: You can set boxed style block or dark style block with these predefined classes or you can add custom CSS classes.', 'newsy-elements' ),
				'id'               => 'block_extra_classes',
				'selectize'        => true,
				'delimiter'        => ' ',
				'options_callback' => 'newsy_get_block_supported_classes',
				'section'          => __( 'Design', 'newsy-elements' ),
			),
			array(
				'type'        => 'select',
				'heading'     => __( 'Block Width', 'newsy-elements' ),
				'description' => __( 'Block column width. 1 Block represents 4 column. Use auto for page builder\'s column sizes', 'newsy-elements' ),
				'id'          => 'block_width',
				'options'     => array(
					''  => __( 'Auto', 'newsy-elements' ),
					'3' => '12 column',
					'2' => '8 column',
					'1' => '4 column',
				),
				'section'     => __( 'Design', 'newsy-elements' ),
			),
			array(
				'type'        => 'text',
				'heading'     => __( 'Block Custom ID', 'newsy-elements' ),
				'description' => __( 'Block custom CSS ID. Useful if you want apply custom style for this block.', 'newsy-elements' ),
				'id'          => 'block_id',
				'section'     => __( 'Design', 'newsy-elements' ),
			),
			$this->block_design_item_margin_options(),
			array(
				'type'    => 'css_editor',
				'heading' => __( 'CSS box', 'newsy-elements' ),
				'id'      => 'css',
				'section' => __( 'Design', 'newsy-elements' ),
			),
		);
	}

	/**
	 * Block post count options.
	 *
	 * @return array
	 */
	public function block_design_item_margin_options() {
		return array(
			'type'        => 'slider',
			'heading'     => __( 'Block Item Margin', 'newsy-elements' ),
			'id'          => 'item_margin',
			'admin_label' => false,
			'max'         => 100,
			'section'     => __( 'Design', 'newsy-elements' ),
		);
	}

	/**
	 * Block design inner options.
	 * Must override in child of this class.
	 *
	 * @return array
	 */
	public function block_design_inner_options() {
		return array();
	}

	/**
	 * Block module parts options.
	 * Must override in child of this class.
	 *
	 * @return array
	 */
	public function block_module_show_parts() {
		return array();
	}
}
