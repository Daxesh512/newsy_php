<?php

namespace NewsyElements\Shortcode\Block;

use NewsyElements\Shortcode\BlockAbstract;
use NewsyElements\Module\Module_2;
use NewsyElements\Module\Module_2_Tall;

/**
 * Newsy Block 11.
 */
class Block_11 extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['module_2_tall_custom_enabled'] = '';
		$this->defaults['module_2_tall_custom_parts']   = '';
		$this->defaults['module_2_custom_enabled']      = '';
		$this->defaults['module_2_custom_parts']        = '';
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$total_count = count( $query_posts );
		$block_width = $atts['block_width'];
		$post_count  = 0;

		$buffy = '';

		switch ( $block_width ) {
			case '1':
				foreach ( $query_posts as $post ) {
					$post_count++;

					if ( 1 == $post_count ) {
						$the_post = new Module_2_Tall( $post, $this->get_module_atts( $atts, 'module_2_tall_' ) );
						$buffy   .= $the_post->display();
					} else {
						$the_post = new Module_2( $post, $this->get_module_atts( $atts, 'module_2_' ) );
						$buffy   .= $the_post->display();
					}
				}

				break;

			case '2':
			case '3':
				$column_class = ( 3 === $block_width ) ? 'col-sm-4' : 'col-sm-6';
				$buffy       .= '<div class="row">';
				foreach ( $query_posts as $post ) {
					$post_count++;

					if ( 1 == $post_count ) {
						$buffy   .= '<div class="' . $column_class . '">';
						$the_post = new Module_2_Tall( $post, $this->get_module_atts( $atts, 'module_2_tall_' ) );
						$buffy   .= $the_post->display();
						$buffy   .= '</div>';
					} else {
						if ( 2 === $post_count || 5 === $post_count ) {
							$buffy .= '<div class="' . $column_class . '">';
						}
						$the_post = new Module_2( $post, $this->get_module_atts( $atts, 'module_2_' ) );
						$buffy   .= $the_post->display();

						if ( 4 === $post_count || $total_count === $post_count ) {
							$buffy     .= '</div>';
							$post_count = 0;
						}
					}
				}
				$buffy .= '</div>';

				break;

		}

		unset( $query_posts );

		return $buffy;
	}

	public function block_post_number_options() {
		//no post number for grid posts
		return array(
			'type'      => 'info',
			'title'     => __( 'This module will not let you to choose number of post.', 'newsy-elements' ),
			'info_type' => 'note',
			'id'        => 'help',
			'section'   => __( 'Filters', 'newsy-elements' ),
		);
	}

	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_2_tall', true ),
			newsy_get_module_vc_fields( 'module_2', true )
		);
	}
}
