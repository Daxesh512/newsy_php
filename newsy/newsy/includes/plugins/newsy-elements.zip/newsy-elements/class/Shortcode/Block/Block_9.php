<?php

namespace NewsyElements\Shortcode\Block;

use NewsyElements\Shortcode\BlockAbstract;
use NewsyElements\Module\Module_2;
use NewsyElements\Module\Module_5;

/**
 * Newsy Block 9.
 */
class Block_9 extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['module_2_custom_enabled'] = '';
		$this->defaults['module_2_custom_parts']   = '';
		$this->defaults['module_5_custom_enabled'] = '';
		$this->defaults['module_5_custom_parts']   = '';
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {

		$column_number = &$atts['block_width'];
		$post_count    = 0;

		$buffy = '';

		switch ( $column_number ) {
			case '1':
				foreach ( $query_posts as $post ) {
					$post_count++;

					if ( 1 == $post_count ) {
						$the_post = new Module_5( $post, $this->get_module_atts( $atts, 'module_5_' ) );
						$buffy   .= $the_post->display();
					} else {

						$the_post = new Module_2( $post, $this->get_module_atts( $atts, 'module_2_' ) );
						$buffy   .= $the_post->display();
					}
				}

				break;

			case '2':
			case '3':
				$buffy .= '<div class="row">';
				foreach ( $query_posts as $post ) {
					$post_count++;

					if ( 1 == $post_count ) {
						$buffy   .= '<div class="col-sm-3">';
						$the_post = new Module_2( $post, $this->get_module_atts( $atts, 'module_2_' ) );
						$buffy   .= $the_post->display();
						$buffy   .= '</div>';
					} elseif ( 2 == $post_count ) {
						$buffy   .= '<div class="col-sm-6">';
						$the_post = new Module_5( $post, $this->get_module_atts( $atts, 'module_5_' ) );
						$buffy   .= $the_post->display();
						$buffy   .= '</div>';
					} elseif ( 3 == $post_count ) {
						$buffy     .= '<div class="col-sm-3">';
						$the_post   = new Module_2( $post, $this->get_module_atts( $atts, 'module_2_' ) );
						$buffy     .= $the_post->display();
						$buffy     .= '</div>';
						$post_count = 0;
					}
				}
				$buffy .= '</div>';

				break;
		}

		unset( $query_posts );

		return $buffy;
	}

	public function block_post_number_options() {
		//no post number for grid posts
		return array(
			'type'      => 'info',
			'title'     => __( 'This module will not let you to choose number of post.', 'newsy-elements' ),
			'info_type' => 'note',
			'id'        => 'help',

			'section'   => __( 'Filters', 'newsy-elements' ),
		);
	}

	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_2', true ),
			newsy_get_module_vc_fields( 'module_5', true )
		);
	}
}
