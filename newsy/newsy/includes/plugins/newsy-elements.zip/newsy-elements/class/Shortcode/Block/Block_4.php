<?php

namespace NewsyElements\Shortcode\Block;

use NewsyElements\Module\Module_10;
use NewsyElements\Module\Module_2_Wide;
use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Block 4.
 */
class Block_4 extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['module_2_wide_custom_enabled'] = '';
		$this->defaults['module_2_wide_custom_parts']   = '';
		$this->defaults['module_10_custom_enabled']     = '';
		$this->defaults['module_10_custom_parts']       = '';
	}

	public function prepare_inner_atts() {
		$this->atts['count'] *= intval( $this->atts['block_width'] );
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$post_count    = 0;
		$count         = 0;
		$column_number = $atts['block_width'];

		$buffy = '';
		foreach ( $query_posts as $post ) {
			$post_count++;
			$count++;

			if ( $count <= $column_number ) {
				$the_post = new Module_2_Wide( $post, $this->get_module_atts( $atts, 'module_2_wide_' ) );
				$buffy   .= $the_post->display();
			} else {
				$the_post = new Module_10( $post, $this->get_module_atts( $atts, 'module_10_' ) );
				$buffy   .= $the_post->display();
			}

			if ( $post_count === $column_number ) {
				$post_count = 0;
			}
		}

		unset( $query_posts );

		return $buffy;
	}

	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_2_wide', true ),
			newsy_get_module_vc_fields( 'module_10', true )
		);
	}
}
