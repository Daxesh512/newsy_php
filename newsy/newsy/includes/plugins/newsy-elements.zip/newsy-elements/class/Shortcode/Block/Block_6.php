<?php

namespace NewsyElements\Shortcode\Block;

use NewsyElements\Module\Module_2;
use NewsyElements\Module\Module_1_Large;
use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Block 6.
 */
class Block_6 extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );
		$this->defaults['count'] = '3';

		$this->defaults['module_1_large_custom_enabled'] = '';
		$this->defaults['module_1_large_custom_parts']   = '';
		$this->defaults['module_2_custom_enabled']       = '';
		$this->defaults['module_2_custom_parts']         = '';
	}

	public function prepare_inner_atts() {
		$column_number = $this->atts['block_width'];

		if ( 3 == $column_number ) {
			$this->atts['count']       = 5;
			$this->atts['block_width'] = 4;
		} elseif ( 2 == $column_number ) {
			$this->atts['count']       = 4;
			$this->atts['block_width'] = 3;
		}
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$total_count = count( $query_posts );
		$post_count  = 0;
		$buffy       = '';

		foreach ( $query_posts as $post ) {
			$post_count++;

			if ( 1 == $post_count ) {
				$the_post = new Module_1_Large( $post, $this->get_module_atts( $atts, 'module_1_large_' ) );
				$buffy   .= $the_post->display();
			} else {
				$the_post = new Module_2( $post, $this->get_module_atts( $atts, 'module_2_' ) );
				$buffy   .= $the_post->display();
			}
		}

		unset( $query_posts );

		return $buffy;
	}

	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_1_large', true ),
			newsy_get_module_vc_fields( 'module_2', true )
		);
	}
}
