<?php

namespace NewsyElements\Shortcode\Slider;

use NewsyElements\Module\Module_Grid_Big;

/**
 * Newsy Slider 3.
 */
class Slider_3 extends SliderAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['gradient']             = 'tg-gradient tg-focus';
		$this->defaults['grid_height']          = '500';
		$this->defaults['slide_count_desktop']  = '1';
		$this->defaults['slide_count_notebook'] = '1';
		$this->defaults['slide_count_tablet']   = '1';
		$this->defaults['slider_items']         = '1';
		$this->defaults['slider_nav']           = 'style-3';
	}

	/**
	 * Handle displaying of shortcode.
	 *
	 * @param array  $this->atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function inner_classes( $classes ) {
		if ( '' !== $this->atts['gradient'] ) {
			$classes[] = esc_attr( $this->atts['gradient'] );
		}

		return $classes;
	}
	/**
	 * Display the inner content of block.
	 */
	public function inner( &$atts, $query_posts ) {
		$column_number = $atts['block_width'];

		$module_atts          = array();
		$module_atts['class'] = 'ak-slider-item';
		if ( 3 === $column_number ) {
			$module_atts['image-size'] = 'newsy_1140x570';
		}

		$post_count = 0;

		$buffy = '';
		foreach ( $query_posts as $post ) {
			$post_count++;

			$the_post = new Module_Grid_Big( $post, $module_atts );
			$buffy   .= $the_post->display( $post_count );
		}

		unset( $module_atts, $query_posts );

		return $buffy;
	}

	public function block_inner_options() {
		return array_merge(
			$this->block_slide_style_options(),
			array(
				'type'        => 'number',
				'heading'     => __( 'Grid Height', 'newsy-elements' ),
				'id'          => 'grid_height',
				'admin_label' => true,
				'section'     => __( 'General', 'newsy-elements' ),
			),
			$this->block_slider_options()
		);
	}

	public function block_header_options() {
		//no inner option
		return array();
	}
}
