<?php
namespace NewsyElements\Shortcode\Slider;

use NewsyElements\Module\Module_Image;

/**
 * Newsy Slider 1.
 */
class Slider_1 extends SliderAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['gradient']            = 'tg-gradient';
		$this->defaults['slide_count_desktop'] = '10';
		$this->defaults['slider_scroll_items'] = '10';
		$this->defaults['slider_nav']          = 'style-1';
	}

	/**
	 * Display the inner content of block.
	 */
	public function inner( &$atts, $query_posts ) {
		$post_count  = 0;
		$buffy       = '';
		$module_atts = array();

		foreach ( $query_posts as $post ) {
			$post_count++;
			$module_atts['image-size'] = 'newsy_120x86';
			$module_atts['class']      = 'ak-slider-item';
			$the_post                  = new Module_Image( $post, $module_atts );

			$buffy .= $the_post->display( $post_count );
		}

		unset( $module_atts, $atts );

		return $buffy;
	}

	public function block_inner_options() {
		return array_merge(
			$this->block_slide_style_options(),
			$this->block_slider_options()
		);
	}

	public function block_header_options() {
		//no inner option
		return array();
	}
}
