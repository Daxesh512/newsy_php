<?php

namespace NewsyElements\Shortcode\Lists;

use NewsyElements\Module\Module_2;
use NewsyElements\Module\Module_1_Medium;
use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy List 12.
 */
class List_12 extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['count']                          = '10';
		$this->defaults['module_2_custom_enabled']        = '';
		$this->defaults['module_2_custom_parts']          = '';
		$this->defaults['module_1_medium_custom_enabled'] = '';
		$this->defaults['module_1_medium_custom_parts']   = '';
	}

		/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {

		$buffy         = '';
		$total_count   = count( $query_posts );
		$count         = 0;
		$post_count    = 0;
		$column_number = $atts['block_width'];

		foreach ( $query_posts as $post ) {
			$post_count++;
			$count++;

			switch ( $post_count ) {
				case 4:
				case 5:
					if ( 4 == $post_count ) {
						$buffy .= '<div class="ak-block-bottom-posts clearfix">';
					}

					$the_post = new Module_2( $post, $this->get_module_atts( $atts, 'module_2_' ) );
					$buffy   .= $the_post->display( 2 );

					if ( 5 == $post_count || $total_count === $count ) {
						$buffy     .= '</div>';
						$post_count = 0;
					}
					break;

				default:
					$the_post = new Module_1_Medium( $post, $this->get_module_atts( $atts, 'module_1_medium_' ) );
					$buffy   .= $the_post->display();
					break;
			}
		}
		unset( $module_atts, $query_posts );

		return $buffy;
	}

	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_1_medium', true ),
			newsy_get_module_vc_fields( 'module_2', true )
		);
	}
}
