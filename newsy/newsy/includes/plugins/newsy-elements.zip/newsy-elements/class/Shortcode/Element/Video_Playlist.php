<?php

namespace NewsyElements\Shortcode\Element;

use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Video Playlist Shortcode.
 */
class Video_Playlist extends BlockAbstract {

	public function __construct( $id, $params ) {

		parent::__construct( $id, $params );

		$_defaults = array(
			'layout'   => '',
			'scheme'   => '',
			'color'    => '',
			'count'    => 10,
			'taxonomy' => 'post_format:post-format-video',
		);

		$this->defaults = array_merge( $this->defaults, $_defaults );
	}


	/**
	 * Handle displaying of shortcode.
	 *
	 * @param array  $this->atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function inner_classes( $classes ) {

		if ( 'horizontal' === $this->atts['layout'] ) {
			$classes[] = ' ak-video-playlist-horizontal';
		} else {
			$classes[] = ' ak-video-playlist-vertical';
		}

		if ( 'dark' === $this->atts['scheme'] ) {
			$classes[] = ' dark';
		}

		return $classes;
	}


	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function render_inner() {

		$block_id = $this->atts['block_id'];

		$buffy = '';

		$block_query = ak_do_query( $this->atts );

		if ( ! empty( $block_query->posts ) ) {
			$playlist = $this->build_playlist( $block_query->posts );

			$buffy .= '
                <div class="ak-video-playlist-player-wrap">
                    <div class="ak-video-playlist-player-holder">
                        ' . newsy_get_post_featured_video( $block_query->posts[0]->ID, false ) . '
                    </div>
                </div>

                <div class="ak-video-playlist-list-wrap">
                    <div class="ak-video-playlist-playing-wrap">
                        <div class="ak-video-playlist-playing-top">
                            <div class="ak-video-playlist-playing-icon">
                                <i class="fa fa-play"></i>
                            </div>
                            <span>' . ak_get_translation( 'Currently Playing', 'newsy-elements', 'currently_playing' ) . '</span>
                        </div>
                        <div class="ak-video-playlist-playing-title">
                            <h2>' . $block_query->posts[0]->post_title . "</h2>
                        </div>
                    </div>
                    <div class=\"ak-video-playlist-list-inner-wrap\">
                        {$playlist}
                    </div>
                </div>
               <script> var {$block_id} = {$this->build_data($block_query->posts)}; </script>
            ";
		}

		unset( $block_query );

		return $buffy;
	}

	public function inner_css() {
		$buffy    = '';
		$block_id = $this->atts['block_id'];
		$color    = $this->atts['color'];
		if ( '' == $color ) {
			return $buffy;
		}

		$buffy .= "#{$block_id}.ak-video-playlist-vertical .ak-video-playlist-playing-wrap { background-color:{$color}; }";
		$buffy .= "#{$block_id}.ak-video-playlist-horizontal .ak-video-playlist-item.active  { border-color:{$color}; }";
		$buffy .= "#{$block_id} .ak-video-playlist-item.active .ak-video-playlist-item-thumb:before { color:{$color}; }";
		$buffy .= "#{$block_id} .ak-video-playlist-item.active .ak-video-playlist-item-thumb img { border-color:{$color}; }";
		$buffy .= "#{$block_id} .ak-video-playlist-playing-top { color:{$color}; }";
		$buffy .= "#{$block_id} .ak-video-playlist-playing-icon { color:{$color}; }";

		unset( $color );
		return $buffy;
	}

	private function build_playlist( $results ) {
		$output = '';

		foreach ( $results as $key => $post ) {

			$img = ak_get_post_image( $post->ID, 'newsy_120x86' );

			$video      = ak_get_post_meta( 'featured_video', $post->ID );
			$video_time = '';
			if ( isset( $video['time'] ) ) {
				$video_time = $video['time'];
			}

			$active = 0 === $key ? 'active' : '';

			$output .=
				"<a class=\"ak-video-playlist-item {$active}\" href=\"" . get_the_permalink( $post ) . '" data-id="' . $post->ID . "\">
                    <div class=\"ak-video-playlist-item-thumb\">
                        {$img}
                    </div>
                    <div class=\"ak-video-playlist-item-desc\">
                        <h3 class=\"ak-video-playlist-item-title\">" . ak_limit_words( get_the_title( $post ), 60 ) . '</h3>
                        <span class="ak-video-playlist-item-duration">' . $video_time . '</span>
                    </div>
                </a>';
		}

		return $output;
	}

	public function build_data( $results ) {
		$json = array();

		foreach ( $results as $key => $post ) {
			$json[ $post->ID ] = newsy_get_post_featured_video( $post->ID, true );
		}

		return wp_json_encode( $json );
	}

	/**
	 * Visual Composer Fields Map for Shortcode
	 */
	function fields() {
		return array_merge(
			$this->block_inner_options(),
			$this->block_header_options(),
			$this->block_filter_options(),
			$this->block_design_options()
		);
	}

	/**
	 * Registers Visual Composer Add-on
	 */
	function block_inner_options() {
		return array(
			array(
				'type'        => 'visual_select',
				'heading'     => __( 'Video Playlist Layout', 'newsy-elements' ),
				'id'          => 'layout',
				'admin_label' => true,
				'options'     => array(
					''           => __( 'Vertical', 'newsy-elements' ),
					'horizontal' => __( 'Horizontal', 'newsy-elements' ),
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'visual_select',
				'heading'     => __( 'Video Playlist Scheme', 'newsy-elements' ),
				'id'          => 'scheme',
				'admin_label' => true,
				'options'     => array(
					''     => __( 'Light Scheme', 'newsy-elements' ),
					'dark' => __( 'Dark Scheme', 'newsy-elements' ),
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'    => 'color',
				'heading' => __( 'Video Playlist Color', 'newsy-elements' ),
				'id'      => 'color',
				'section' => __( 'Settings', 'newsy-elements' ),
			),
		);
	}

	public function block_design_item_margin_options() {
		return array();
	}
}
