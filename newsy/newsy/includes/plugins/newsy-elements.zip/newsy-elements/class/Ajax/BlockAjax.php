<?php

namespace NewsyElements\Ajax;

/**
 * Class BlockAjax.
 */
class BlockAjax {

	/**
	 * Handle block ajax request.
	 *
	 * @return void
	 */
	public static function handle() {
		$required_keys = array(
			'atts'         => '',
			'id'           => '',
			'token'        => '',
			'current_page' => '',
		);

		// checking for valid ajax params
		if ( array_diff_key( $required_keys, $_POST ) ) {
			wp_send_json(
				array(
					'success' => 0,
					'error'   => 'Invalid Request!',
				)
			);
		}

		if ( empty( $_POST['token'] ) || substr( wp_hash( $_POST['id'], 'nonce' ), 1, 11 ) != $_POST['token'] ) {
			wp_send_json(
				array(
					'success' => 0,
					'error'   => 'Invalid Token!',
				)
			);
		}

		$atts         = &$_POST['atts'];
		$view         = &$atts['view'];
		$current_page = absint( $_POST['current_page'] );

		if ( isset( $_POST['doing_tab'] ) && $_POST['doing_tab'] ) {
			$tab_filter       = $_POST['tab_filter'];
			$tab_filter_value = $_POST['tab_filter_value'];

			$atts[ $tab_filter ] = $tab_filter_value;

			unset( $atts['offset'] );
		}

		$response = ak_do_pagination_query( $atts, $current_page );

		$instance = ak_get_shortcode( $view );

		if ( $instance && is_callable( array( $instance, 'inner' ) ) ) {
			// get only inner html
			if ( ! empty( $response['result'] ) ) {
				$response['html'] = $instance->inner( $atts, $response['result'] );
			} else {
				$response['html'] = newsy_block_no_content();
			}
		}

		unset( $response['result'] );

		wp_send_json( $response );
	}
}
