<?php
namespace NewsyElements\Module;

/**
 * Class Module_2.
 */
class Module_2 extends ModuleAbstract {

	public $module_id = 'module_2';

	public $module_class = 'ak-module-2 ak-column-module';

	public $module_image = 'newsy_350x250';

	public $featured_meta = true;

	public $show_video_duration = true;

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-featured">
					<?php
					$this->get_badge_icon();
					$this->get_featured_image();
					$this->get_category();
					$this->get_featured_meta();
					?>
				</div>
				<div class="ak-module-details">
					<?php
					$this->get_category( 'inline' );
					$this->get_title( '', 'h3' );
					$this->get_meta();
					$this->get_excerpt( 80 );
					?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
