<?php
namespace NewsyElements\Module;

/**
 * Class Module_1_Wide.
 */
class Module_1_Wide extends ModuleAbstract {

	public $module_id = 'module_1_wide';

	public $module_class = 'ak-module-1-wide';

	public $module_image = 'newsy_360x180';

	public $show_video_duration = true;

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<?php
					$this->get_title();
					$this->get_meta();
				?>
				<div class="ak-module-featured">
					<?php
					$this->get_badge_icon();
					$this->get_featured_image();
					?>
				</div>
				<div class="ak-module-details">
					<?php
					$this->get_category( 'inline' );
					$this->get_excerpt( 245 );
					?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
