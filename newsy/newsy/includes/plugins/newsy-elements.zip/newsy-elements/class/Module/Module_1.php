<?php
namespace NewsyElements\Module;

/**
 * Class Module_1.
 */
class Module_1 extends ModuleAbstract {

	public $module_id = 'module_1';

	public $module_class = 'ak-module-1';

	public $module_image = 'newsy_350x250';

	public $show_video_duration = true;

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-featured">
					<?php
					$this->get_badge_icon();
					$this->get_featured_image();
					$this->get_category();
					?>
				</div>
				<div class="ak-module-details">
					<?php
					$this->get_category( 'inline' );
					$this->get_title( 70, 'h3' );
					$this->get_excerpt( 90, false );
					$this->get_meta();
					?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
