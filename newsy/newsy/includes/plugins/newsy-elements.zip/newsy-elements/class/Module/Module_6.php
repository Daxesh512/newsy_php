<?php
namespace NewsyElements\Module;

/**
 * Class Module_6.
 */
class Module_6 extends ModuleAbstract {

	public $module_id = 'module_6';

	public $module_class = 'ak-module-6';

	public $module_image = 'newsy_750x536';

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="clearfix ak-module-inner">
				<div class="clearfix ak-module-featured">
					<?php $this->get_badge_icon(); ?>
					<?php $this->get_featured_image( '', false, false, true ); ?>
				</div>
				<div class="ak-module-details">
					<?php $this->get_category( '' ); ?>

					<?php $this->get_title(); ?>

					<?php $this->get_meta(); ?>

					<?php $this->get_excerpt( 180 ); ?>

					<div class="clearfix ak-module-bottom">
						<?php $this->get_meta_bottom(); ?>
					</div>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
