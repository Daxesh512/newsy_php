<?php
namespace NewsyElements\Module;

/**
 * Class Module_9.
 */
class Module_9 extends ModuleAbstract {

	public $module_id = 'module_9';

	public $module_class = 'ak-module-9';

	public $module_image = 'newsy_750x0';

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-details top">
					<?php $this->get_category( 'inline' ); ?>
					<?php $this->get_badge_icon(); ?>
					<?php $this->get_title(); ?>
				</div>
				<div class="ak-module-featured clearfix">
				<?php $this->get_featured_image( '', false, true, true ); ?>
				</div>
				<div class="ak-module-details">
					<?php $this->get_meta(); ?>

					<div class="ak-module-bottom clearfix">
						<?php $this->get_meta_bottom(); ?>
					</div>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
