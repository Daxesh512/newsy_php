<?php
namespace NewsyElements\Module;

/**
 * Class Module_Image.
 */
class Module_Image extends ModuleAbstract {

	public $module_id = 'module_image';

	public $module_class = 'ak-module-featured-grid';

	public $module_image = 'newsy_350x250';

	public function display( $order_no ) {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes( array( 'ak-block-item-' . $order_no ) ) ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-featured">
					<?php $this->get_featured_image(); ?>
				</div>
				<div class="ak-module-details">
					<?php $this->get_title( 65 ); ?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
