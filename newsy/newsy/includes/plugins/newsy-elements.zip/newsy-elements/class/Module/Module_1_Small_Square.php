<?php
namespace NewsyElements\Module;

/**
 * Class Module_1_Small_Square.
 */
class Module_1_Small_Square extends ModuleAbstract {

	public $module_id = 'module_1_small_square';

	public $module_class = 'ak-module-1-small-square ak-column-module';

	public $module_image = 'newsy_75x75';

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-featured">
					<?php $this->get_featured_image(); ?>
				</div>
				<div class="ak-module-details">
					<?php
					$this->get_title( 75, 'h3' );
					$this->get_meta();
					?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
