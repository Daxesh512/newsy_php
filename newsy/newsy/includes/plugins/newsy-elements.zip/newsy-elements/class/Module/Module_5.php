<?php
namespace NewsyElements\Module;

/**
 * Class Module_5.
 */
class Module_5 extends ModuleAbstract {

	public $module_id = 'module_5';

	public $module_class = 'ak-module-5';

	public $module_image = 'newsy_750x375';

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-featured clearfix">
					<?php $this->get_badge_icon(); ?>
					<?php $this->get_featured_image( '', false, false ); ?>
					<?php $this->get_category(); ?>
				</div>
				<div class="ak-module-details">
					<?php $this->get_category( 'inline' ); ?>
					<?php $this->get_title(); ?>
					<?php $this->get_meta(); ?>
					<?php $this->get_excerpt( 250 ); ?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
