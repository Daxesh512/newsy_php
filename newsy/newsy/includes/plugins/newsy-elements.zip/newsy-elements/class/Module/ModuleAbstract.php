<?php
namespace NewsyElements\Module;

/**
 * Main class for post modules.
 *
 * Class ModuleAbstract
 */
abstract class ModuleAbstract {

	/**
	 * @var WP_Post
	 */
	public $post;

	public $title_attribute;

	public $title;

	public $href;

	public $post_format;

	public $module_id;

	public $module_class;

	public $module_image;

	public $featured_meta = false;

	public $show_video_duration = false;

	public $atts = array(
		'title_length'       => '',
		'excerpt_length'     => '',
		'show_excerpt'       => '',
		'show_category'      => '',
		'show_category_type' => 'badge',
		'category_limit'     => '1',
		'show_meta'          => '',
		'show_author_icon'   => '',
		'show_author'        => '',
		'show_view_count'    => '',
		'show_comment_count' => '',
		'show_share_count'   => '',
		'show_voting_count'  => '',
		'show_date'          => '',
		'date_format'        => '',
		'custom_date_format' => 'F j, Y',
		'show_badge_icon'    => '',
		'show_format_icon'   => '',
		'show_social_share'  => '',
	);

	/**
	 * @param WP_Post $post WP_Post
	 * @param array $args Module args
	 *
	 * @throws ErrorException
	 */
	public function __construct( $post, $args = array() ) {
		$this->post = $post;

		// by default the WordPress title is not escaped on twenty fifteen
		$this->title           = get_the_title( $post->ID );
		$this->title_attribute = esc_attr( strip_tags( $this->title ) );
		$this->href            = esc_url( get_permalink( $post->ID ) );
		$this->post_format     = get_post_format( $post->ID );

		if ( ! empty( $args ) ) {
			if ( ! empty( $args['class'] ) ) {
				$this->module_class = $this->module_class . ' ' . $args['class'];
			}
			if ( ! empty( $args['image-size'] ) ) {
				$this->module_image = $args['image-size'];
			}
		}

		$atts = ! empty( $args['atts'] ) ? $args['atts'] : array();

		$this->set_module_atts( $atts );

		unset( $atts );
	}

	/**
	 * Set module attributes.
	 */
	public function set_module_atts( $atts = array() ) {
		if ( empty( $atts ) ) {
			$atts = apply_filters( 'newsy_block_module_atts', array(), $this->module_id );
		}

		$this->atts = array_merge( $this->atts, $atts );
	}

	/**
	 * Get Module classes.
	 *
	 * @param array $additional
	 * @return string
	 */
	public function get_module_classes( $additional = array() ) {
		//add the wrap and module id class
		$class = str_replace( 'hentry', '', implode( ' ', get_post_class( 'ak-module ' . $this->module_class, $this->post->ID ) ) );

		// fix the meta info space when all options are off
		if ( 'hide' === $this->atts['show_meta'] ) {
			$class .= ' ak-module-meta-hide';
		}
		// fix the meta info space when all options are off
		if ( 'hide' === $this->atts['show_excerpt'] ) {
			$class .= ' ak-module-excerpt-hide';
		}

		if ( '' !== $additional && is_array( $additional ) ) {
			$class .= ' ' . implode( ' ', $additional );
		}

		$class .= ' clearfix';

		return $class;
	}

	/**
	 * Get the module title
	 *
	 * @param string|int $length
	 * @param string $tag
	 * @return string
	 */
	public function get_title( $length = '', $tag = 'h3' ) {
		$output = '';

		// If module excerpt length set
		if ( ! empty( $this->atts['title_length'] ) ) {
			$length = intval( $this->atts['title_length'] );
		}
		if ( ! empty( $length ) ) {
			$this->title = ak_limit_words( $this->title, $length, '&hellip;' );
		}

		if ( ! empty( $this->title ) ) {
			$output .= "<{$tag} class=\"ak-module-title\">";
			$output .= '<a href="' . $this->href . '" rel="bookmark" title="' . $this->title_attribute . '">';
			$output .= $this->title;
			$output .= '</a>';
			$output .= "</{$tag}>";
		}

		ak_sanitize_echo( $output );
	}

	/**
	 * Get the module excerpt.
	 *
	 * @param integer $length
	 * @param boolean $show_more
	 * @return void
	 */
	public function get_excerpt( $length = 0, $show_more = true ) {
		if ( 'hide' === $this->atts['show_excerpt'] ) {
			return;
		}

		$text = $this->post->post_excerpt;

		// If text not defined get excerpt
		if ( ! $text ) {
			$text = $this->post->post_content;
		}

		// If module excerpt length set
		if ( ! empty( $this->atts['excerpt_length'] ) ) {
			$length = intval( $this->atts['excerpt_length'] );
		}

		$text = preg_replace( '/\[caption(.*)\[\/caption\]/i', '', $text );
		$text = preg_replace( '/\[[^\]]*\]/', '', $text );
		$text = wp_kses( $text, 'strip' );

		// get plaintext excerpt trimmed to right length
		if ( $length > 0 ) {
			$excerpt = ak_html_limit_words( $text, $length, '&hellip;' );
		} else {
			$excerpt = $text;
		}

		// fix extra spaces
		$excerpt = str_replace( '&nbsp;', ' ', $excerpt );

		$output  = '<div class="ak-module-summary"><p>';
		$output .= $excerpt;
		$output .= '</p></div>';

		ak_sanitize_echo( $output );
	}

	/**
	 * v3 23 ian 2015.
	 *
	 * @param $thumbType
	 *
	 * @return string
	 */
	public function get_featured_image( $image_size = '', $inline = false, $auto_wrap = false, $video = false ) {
		if ( empty( $image_size ) ) {
			$image_size = $this->module_image;
		}

		$output = '<div class="ak-featured-cover">';
		if ( $video && 'video' === $this->post_format && function_exists( 'newsy_get_post_featured_video' ) ) {
			$output = newsy_get_post_featured_video( $this->post->ID );
			if ( '' !== $output ) {
				echo "<div class=\"ak-featured-cover\">{$output}</div>";
				return;
			}
		}

		$output .= newsy_module_edit_post_link( $this->post->ID );

		$output .= $this->get_format_icon();

		$output .= '<a href="' . $this->href . '" class="ak-featured-link" rel="bookmark" title="' . $this->title_attribute . '">';

		$output .= ak_get_post_image( $this->post->ID, $image_size, $inline, $auto_wrap );

		$output .= '</a></div>';

		ak_sanitize_echo( $output );
	}

	public function get_format_icon() {
		if ( 'hide' === $this->atts['show_format_icon'] ) {
			return;
		}

		$output = '';

		if ( $this->post_format ) {
			switch ( $this->post_format ) {
				case 'video':
					$output = '<span class="ak-module-format-icon format-video"><i class="ak-icon fa fa-play"></i></span>';
					if ( $this->show_video_duration ) {
						$output .= $this->get_video_format_time();
					}
					break;

				case 'gallery':
				case 'image':
					$output = '<span class="ak-module-format-icon format-' . $this->post_format . '"><i class="ak-icon fa fa-camera"></i></span>';
					break;
			}
		}

		ak_sanitize_echo( $output );
	}

	public function get_video_format_time() {
		$output = '';

		if ( 'video' === $this->post_format ) {
			$video = ak_get_post_meta( 'featured_video', $this->post->ID );

			if ( isset( $video['time'] ) ) {
				$this->featured_meta = false;

				$output .= '<div class="ak-module-video-duration"><div class="inactive">' . $video['time'] . '</div><div class="active">' . ak_get_translation( 'Watch', 'newsy-elements', 'watch' ) . '</div></div>';
			}
		}

		ak_sanitize_echo( $output );
	}

	public function get_category( $type = 'badge' ) {
		if ( 'hide' === $this->atts['show_category'] || 'post' !== $this->post->post_type ) {
			return;
		}
		$output   = '';
		$cat_type = $this->atts['show_category_type'];

		if ( $cat_type === $type || 'inline_badge' === $cat_type && 'inline' === $type ) {
			$cat_html = newsy_elements_get_post_categories( $this->post->ID, intval( $this->atts['category_limit'] ) );

			$output = "<div class=\"ak-module-terms {$cat_type}\">{$cat_html}</div>";
		}

		ak_sanitize_echo( $output );
	}

	public function get_featured_meta() {
		if ( ! $this->featured_meta || 'hide' === $this->atts['show_meta'] ) {
			return;
		}

		$output = '';

		$output .= '<div class="ak-module-featured-meta">';
		$output .= $this->get_comment_count();
		$output .= $this->get_view_count();
		$output .= $this->get_share_count();
		$output .= $this->get_voting_count();
		$output .= '</div>';

		ak_sanitize_echo( $output );
	}

	public function get_meta() {
		if ( 'hide' === $this->atts['show_meta'] ) {
			return;
		}

		$output = '';

		if ( 'product' === $this->post->post_type ) {
			$output .= $this->get_product_meta();
		} else {
			$output .= $this->get_author();
			$output .= $this->get_date();

			if ( ! $this->featured_meta ) {
				$output .= $this->get_comment_count();
				$output .= $this->get_view_count();
				$output .= $this->get_share_count();
				$output .= $this->get_voting_count();
			}
		}

		$output = "<div class=\"ak-module-meta\">{$output}</div>";

		ak_sanitize_echo( $output );
	}

	public function get_author() {
		if ( 'hide' === $this->atts['show_author_icon'] && 'hide' === $this->atts['show_author'] ) {
			return '';
		}

		$author_url  = get_author_posts_url( $this->post->post_author );
		$author_name = get_the_author_meta( 'display_name', $this->post->post_author );

		$output = '<div class="ak-module-author">';

		if ( 'hide' !== $this->atts['show_author_icon'] ) {
			$output .= '<a href="' . $author_url . '">' . get_avatar( $this->post->post_author, 22, null, $author_name, array( 'class' => 'post-author-avatar' ) ) . '</a>';
		}

		if ( 'hide' !== $this->atts['show_author'] ) {
			$output .= '<span class="ak-module-author-by">by</span>';
			$output .= '<a href="' . $author_url . '" class="ak-module-author-name">' . $author_name . '</a>';
		}

		$output .= '</div>';

		return $output;
	}

	public function get_date() {
		if ( 'hide' === $this->atts['show_date'] ) {
			return '';
		}

		if ( 'custom' === $this->atts['date_format'] ) {
			$post_time = get_the_time( $this->atts['custom_date_format'], $this->post->ID );
		} elseif ( 'ago' === $this->atts['date_format'] ) {
			$post_time = sprintf( ak_get_translation( '%s ago', 'newsy-elements', 'readable_time_ago' ), ak_ago_time( get_the_time( 'U', $this->post->ID ) ) );
		} else {
			$post_time = get_the_time( get_option( 'date_format' ), $this->post->ID );
		}

		$output  = '<div class="ak-module-time">';
		$output .= '<a href="' . $this->href . '" class="ak-module-meta-published"><i class="ak-icon akfi-schedule"></i>';
		$output .= esc_html( $post_time );
		$output .= '</a></div>';

		return $output;
	}

	public function get_comment_count() {
		if ( 'hide' === $this->atts['show_comment_count'] ) {
			return '';
		}
		if ( function_exists( 'newsy_get_post_comment_count' ) ) {
			$comments_number = newsy_get_post_comment_count( $this->post->ID );
		} else {
			$comments_number = get_comments_number( $this->post->ID );
		}

		$output = '';
		if ( $comments_number > 0 ) {
			$output .= '<div class="ak-module-comments">';
			$output .= '<a href="' . get_comments_link( $this->post->ID ) . '" class="link"><i class="ak-icon fa fa-comment-o"></i>';
			$output .= '<span class="post-comments-count">';
			$output .= apply_filters( 'newsy_number_format', $comments_number );
			$output .= '</span>';
			$output .= '</a>';
			$output .= '</div>';
		}

		return $output;
	}

	public function get_view_count() {
		if ( 'hide' === $this->atts['show_view_count'] || ! function_exists( 'newsy_get_post_view_count' ) ) {
			return '';
		}

		$post_views = newsy_get_post_view_count( $this->post->ID );

		$output = '';
		if ( $post_views > 0 ) {
			$output .= ' <div class="ak-module-view-count">';
			$output .= apply_filters( 'newsy_view_count_format', $post_views );
			$output .= '</div>';
		}

		return $output;
	}

	public function get_share_count() {
		if ( 'hide' === $this->atts['show_share_count'] || ! function_exists( 'newsy_get_share_counts' ) ) {
			return '';
		}

		$post_share = newsy_get_share_counts( $this->post->ID, true );

		$output = '';

		if ( $post_share['total'] > 0 ) {
			$output .= ' <div class="ak-module-share-count">';
			$output .= '<i class="ak-icon fa fa-share"></i>';
			$output .= '<span class="count">';
			$output .= apply_filters( 'newsy_number_format', $post_share['total'] );
			$output .= '</span>';
			$output .= '</div>';
		}

		return $output;
	}

	public function get_voting_count() {
		if ( 'hide' === $this->atts['show_voting_count'] || ! function_exists( 'newsy_get_voting_counts' ) ) {
			return '';
		}

		$output = '';

		$post_vote_count = newsy_get_voting_counts( $this->post->ID );

		if ( $post_vote_count > 0 ) {
			$output .= '<div class="ak-module-voting-count">';
			$output .= '<i class="ak-icon akfi-import_export"></i>';
			$output .= '<span class="count">';
			$output .= apply_filters( 'newsy_number_format', $post_vote_count );
			$output .= '</span>';
			$output .= '</div>';
		}

		return $output;
	}

	public function get_meta_bottom() {
		if ( 'hide' === $this->atts['show_share_count'] && 'hide' === $this->atts['show_voting_count'] ) {
			return;
		}

		$output = apply_filters( 'newsy_module_bottom_meta', '', $this->post->ID );

		newsy_sanitize_echo( $output );
	}

	public function get_badge_icon( $show_both = false, $show_count = 1 ) {
		if ( 'hide' === $this->atts['show_badge_icon'] || 'post' !== $this->post->post_type ) {
			return;
		}

		$output = apply_filters( 'newsy_post_badge_icons', '', $this->post->ID, $show_count, $show_both );

		$output = "<div class=\"ak-module-badges\">{$output}</div>";

		ak_sanitize_echo( $output );
	}

	private function get_product_meta() {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		$_product = wc_get_product( $this->post->ID );

		$price_html  = $_product->get_price_html();
		$add_to_html = wc_get_template_html(
			'single-product/add-to-cart/external.php',
			array(
				'product_url' => $_product->add_to_cart_url(),
				'button_text' => $_product->single_add_to_cart_text(),
			)
		);

		$attributes = array(
			'aria-label'       => $_product->add_to_cart_description(),
			'data-quantity'    => '1',
			'data-product_id'  => $_product->get_id(),
			'data-product_sku' => $_product->get_sku(),
			'rel'              => 'nofollow',
			'class'            => 'wp-block-button__link add_to_cart_button btn btn-xs btn-box rounded',
		);
		if ( $_product->supports( 'ajax_add_to_cart' ) ) {
			$attributes['class'] .= ' ajax_add_to_cart';
		}

		$add_to_html = sprintf(
			'<a href="%s" %s>%s</a>',
			esc_url( $_product->add_to_cart_url() ),
			wc_implode_html_attributes( $attributes ),
			esc_html( $_product->add_to_cart_text() )
		);

		return "<div class=\"ak-module-add-to-cart\">{$add_to_html}</div><div class=\"ak-module-product-price\">{$price_html}</div>";
	}

}
