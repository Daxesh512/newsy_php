<?php

namespace NewsyElements\Plugin;

/**
 * Newsy Elementor plugin compatibility handler.
 */
class Elementor {

	/**
	 * @var Elementor
	 */
	private static $instance;

	/**
	 * @return Elementor
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	/**
	 * Newsy_bbPress constructor.
	 */
	public function __construct() {
		$this->hook();
	}

	/**
	 * Callback: adds some code change to bbPress and other simple things.
	 *
	 * Filter: init
	 */
	public function hook() {
		// frontend script & style
		add_action( 'elementor/frontend/after_enqueue_scripts', array( $this, 'register_script' ), 99 );

		// editor script & style
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'register_editor_scripts' ) );

		// check width of section
		add_action( 'elementor/frontend/before_render', array( $this, 'register_width' ) );
		add_action( 'elementor/frontend/element/before_render', array( $this, 'register_width' ) );
		add_action( 'elementor/editor/element/before_raw_data', array( $this, 'register_width' ) );
	}

	public function register_script() {
		wp_enqueue_script( 'newsy-elementor-frontend', NEWSY_ELEMENTS_URI . '/assets/js/elementor.frontend.js', null, NEWSY_ELEMENTS_VERSION, null );
	}

	public function register_editor_scripts() {
		wp_enqueue_script( 'newsy-elementor-editor-js', NEWSY_ELEMENTS_URI . '/assets/js/elementor.editor.js', null, NEWSY_ELEMENTS_VERSION, true );
	}

	private function get_column_width( $width ) {
		if ( $width < 34 ) {
			$block_width = 1;
		} elseif ( $width < 67 ) {
			$block_width = 2;
		} else {
			$block_width = 3;
		}

		return $block_width;
	}

	/**
	 * @param Element_Column $object
	 */
	public function register_width( $object ) {
		if ( $object instanceof \Elementor\Element_Column ) {
			$setting = $object->get_settings();

			$block_width = $this->get_column_width( $setting['_column_size'] );
			add_filter(
				'newsy_block_width', function() use ( $block_width ) {
					return $block_width;
				}
			);
		}
	}
}
