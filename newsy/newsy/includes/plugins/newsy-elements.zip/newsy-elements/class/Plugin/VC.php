<?php

namespace NewsyElements\Plugin;

/**
 * Newsy Visual Composer plugin compatibility handler.
 */
class VC {

	/**
	 * @var VC
	 */
	private static $instance;

	/**
	 * @return VC
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	/**
	 * VC constructor.
	 */
	public function __construct() {
		$this->hook();
	}

	/**
	 * Callback: adds some code change to bbPress and other simple things.
	 *
	 * Filter: init
	 */
	public function hook() {
		// editor script & style
		add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ), 99 );
		add_action( 'admin_enqueue_scripts', array( $this, 'register_admin_scripts' ), 999 );

		add_filter( 'vc_shortcodes_css_class', array( $this, 'vc_block_class' ), 100, 2 );
	}

	public function register_scripts() {
		if ( function_exists( 'vc_is_page_editable' ) && vc_is_page_editable() ) {
			wp_enqueue_script( 'newsy-vc-inline', NEWSY_ELEMENTS_URI . '/assets/js/vc.editor.js', null, null, true );
		}
	}

	public function register_admin_scripts() {
		if ( function_exists( 'vc_is_frontend_editor' ) && vc_is_frontend_editor() ) {
			wp_enqueue_script( 'newsy-vc-frontend', NEWSY_ELEMENTS_URI . '/assets/js/vc.frontend.js', array( 'jquery' ), null, true );
		}
	}

	public function vc_block_class( $class = '', $base = '', $atts = array() ) {
		$_check = array(
			'vc_gmaps'              => '',
			'vc_toggle'             => '',
			'vc_gallery'            => '',
			'vc_images_carousel'    => '',
			'vc_posts_slider'       => '',
			'vc_progress_bar'       => '',
			'vc_pie'                => '',
			'vc_round_chart'        => '',
			'vc_line_chart'         => '',
			'vc_media_grid'         => '',
			'vc_masonry_media_grid' => '',
		);

		if ( isset( $_check[ $base ] ) ) {
			$class .= ' ak-block';
		}

		return $class;
	}
}
