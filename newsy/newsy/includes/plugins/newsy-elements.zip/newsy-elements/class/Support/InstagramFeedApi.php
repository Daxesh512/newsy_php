<?php
/**
 * @author akbilisim
 */
namespace NewsyElements\Support;

class InstagramFeedApi {
	/**
	 * @var $userid
	 */
	protected $userid;

	/**
	 * @var $username
	 */
	protected $username;

	/**
	 * @var $access_token
	 */
	protected $access_token;

	/**
	 * @var $transient_id
	 */
	protected $transient_id;

	/**
	 * Instance of InstagramFeedApi
	 *
	 * @var InstagramFeedApi
	 */
	private static $instance;

	/**
	 * Singleton page of InstagramFeedApi class
	 *
	 * @return InstagramFeedApi
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	/**
	 * InstagramFeedApi constructor.
	 */
	private function __construct() {
		$this->setup_hook();
	}

	/**
	 * Setup Hook
	 */
	private function setup_hook() {
		$this->userid       = $this->get( 'id' );
		$this->username     = $this->get( 'username' );
		$this->access_token = $this->get( 'access_token' );
		$this->transient_id = 'newsy_instagram_feed_cache_' . $this->userid;

		add_action( 'init', array( $this, 'init_instagram_page' ) );
		add_action( 'admin_init', array( $this, 'refresh_access_token' ) );
	}

	/**
	 * Override smash ballon page
	 */
	public function init_instagram_page() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) | $this->is_sb_activate() ) {
			return;
		}

		if ( ! empty( $_GET['page'] ) && 'sb-instagram-feed' === $_GET['page'] ) {
			if ( ! empty( $_GET['access_token'] ) ) {
				$user_id = sanitize_text_field( $_GET['id'] );
				$account = array(
					'id'           => $user_id,
					'username'     => sanitize_text_field( $_GET['username'] ),
					'access_token' => $this->clean( sanitize_text_field( $_GET['access_token'] ) ),
					'expires_on'   => (int) $_GET['expires_in'] + time(),
				);
				update_option( 'newsy_instagram', $account );
				delete_transient( 'newsy_instagram_feed_cache_' . $user_id );
			}

			// Redirect
			wp_redirect( admin_url( '/' ) );

			exit;
		}
	}

	/**
	 * Check if smash ballon plugin active
	 *
	 * @return bool
	 */
	public function is_sb_activate() {
		return function_exists( 'sb_instagram_feed_init' );
	}

	/**
	 * Make the connection to Instagram
	 */
	public function get_data() {
		if ( ! $this->is_active() ) {
			return false;
		}

		if ( get_transient( $this->transient_id ) !== false ) {
			return get_transient( $this->transient_id );
		}

		$this->refresh_access_token();

		$args = array(
			'fields'       => 'media_url,thumbnail_url,caption,id,media_type,timestamp,username,comments_count,like_count,permalink',
			'limit'        => 20,
			'access_token' => $this->access_token,
		);

		$url = add_query_arg( $args, "https://graph.instagram.com/$this->userid/media" );

		$request = $this->remote_get( $url );

		if ( is_wp_error( $request ) ) {
			return $request;
		}

		$media = wp_remote_retrieve_body( $request );
		$media = json_decode( $media, true );

		$expiration = 24 * HOUR_IN_SECONDS;

		set_transient( $this->transient_id, $media['data'], $expiration );

		return $media['data'];
	}

	/**
	 * Check if need to refresh the Access Token.
	 *
	 * @return bool
	 */
	private function time_passed_threshold() {
		$expiration_time   = $this->get( 'expires_on' );
		$refresh_threshold = $expiration_time - ( 30 * DAY_IN_SECONDS );

		return $refresh_threshold < time();
	}

	/**
	 * Refresh access token if needed.
	 * Valid for 60 days and refresh every 30 days
	 *
	 * @return bool|mixed|string|void|\WP_Error
	 */
	public function refresh_access_token() {
		if ( ! $this->is_active() ) {
			return false;
		}

		if ( ! $this->time_passed_threshold() ) {
			return;
		}

		$url = add_query_arg(
			array(
				'grant_type'   => 'ig_refresh_token',
				'access_token' => $this->access_token,
			),
			'https://graph.instagram.com/refresh_access_token'
		);

		$request = $this->remote_get( $url );

		if ( is_wp_error( $request ) ) {
			return $request;
		}

		$data = wp_remote_retrieve_body( $request );
		$data = json_decode( $data, true );

		if ( ! empty( $data['access_token'] ) ) {
			$access_token = $this->clean( sanitize_text_field( $data['access_token'] ) );
			$expires_on   = (int) $data['expires_in'] + time();

			$this->update( 'access_token', $access_token );
			$this->update( 'expires_on', $expires_on );
		}
	}

	/**
	 * Get Instagram token option
	 *
	 * @param bool $key
	 *
	 * @return bool
	 */
	public function get( $key = false ) {
		$instagram_token = get_option( 'newsy_instagram', array() );
		if ( empty( $instagram_token ) ) {
			return false;
		}
		if ( ! empty( $instagram_token[ $key ] ) ) {
			return $instagram_token[ $key ];
		}

		return false;
	}

	/**
	 * Update Instagram token option
	 *
	 * @param bool $key
	 * @param bool $value
	 */
	public function update( $key = false, $value = false ) {

		if ( empty( $key ) || empty( $value ) ) {
			return;
		}

		$account = get_option( 'newsy_instagram', array() );

		$account[ $key ] = $value;

		update_option( 'newsy_instagram', $account );
	}

	/**
	 * Clean Access TokenClean Access Token
	 *
	 * @param $maybe_dirty
	 *
	 * @return string|string[]
	 */
	protected function clean( $maybe_dirty ) {
		if ( substr_count( $maybe_dirty, '.' ) < 3 ) {
			return str_replace( '634hgdf83hjdj2', '', $maybe_dirty );
		}

		$parts     = explode( '.', trim( $maybe_dirty ) );
		$last_part = $parts[2] . $parts[3];
		$cleaned   = $parts[0] . '.' . base64_decode( $parts[1] ) . '.' . base64_decode( $last_part );

		return $cleaned;
	}

	/**
	 * Check if there is a connected account
	 *
	 * @return bool
	 */
	public function is_active() {
		$is_active = false;

		if ( $this->userid && $this->access_token ) {
			$is_active = true;
		}

		return $is_active;
	}

	/**
	 * Check if the Access token is expired
	 *
	 * @return bool
	 */
	public function is_expired() {
		if ( ! $this->is_active() ) {
			return false;
		}

		$expires_on = $this->get( 'expires_on' );

		return empty( $expires_on ) || ( ! empty( $expires_on ) && $expires_on < time() );
	}

	/**
	 * Get the app callback
	 *
	 * @return string
	 */
	public function get_api_url() {
		$instagram_app = 'https://api.instagram.com/oauth/authorize?app_id=423965861585747&redirect_uri=https://api.smashballoon.com/instagram-basic-display-redirect.php&response_type=code&scope=user_profile,user_media&state=' . admin_url( 'admin.php?page=sb-instagram-feed' );

		return  $instagram_app;
	}

	/**
	 * Make the connection to Instagram
	 *
	 * @param bool $url
	 *
	 * @return bool|mixed|string|WP_Error
	 */
	protected function remote_get( $url = false ) {
		$args = array(
			'timeout'    => 30,
			'user-agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36',
		);

		$request = wp_remote_get( $url, $args );

		return $this->check_for_errors( $request );
	}

	/**
	 * Check if the reply has error
	 *
	 * @param bool|object $response
	 *
	 * @return bool|mixed|string|WP_Error
	 */
	protected function check_for_errors( $response = false ) {

		// Check Response for errors
		$response_code    = wp_remote_retrieve_response_code( $response );
		$response_message = wp_remote_retrieve_response_message( $response );

		if ( is_wp_error( $response ) ) {
			return new \WP_Error( 'http_error', $response->get_error_message() );
		}

		if ( ! empty( $response->errors ) && isset( $response->errors['http_request_failed'] ) ) {
			return new \WP_Error( 'http_error', esc_html( current( $response->errors['http_request_failed'] ) ) );
		}

		if ( 200 !== $response_code ) {

			// Get value of Error - contains more details
			$response = wp_remote_retrieve_body( $response );
			$response = json_decode( $response, true );

			if ( ! empty( $response['error']['message'] ) ) {
				return new \WP_Error( $response_code, $response['error']['message'] );
			}

			if ( empty( $response_message ) ) {
				return new \WP_Error( $response_code, 'Connection Error' );
			} else {
				return new \WP_Error( $response_code, $response_message );
			}
		}

		return $response;
	}

	/**
	 * Get the Error Messages
	 *
	 * @param bool $error_id
	 *
	 * @return string
	 */
	public function get_error( $error_id = false ) {
		if ( ! empty( $error_id ) ) {
			switch ( $error_id ) {
				case 'inactive':
					return esc_html__( ' Open this block in your editor and connect your Instagram account.', 'newsy-elements' );
					break;

				case 'expired':
					return esc_html__( 'The Instagram Access Token is expired, Open this block in your editor and refresh it.', 'newsy-elements' );
					break;
			}
		}
	}
}
