<?php

add_filter( 'newsy_post_badge_icons', 'newsy_register_post_badge_icons', 11, 4 );

if ( ! function_exists( 'newsy_register_post_badge_icons' ) ) {
	/**
	 * Filter get post badge icons.
	 *
	 * @return array
	 */
	function newsy_register_post_badge_icons( $output, $post_id, $show_count = 1, $show_both = true ) {
		$prim_cat = newsy_get_post_primary_category( $post_id );

		if ( $prim_cat ) {
			$output .= newsy_get_term_badge_icon( $prim_cat );
		}

		return $output;
	}
}

add_filter( 'newsy_block_order_by_options', 'newsy_block_order_by_options' );

if ( ! function_exists( 'newsy_block_order_by_options' ) ) {
	/**
	 * Register the block order by options.
	 *
	 * @return array
	 */
	function newsy_block_order_by_options( $options = array() ) {
		// framework query types
		$options['latest']        = ak_get_translation( 'Latest', 'newsy-elements', 'latest' );
		$options['oldest']        = ak_get_translation( 'Oldest', 'newsy-elements', 'oldest' );
		$options['alphabet_asc']  = ak_get_translation( 'Alphabet Asc', 'newsy-elements', 'alphabet_asc' );
		$options['alphabet_desc'] = ak_get_translation( 'Alphabet Desc', 'newsy-elements', 'alphabet_desc' );
		$options['random']        = ak_get_translation( 'Random', 'newsy-elements', 'random' );
		$options['comment_count'] = ak_get_translation( 'Comments', 'newsy-elements', 'comments' );

		return $options;
	}
}

if ( ! function_exists( 'newsy_get_block_order_by_tabs' ) ) {
	/**
	 * Get tje block order tabs
	 *
	 * @param array $exclude
	 * @return array
	 */
	function newsy_get_block_order_by_tabs( $exclude = array() ) {
		$options = apply_filters( 'newsy_block_order_by_options', array() );

		if ( ! empty( $exclude ) ) {
			foreach ( $exclude as $option ) {
				unset( $options[ $option ] );
			}
		}

		return $options;
	}
}

add_filter( 'newsy_block_width', 'newsy_editor_block_width', 100 );

if ( ! function_exists( 'newsy_editor_block_width' ) ) {
	/**
	 * Hook for detect block with from ajax request.
	 *
	 * @return mixed
	 */
	function newsy_editor_block_width( $width ) {
		if ( isset( $_REQUEST['block_width'] ) ) {
			return esc_attr( $_REQUEST['block_width'] );
		}

		return $width;
	}
}

add_filter( 'user_contactmethods', 'newsy_contact_methods_filter', 10, 1 );

if ( ! function_exists( 'newsy_contact_methods_filter' ) ) {
	/**
	 * Callback: Used for adding contact methods to user meta.
	 * Used on Author Box and various places.
	 *
	 * Filter: user_contactmethods

	 * @param $methods
	 *
	 * @return array
	 */
	function newsy_contact_methods_filter( $methods ) {
		foreach ( newsy_get_author_contact_methods() as $social_id => $social_name ) {
			$methods[ $social_id ] = $social_name;
		}

		return $methods;
	}
}

add_filter( 'vc_translate_column_width_class', 'newsy_register_vc_block_width', 99 );

if ( ! function_exists( 'newsy_register_vc_block_width' ) ) {
	/**
	 * Hook visual composer column with and apply to our block width.
	 *
	 * Filter: vc_translate_column_width_class

	 * @param $output
	 *
	 * @return string
	 */
	function newsy_register_vc_block_width( $output ) {
		$block_width = 1;
		if ( $output ) {
			$tmp          = explode( '-', $output );
			$column_width = end( $tmp );

			if ( $column_width > 8 ) {
				$block_width = 3;
			} elseif ( $column_width <= 8 && $column_width > 4 ) {
				$block_width = 2;
			}
		}
		add_filter(
			'newsy_block_width', function() use ( $block_width ) {
				return $block_width;
			}
		);

		return $output;
	}
}
