<?php

if ( ! function_exists( 'newsy_get_block_supported_classes' ) ) {
	/**
	 *  Get the supported block classes.
	 *
	 * @return array
	 */
	function newsy_get_block_supported_classes() {
		return apply_filters(
			'newsy_block_supported_classes', array(
				'dark'                            => __( 'Dark Block', 'newsy-elements' ),
				'ak-block-boxed'                  => __( 'Boxed Block', 'newsy-elements' ),
				'ak-block-inner-boxed'            => __( 'ak-block-inner-boxed', 'newsy-elements' ),
				'ak-block-module-boxed'           => __( 'ak-block-module-boxed', 'newsy-elements' ),
				'ak-block-module-inner-boxed'     => __( 'ak-block-module-inner-boxed', 'newsy-elements' ),
				'ak-block-module-inner-highlight' => __( 'ak-block-module-inner-highlight', 'newsy-elements' ),
				'ak-block-module-center-elements' => __( 'ak-block-module-center-elements', 'newsy-elements' ),
				'ak-block-module-seperator-line'  => __( 'ak-block-module-seperator-line', 'newsy-elements' ),
				'ak-block-module-thumb-round'     => __( 'ak-block-module-thumb-round', 'newsy-elements' ),
				'ak-block-shadow'                 => __( 'ak-block-shadow', 'newsy-elements' ),
				'ak-block-item-shadow'            => __( 'ak-block-item-shadow', 'newsy-elements' ),
				'ak-visible-sm'                   => __( 'Show On Phone', 'newsy-elements' ),
				'ak-hidden-sm'                    => __( 'Hide On Phone', 'newsy-elements' ),
				'ak-visible-md'                   => __( 'Show On Table', 'newsy-elements' ),
				'ak-hidden-md'                    => __( 'Hide On Table', 'newsy-elements' ),
				'ak-visible-lg'                   => __( 'Show On Desktop', 'newsy-elements' ),
				'ak-visible-lg'                   => __( 'Hide On Desktop ', 'newsy-elements' ),
			)
		);
	}
}

if ( ! function_exists( 'newsy_get_block_order_by_options' ) ) {
	/**
	 * Get the block orders field options.
	 *
	 * @return array
	 */
	function newsy_get_block_order_by_options( $options = array() ) {
		$options = apply_filters( 'newsy_block_order_by_options', $options );

		// add readable option names
		$options['alphabet_asc']  = __( 'Alphabet Asc', 'newsy-elements' );
		$options['alphabet_desc'] = __( 'Alphabet Desc', 'newsy-elements' );
		$options['comment_count'] = __( 'Number of Comments', 'newsy-elements' );

		return apply_filters( 'newsy_get_block_order_by_options', $options );
	}
}


if ( ! function_exists( 'newsy_get_ad_size_options' ) ) {
	/**
	 * Handy callback to get ads sizes.
	 *
	 * @return array
	 */
	function newsy_get_ad_size_options() {
		return array(
			''        => esc_attr__( 'Auto', 'newsy-elements' ),
			'hide'    => esc_attr__( 'Hide', 'newsy-elements' ),
			'120x90'  => '120x90',
			'120x240' => '120x240',
			'120x600' => '120x600',
			'125x125' => '125x125',
			'160x90'  => '160x90',
			'160x600' => '160x600',
			'180x90'  => '180x90',
			'180x150' => '180x150',
			'200x90'  => '200x90',
			'200x200' => '200x200',
			'234x60'  => '234x60',
			'250x250' => '250x250',
			'320x100' => '320x100',
			'300x250' => '300x250',
			'300x600' => '300x600',
			'320x50'  => '320x50',
			'336x280' => '336x280',
			'468x15'  => '468x15',
			'468x60'  => '468x60',
			'728x15'  => '728x15',
			'728x90'  => '728x90',
			'970x90'  => '970x90',
			'240x400' => '240x400',
			'250x360' => '250x360',
			'580x400' => '580x400',
			'750x100' => '750x100',
			'750x200' => '750x200',
			'750x300' => '750x300',
			'980x120' => '980x120',
			'930x180' => '930x180',
		);
	}
}

if ( ! function_exists( 'newsy_get_grid_overlay_styles' ) ) {
	/**
	 * Get the grid overlay styles field options.
	 *
	 * @return array
	 */
	function newsy_get_grid_overlay_styles() {
		$styles = array();

		$styles['default'] = array(
			'label'   => __( 'Defaults', 'newsy-elements' ),
			'options' => array(
				''               => __( 'Default', 'newsy-elements' ),
				'tg-gradient'    => __( 'Gradient', 'newsy-elements' ),
				'tg-center'      => __( ' Center ', 'newsy-elements' ),
				'tg-center-left' => __( ' Center Left', 'newsy-elements' ),
			),
		);

		$styles[] = array(
			'label'   => __( 'Focus', 'newsy-elements' ),
			'options' => array(
				'tg-focus'                => __( 'Focus', 'newsy-elements' ),
				'tg-gradient tg-focus'    => __( 'Focus + Gradient', 'newsy-elements' ),
				'tg-focus tg-center'      => __( 'Focus + Center', 'newsy-elements' ),
				'tg-focus tg-center-left' => __( 'Focus + Center-Left', 'newsy-elements' ),
			),
		);

		$styles[] = array(
			'label'   => __( 'Colored', 'newsy-elements' ),
			'options' => array(
				'tg-colored'                         => __( 'Colored', 'newsy-elements' ),
				'tg-colored tg-focus'                => __( 'Colored + Focus', 'newsy-elements' ),
				'tg-colored tg-center'               => __( 'Colored + Center', 'newsy-elements' ),
				'tg-colored tg-center tg-focus'      => __( 'Colored + Center + Focus', 'newsy-elements' ),
				'tg-colored tg-center-left'          => __( 'Colored + Center-Left', 'newsy-elements' ),
				'tg-colored tg-center-left tg-focus' => __( 'Colored + Center-Left + Focus', 'newsy-elements' ),
			),
		);

		$styles[] = array(
			'label'   => __( 'Single Colored', 'newsy-elements' ),
			'options' => array(
				'tg-colored-single'          => __( 'Single Colored', 'newsy-elements' ),
				'tg-colored-single tg-focus' => __( 'Single Colored + Focus', 'newsy-elements' ),
			),
		);

		$styles[] = array(
			'label'   => __( 'Box', 'newsy-elements' ),
			'options' => array(
				'tg-box'                    => __( 'Box', 'newsy-elements' ),
				'tg-box tg-focus'           => __( 'Box + Focus', 'newsy-elements' ),
				'tg-box tg-center'          => __( 'Box + Center ', 'newsy-elements' ),
				'tg-box tg-center tg-focus' => __( 'Box + Center + Focus', 'newsy-elements' ),
			),
		);

		$styles[] = array(
			'label'   => __( 'Text Highlight', 'newsy-elements' ),
			'options' => array(
				'tg-highlight'                         => __( 'Text Highlight', 'newsy-elements' ),
				'tg-highlight tg-focus'                => __( 'Text Highlight + Focus', 'newsy-elements' ),
				'tg-highlight tg-center'               => __( 'Text Highlight + Center ', 'newsy-elements' ),
				'tg-highlight tg-center tg-focus'      => __( 'Text Highlight + Center + Focus', 'newsy-elements' ),
				'tg-highlight tg-center-left'          => __( 'Text Highlight + Center-Left', 'newsy-elements' ),
				'tg-highlight tg-center-left tg-focus' => __( 'Text Highlight + Center-Left + Focus', 'newsy-elements' ),
			),
		);

		$styles[] = array(
			'label'   => __( 'Simple', 'newsy-elements' ),
			'options' => array(
				'tg-simple'          => __( 'Simple', 'newsy-elements' ),
				'tg-simple tg-focus' => __( 'Simple + Focus', 'newsy-elements' ),
			),
		);

		return $styles;
	}
}

if ( ! function_exists( 'newsy_get_archive_grid_options' ) ) {
	/**
	 * Get the category sliders field options.
	 *
	 * @return array
	 */
	function newsy_get_archive_grid_options( $default = false ) {
		$buffy_array = ak_array_find_all_by_value( apply_filters( 'ak-framework/shortcode', array() ), 'top_posts', true );

		$final_array = array();

		foreach ( $buffy_array as $id => $array ) {
			$final_array[ $id ]['label'] = $array['name'];
			$final_array[ $id ]['img']   = $array['icon'];
		}

		if ( $default ) {
			$default_array = array(
				'' => array(
					'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/default.png',
					'label' => '',
				),
			);
			$disable_array = array(
				'hide' => array(
					'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/disabled.png',
					'label' => 'hide',
				),
			);

			$final_array = array_merge( $default_array, $final_array, $disable_array );
		}

		return $final_array;
	}
}

if ( ! function_exists( 'newsy_get_archive_list_options' ) ) {
	/**
	 * Get the category loops field options.
	 *
	 * @return array
	 */
	function newsy_get_archive_list_options( $default = false ) {
		$buffy_array = ak_array_find_all_by_value( apply_filters( 'ak-framework/shortcode', array() ), 'cat_loop', true );

		$final_array = array();

		foreach ( $buffy_array as $id => $array ) {
			$final_array[ $id ]['label'] = $array['name'];
			$final_array[ $id ]['img']   = $array['icon'];
		}

		if ( $default ) {
			$default_array = array(
				'' => array(
					'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/default.png',
					'label' => '',
				),
			);

			$final_array = array_merge( $default_array, $final_array );
		}

		return $final_array;
	}
}

if ( ! function_exists( 'newsy_get_block_header_styles' ) ) {
	/**
	 * Get the block headers field options.
	 *
	 * @return array
	 */
	function newsy_get_block_header_styles( $default = false ) {
		$buffy_array = array(
			'style-1'  => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '1' ),
				'value' => 'style-1',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-1.png',
			),
			'style-2'  => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '2' ),
				'value' => 'style-2',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-2.png',
			),
			'style-3'  => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '3' ),
				'value' => 'style-3',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-3.png',
			),
			'style-4'  => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '4' ),
				'value' => 'style-4',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-4.png',
			),
			'style-5'  => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '5' ),
				'value' => 'style-5',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-5.png',
			),
			'style-6'  => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '6' ),
				'value' => 'style-6',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-6.png',
			),
			'style-7'  => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '7' ),
				'value' => 'style-7',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-7.png',
			),
			'style-8'  => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '8' ),
				'value' => 'style-8',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-8.png',
			),
			'style-9'  => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '9' ),
				'value' => 'style-9',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-9.png',
			),
			'style-10' => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '10' ),
				'value' => 'style-10',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-10.png',
			),
			'style-11' => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '11' ),
				'value' => 'style-11',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-11.png',
			),
			'style-12' => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '12' ),
				'value' => 'style-12',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-12.png',
			),
			'style-13' => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '13' ),
				'value' => 'style-13',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-13.png',
			),
			'style-14' => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '14' ),
				'value' => 'style-14',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-14.png',
			),
			'style-15' => array(
				'label' => sprintf( __( 'Style %s', 'newsy-elements' ), '15' ),
				'value' => 'style-15',
				'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/style-15.png',
			),
		);

		if ( $default ) {
			$default_array = array(
				'' => array(
					'img'   => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/block_headers/default.png',
					'value' => '',
				),
			);

			$buffy_array = array_merge( $default_array, $buffy_array );
		}

		return $buffy_array;
	}
}

if ( ! function_exists( 'newsy_get_module_options' ) ) {
	/**
	 * Get the modules field options.
	 *
	 * @return array
	 */
	function newsy_get_module_options() {
		$modules = array();

		$modules['module_1']              = array(
			'name' => __( 'Module 1', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1.png',
		);
		$modules['module_1_large']        = array(
			'name' => __( 'Module 1 Large', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1-large.png',
		);
		$modules['module_1_medium']       = array(
			'name' => __( 'Module 1 Medium', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1-medium.png',
		);
		$modules['module_1_small']        = array(
			'name' => __( 'Module 1 Small', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1-small.png',
		);
		$modules['module_1_small_square'] = array(
			'name' => __( 'Module 1 Small Square', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1-small-square.png',
		);
		$modules['module_1_wide']         = array(
			'name' => __( 'Module 1 Wide', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1-wide.png',
		);
		$modules['module_2']              = array(
			'name' => __( 'Module 2', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-2.png',
		);
		$modules['module_2_wide']         = array(
			'name' => __( 'Module 2 Wide', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-2-wide.png',
		);
		$modules['module_2_tall']         = array(
			'name' => __( 'Module 2 Tall', 'newsy-elements' ),
		);
		$modules['module_3']              = array(
			'name' => __( 'Module 3', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-3.png',
		);
		$modules['module_4']              = array(
			'name' => __( 'Module 4', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-4.png',
		);
		$modules['module_5']              = array(
			'name' => __( 'Module 5', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-5.png',
		);
		$modules['module_6']              = array(
			'name' => __( 'Module 6', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-6.png',
		);
		$modules['module_7']              = array(
			'name' => __( 'Module 7', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-7.png',
		);
		$modules['module_8']              = array(
			'name' => __( 'Module 8', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-8.png',
		);
		$modules['module_9']              = array(
			'name' => __( 'Module 9', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-9.png',
		);
		$modules['module_10']             = array(
			'name' => __( 'Module 10', 'newsy-elements' ),
			'img'  => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-10.png',
		);
		//used for grid items
		$modules['module_grid_big']      = array(
			'name' => __( 'Module Grid Big Item', 'newsy-elements' ),
		);
		$modules['module_grid_small']    = array(
			'name' => __( 'Module Grid Small Item', 'newsy-elements' ),
		);
		$modules['module_grid_tall']     = array(
			'name' => __( 'Module Grid Tall Item', 'newsy-elements' ),
		);
		$modules['module_grid_wide']     = array(
			'name' => __( 'Module Grid Wide Item', 'newsy-elements' ),
		);
		$modules['module_grid_wide_big'] = array(
			'name' => __( 'Module Grid Wide Big Item', 'newsy-elements' ),
		);

		return $modules;
	}
}

if ( ! function_exists( 'newsy_get_module_fields' ) ) {
	/**
	 * Get the modules field options.
	 *
	 * @return array
	 */
	function newsy_get_module_fields( $module_id = '' ) {
		$fields = array();

		$modules = newsy_get_module_options();

		if ( isset( $modules[ $module_id ]['img'] ) ) {
			$fields['module_preview'] = array(
				'heading'         => '',
				'id'              => 'module_preview',
				'type'            => 'custom_field',
				'container_class' => 'control-heading-hide',
				'html'            => '<img width="150" src="' . $modules[ $module_id ]['img'] . '" />',
			);
		}

		$fields['title_length']       = array(
			'heading'         => __( 'Title Length', 'newsy-elements' ),
			'id'              => 'title_length',
			'type'            => 'number',
			'container_class' => 'control-heading-full',
		);
		$fields['show_excerpt']       = array(
			'heading'         => __( 'Show Excerpt', 'newsy-elements' ),
			'id'              => 'show_excerpt',
			'field_col'       => 2,
			'type'            => 'switcher',
			'container_class' => 'control-heading-full',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
		);
		$fields['excerpt_length']     = array(
			'heading'         => __( 'Excerpt Length', 'newsy-elements' ),
			'id'              => 'excerpt_length',
			'type'            => 'number',
			'field_col'       => 2,
			'container_class' => 'control-heading-full module-select-dependency-start',
			'dependency'      => array(
				'element' => 'show_excerpt',
				'value'   => array( '' ),
			),
		);
		$fields['show_meta']          = array(
			'heading'         => __( 'Show Meta', 'newsy-elements' ),
			'id'              => 'show_meta',
			'type'            => 'switcher',
			'container_class' => 'control-heading-full',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
		);
		$fields['show_author_icon']   = array(
			'heading'         => __( 'Author Icon', 'newsy-elements' ),
			'id'              => 'show_author_icon',
			'type'            => 'switcher',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
			'field_col'       => 6,
			'container_class' => 'control-heading-full',
			'dependency'      => array(
				'element' => 'show_meta',
				'value'   => array( '' ),
			),
		);
		$fields['show_author']        = array(
			'heading'         => __( 'Author', 'newsy-elements' ),
			'id'              => 'show_author',
			'type'            => 'switcher',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
			'field_col'       => 6,
			'container_class' => 'control-heading-full',
			'dependency'      => array(
				'element' => 'show_meta',
				'value'   => array( '' ),
			),
		);
		$fields['show_comment_count'] = array(
			'heading'         => __( 'Comments', 'newsy-elements' ),
			'id'              => 'show_comment_count',
			'type'            => 'switcher',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
			'field_col'       => 6,
			'container_class' => 'control-heading-full',
			'dependency'      => array(
				'element' => 'show_meta',
				'value'   => array( '' ),
			),
		);
		$fields['show_share_count']   = array(
			'heading'         => __( 'Shares', 'newsy-elements' ),
			'id'              => 'show_share_count',
			'type'            => 'switcher',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
			'field_col'       => 6,
			'container_class' => 'control-heading-full',
			'dependency'      => array(
				'element' => 'show_meta',
				'value'   => array( '' ),
			),
		);
		$fields['show_view_count']    = array(
			'heading'         => __( 'Views', 'newsy-elements' ),
			'id'              => 'show_view_count',
			'type'            => 'switcher',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
			'field_col'       => 6,
			'container_class' => 'control-heading-full',
			'dependency'      => array(
				'element' => 'show_meta',
				'value'   => array( '' ),
			),
		);

		$fields['show_voting_count'] = array(
			'heading'         => __( 'Votes', 'newsy-elements' ),
			'id'              => 'show_voting_count',
			'type'            => 'switcher',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
			'field_col'       => 6,
			'container_class' => 'control-heading-full module-select-dependency-start',
			'dependency'      => array(
				'element' => 'show_meta',
				'value'   => array( '' ),
			),
		);

		$fields['show_date']          = array(
			'heading'         => __( 'Date', 'newsy-elements' ),
			'id'              => 'show_date',
			'type'            => 'switcher',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
			'field_col'       => 3,
			'container_class' => 'control-heading-full module-select-dependency-start',
			'dependency'      => array(
				'element' => 'show_meta',
				'value'   => array( '' ),
			),
		);
		$fields['date_format']        = array(
			'heading'         => __( 'Date Format', 'newsy-elements' ),
			'id'              => 'date_format',
			'type'            => 'select',
			'options'         => array(
				''       => __( 'Default', 'newsy-elements' ),
				'ago'    => __( 'Ago', 'newsy-elements' ),
				'custom' => __( 'Custom Format', 'newsy-elements' ),
			),
			'field_col'       => 3,
			'container_class' => 'control-heading-full',
			'dependency'      => array(
				'element' => 'show_date',
				'value'   => array( '' ),
			),
		);
		$fields['custom_date_format'] = array(
			'heading'         => __( 'Custom Date Format', 'newsy-elements' ),
			'id'              => 'custom_date_format',
			'type'            => 'text',
			'input_attrs'     => array(
				'placeholder' => 'F j, Y',
			),
			'field_col'       => 3,
			'container_class' => 'control-heading-full',
			'dependency'      => array(
				'element' => 'date_format',
				'value'   => array( 'custom' ),
			),
		);
		$fields['show_category']      = array(
			'heading'         => __( 'Show Categories', 'newsy-elements' ),
			'id'              => 'show_category',
			'type'            => 'switcher',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
			'field_col'       => 3,
			'container_class' => 'control-heading-full',
		);
		$fields['show_category_type'] = array(
			'heading'         => __( 'Category Type', 'newsy-elements' ),
			'id'              => 'show_category_type',
			'type'            => 'select',
			'options'         => array(
				''             => __( 'Default', 'newsy-elements' ),
				'badge'        => __( 'Badge on Image', 'newsy-elements' ),
				'inline'       => __( 'Inline', 'newsy-elements' ),
				'inline_badge' => __( 'Inline Badge', 'newsy-elements' ),
			),
			'field_col'       => 3,
			'container_class' => 'control-heading-full',
			'dependency'      => array(
				'element' => 'show_category',
				'value'   => array( '' ),
			),
		);
		$fields['category_limit']     = array(
			'heading'         => __( 'Category limit', 'newsy-elements' ),
			'id'              => 'category_limit',
			'type'            => 'number',
			'field_col'       => 3,
			'container_class' => 'control-heading-full',
			'dependency'      => array(
				'element' => 'show_category',
				'value'   => array( '' ),
			),
		);
		$fields['show_format_icon']   = array(
			'heading'         => __( 'Format Icon', 'newsy-elements' ),
			'id'              => 'show_format_icon',
			'type'            => 'switcher',
			'container_class' => 'control-heading-full',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
		);

		$fields['show_badge_icon'] = array(
			'heading'         => __( 'Badge Icon', 'newsy-elements' ),
			'id'              => 'show_badge_icon',
			'type'            => 'switcher',
			'container_class' => 'control-heading-full',
			'options'         => array(
				'off' => 'hide',
				'on'  => '',
			),
		);

		if ( $module_id ) {
			$excluded_fields = newsy_get_module_excluded_fields( $module_id );

			if ( ! empty( $excluded_fields ) ) {
				foreach ( $excluded_fields as $id ) {
					unset( $fields[ $id ] );
				}
			}
		}

		return $fields;
	}
}

if ( ! function_exists( 'newsy_get_module_vc_fields' ) ) {
	/**
	 * Get the visual composer modules field options.
	 *
	 * @return array
	 */
	function newsy_get_module_vc_fields( $module_id, $use_module_prefix = false ) {
		$module_prefix = '';
		if ( $use_module_prefix ) {
			$module_prefix = $module_id . '_';
		}

		$module_list = newsy_get_module_options();

		if ( ! isset( $module_list[ $module_id ] ) ) {
			return array();
		}

		return array(
			array(
				'type'    => 'heading',
				'heading' => $module_list[ $module_id ]['name'],
				'id'      => $module_prefix . 'custom_part_heading',
				'section' => __( 'Module', 'newsy-elements' ),
			),
			array(
				'type'    => 'switcher',
				'heading' => __( 'Override Module Parts?', 'newsy-elements' ),
				'id'      => $module_prefix . 'custom_enabled',
				'options' => array(
					'off' => '',
					'on'  => 'yes',
				),
				'section' => __( 'Module', 'newsy-elements' ),
			),
			array(
				'type'            => 'mix_fields',
				'heading'         => __( 'Module Parts', 'newsy-elements' ),
				'id'              => $module_prefix . 'custom_parts',
				'fields_callback' => array(
					'function' => 'newsy_get_module_fields',
					'args'     => $module_id,
				),
				'section'         => __( 'Module', 'newsy-elements' ),
				'container_class' => 'control-heading-hide',
				'dependency'      => array(
					'element' => $module_prefix . 'custom_enabled',
					'value'   => array( 'yes' ),
				),
			),
		);
	}
}

if ( ! function_exists( 'newsy_get_module_excluded_fields' ) ) {
	/**
	 * Get the excluded module fields.
	 *
	 * @return array
	 */
	function newsy_get_module_excluded_fields( $module_id ) {
		$fields = array();

		switch ( $module_id ) {
			case 'module_1_small':
			case 'module_1_small_right':
			case 'module_1_small_square':
				$fields = array( 'show_excerpt', 'excerpt_length', 'show_category', 'show_category_type', 'category_limit' );
				break;

			case 'module_3':
				$fields = array( 'show_excerpt', 'excerpt_length', 'show_badge_icon' );
				break;

			case 'module_8':
				$fields = array( 'show_excerpt', 'excerpt_length', 'show_badge_icon', 'show_format_icon' );
				break;

			case 'module_9':
				$fields = array( 'show_excerpt', 'excerpt_length', 'show_badge_icon', 'show_format_icon' );
				break;

			case 'module_10':
				$fields = array( 'show_excerpt', 'excerpt_length', 'show_badge_icon', 'show_format_icon' );
				break;
		}

		return $fields;
	}
}

if ( ! function_exists( 'newsy_get_ad_size_options' ) ) {
	/**
	 * Handy callback to get ads sizes.
	 *
	 * @return array
	 */
	function newsy_get_ad_size_options() {
		return array(
			''        => esc_attr__( 'Auto', 'newsy-elements' ),
			'hide'    => esc_attr__( 'Hide', 'newsy-elements' ),
			'120x90'  => '120x90',
			'120x240' => '120x240',
			'120x600' => '120x600',
			'125x125' => '125x125',
			'160x90'  => '160x90',
			'160x600' => '160x600',
			'180x90'  => '180x90',
			'180x150' => '180x150',
			'200x90'  => '200x90',
			'200x200' => '200x200',
			'234x60'  => '234x60',
			'250x250' => '250x250',
			'320x100' => '320x100',
			'300x250' => '300x250',
			'300x600' => '300x600',
			'320x50'  => '320x50',
			'336x280' => '336x280',
			'468x15'  => '468x15',
			'468x60'  => '468x60',
			'728x15'  => '728x15',
			'728x90'  => '728x90',
			'970x90'  => '970x90',
			'240x400' => '240x400',
			'250x360' => '250x360',
			'580x400' => '580x400',
			'750x100' => '750x100',
			'750x200' => '750x200',
			'750x300' => '750x300',
			'980x120' => '980x120',
			'930x180' => '930x180',
		);
	}
}

if ( ! function_exists( 'newsy_get_block_ad_fields' ) ) {
	/**
	 * Get the ad field options.
	 *
	 * @return array
	 */
	function newsy_get_block_ad_fields( $ad = '' ) {
		return array(
			array(
				'id'          => 'type',
				'type'        => 'visual_select',
				'heading'     => __( 'Ads Type', 'newsy-elements' ),
				'admin_label' => true,
				'options'     => array(
					''       => __( 'No Ads', 'newsy-elements' ),
					'google' => __( 'Google Ads', 'newsy-elements' ),
					'image'  => __( 'Image Ads', 'newsy-elements' ),
					'code'   => __( 'Script Code', 'newsy-elements' ),
				),
				'section'     => __( 'Ads', 'newsy-elements' ),
			),
			array(
				'id'              => 'image',
				'type'            => 'media_image',
				'heading'         => __( 'Ads Image', 'newsy-elements' ),
				'dependency'      => array(
					'element' => 'type',
					'value'   => array( 'image' ),
				),
				'media_data_type' => 'id',
				'section'         => __( 'Ads', 'newsy-elements' ),
			),

			array(
				'id'         => 'image_link',
				'type'       => 'text',
				'heading'    => __( 'Ads Image Link', 'newsy-elements' ),
				'dependency' => array(
					'element' => 'type',
					'value'   => array( 'image' ),
				),
				'section'    => __( 'Ads', 'newsy-elements' ),
			),

			array(
				'id'         => 'image_alt',
				'type'       => 'text',
				'heading'    => __( 'Ads  Alternate Text', 'newsy-elements' ),
				'dependency' => array(
					'element' => 'type',
					'value'   => array( 'image' ),
				),
				'section'    => __( 'Ads', 'newsy-elements' ),
			),
			array(
				'id'         => 'image_new_tab',
				'type'       => 'select',
				'heading'    => __( 'Ads Open New Tab', 'newsy-elements' ),
				'options'    => array(
					''   => __( 'Open new tab', 'newsy-elements' ),
					'no' => __( 'Current tab', 'newsy-elements' ),
				),
				'dependency' => array(
					'element' => 'type',
					'value'   => array( 'image' ),
				),
				'section'    => __( 'Ads', 'newsy-elements' ),
			),
			array(
				'id'          => 'google_client_id',
				'type'        => 'text',
				'heading'     => __( 'Ads Client ID', 'newsy-elements' ),
				'description' => esc_html__( 'Insert data-ad-client / google_ad_client content.', 'newsy-elements' ),
				'dependency'  => array(
					'element' => 'type',
					'value'   => array( 'google' ),
				),
				'section'     => __( 'Ads', 'newsy-elements' ),
			),
			array(
				'id'          => 'google_slot_id',
				'type'        => 'text',
				'heading'     => __( 'Ads Slot ID', 'newsy-elements' ),
				'description' => esc_html__( 'Insert data-ad-slot / google_ad_slot content.', 'newsy-elements' ),
				'dependency'  => array(
					'element' => 'type',
					'value'   => array( 'google' ),
				),
				'section'     => __( 'Ads', 'newsy-elements' ),
			),
			array(
				'id'               => 'google_desktop',
				'type'             => 'select',
				'heading'          => __( 'Ads Desktop Size', 'newsy-elements' ),
				'description'      => esc_html__( 'Insert data-ad-slot / google_ad_slot content.', 'newsy-elements' ),
				'options_callback' => 'newsy_get_ad_size_options',
				'dependency'       => array(
					'element' => 'type',
					'value'   => array( 'google' ),
				),
				'section'          => __( 'Ads', 'newsy-elements' ),
			),
			array(
				'id'               => 'google_tablet',
				'type'             => 'select',
				'heading'          => __( 'Ads Tablet Size', 'newsy-elements' ),
				'description'      => esc_html__( 'Choose ads size to show on tablet.', 'newsy-elements' ),
				'options_callback' => 'newsy_get_ad_size_options',
				'dependency'       => array(
					'element' => 'type',
					'value'   => array( 'google' ),
				),
				'section'          => __( 'Ads', 'newsy-elements' ),
			),
			array(
				'id'               => 'google_phone',
				'type'             => 'select',
				'heading'          => __( 'Ads Phone Size', 'newsy-elements' ),
				'description'      => esc_html__( 'Choose ads size to show on phone.', 'newsy-elements' ),
				'options_callback' => 'newsy_get_ad_size_options',
				'dependency'       => array(
					'element' => 'type',
					'value'   => array( 'google' ),
				),
				'section'          => __( 'Ads', 'newsy-elements' ),
			),
			array(
				'id'                => 'content',
				'type'              => 'textarea',
				'heading'           => __( 'Ads Code', 'newsy-elements' ),
				'description'       => esc_html__( 'Put your full ads script right here.', 'newsy-elements' ),
				'dependency'        => array(
					'element' => 'type',
					'value'   => array( 'code' ),
				),
				'section'           => __( 'Ads', 'newsy-elements' ),
				'sanitize_callback' => false,
			),
		);
	}
}
