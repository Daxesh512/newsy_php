Change Log :

== 1.5.0 ==
- [IMPROVEMENT] Compatible with Newsy v1.5.0

== 1.0.5 ==
- [IMPROVEMENT] Some minor style changes
- [IMPROVEMENT] Added module preview images to module fields
- [IMPROVEMENT] Added missed translations
- [FIX] Issue on Block tabs

== 1.0.3 ==
- [FIX] Block post count issue

== 1.0.2 ==
- [IMPROVEMENT] Some minor style changes
- [FIX] Issue on WPBakery Page Builder default values

== 1.0.1 ==
- [IMPROVEMENT] Some minor style changes

== 1.0.0 ==
- First Release
