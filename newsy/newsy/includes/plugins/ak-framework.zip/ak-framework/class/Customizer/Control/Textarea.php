<?php
namespace Ak\Customizer\Control;

/**
 * Slider control (range).
 */
class Textarea extends ControlAbstract {

	/**
	 * The control type.
	 *
	 * @var string
	 */
	public $_type = 'textarea';

}
