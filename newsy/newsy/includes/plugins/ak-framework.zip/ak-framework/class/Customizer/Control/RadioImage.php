<?php
namespace Ak\Customizer\Control;

/**
 * Radio Image control (modified radio).
 */
class RadioImage extends ControlAbstract {
	public $_type = 'radio_image';
}
