<?php

namespace Ak\Customizer\Section;

/**
 * Default Section.
 */
class DefaultSection extends \WP_Customize_Section {

}
