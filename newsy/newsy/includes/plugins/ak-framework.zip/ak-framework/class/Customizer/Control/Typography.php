<?php
namespace Ak\Customizer\Control;

/**
 * Typography control.
 */
class Typography extends ControlAbstract {

	/**
	 * The control type.
	 *
	 * @var string
	 */
	public $_type = 'typography';
}
