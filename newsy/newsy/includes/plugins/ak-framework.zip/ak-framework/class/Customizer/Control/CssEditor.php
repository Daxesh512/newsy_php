<?php

namespace Ak\Customizer\Control;

/**
 * Typography control.
 */
class CssEditor extends ControlAbstract {
	/**
	 * The control type.
	 *
	 * @var string
	 */
	public $_type = 'css_editor';
}
