<?php
namespace Ak\Customizer\Control;

/**
 * Radio Icon set control (modified radio).
 */
class RadioIcon extends ControlAbstract {
	public $_type = 'radio_icon';
}
