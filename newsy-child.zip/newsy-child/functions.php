<?php

// Dev mode enabled
// Use this for uncompressed custom css codes
//if ( ! defined( 'AK_DEV_MODE' ) ) {
//	define( 'AK_DEV_MODE', TRUE );
//}
