Change Log:

== 1.0.6 ==
- [FIX] Issue on Part builder

== 1.0.5 ==
- [IMPROVEMENT] Demo data updated
- [IMPROVEMENT] Added missing translations
- [IMPROVEMENT] Framework compatibility
- [FIX] Missing option for hiding post categories

== 1.0.4 ==
- [IMPROVEMENT] Demo data updated
- [FIX] Issue on SSL asset redirects
- [FIX] Some minor issues & style fixes

== 1.0.3 ==
- [FIX] Demos import data update
- [FIX] Number of smaller issues

== 1.0.2 ==
- [FIX] Issue on Dark Mode style
- [FIX] Issue on RTL style
- [FIX] Issue on Header & Footer presets
- [FIX] Minnor CSS issues

== 1.0.1 ==
- [IMPROVEMENT] Some minor style changes
- [FIX] Issue on reCaptcha validation
- [FIX] Issue on post progress bar

== 1.0.0 ==
- First Release
