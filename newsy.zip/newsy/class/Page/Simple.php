<?php
namespace Newsy\Page;

use Newsy\TemplateAbstract;

/**
 * Simple Page template class.
 */
class Simple extends TemplateAbstract { }
