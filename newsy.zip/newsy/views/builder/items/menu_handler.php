<div class="ak-bar-item ak-header-menu-handler ">
	<a href="#" class="ak-menu-handler">
		<span></span>
		<span></span>
		<span></span>
	</a>
</div>
