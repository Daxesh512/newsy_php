<div class="ak-bar-item ak-header-ad1">
	<?php newsy_get_ad( 'header_ad1' ); ?>
</div>
