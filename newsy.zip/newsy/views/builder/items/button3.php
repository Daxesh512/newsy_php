<div class="ak-bar-item ak-header-button ak-header-button3">
	<?php newsy_generate_button( 'header_button3' ); ?>
</div>
