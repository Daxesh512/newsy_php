<div class="ak-bar-item ak-dark-mode">
	<label class="dark_mode_label">
		<input type="checkbox" class="ak-dark-mode-toggle">
		<span class="slider round"></span>
	</label>
</div>