<div class="ak-bar-item ak-header-html">
	<?php echo do_shortcode( newsy_get_option( 'header_html_2', '' ) ); ?>
</div>
