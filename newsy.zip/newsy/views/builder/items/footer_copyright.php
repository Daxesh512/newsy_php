<div class="ak-bar-item ak-footer-copyright">
	<?php echo newsy_get_copyright_text(); ?>
</div>
