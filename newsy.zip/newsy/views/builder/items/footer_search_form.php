<div class="ak-bar-item ak-header-search-form">
	<div class="search-box clearfix">
		<?php get_search_form(); ?>
	</div>
</div>
