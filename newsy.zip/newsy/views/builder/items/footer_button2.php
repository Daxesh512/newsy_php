<div class="ak-bar-item ak-footer-button2">
	<?php newsy_generate_button( 'footer_button2' ); ?>
</div>
