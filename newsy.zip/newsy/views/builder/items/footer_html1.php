<div class="ak-bar-item ak-footer-html">
	<?php echo do_shortcode( newsy_get_option( 'footer_html_1', '' ) ); ?>
</div>
