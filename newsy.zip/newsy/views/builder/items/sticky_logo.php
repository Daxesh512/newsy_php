<div class="ak-bar-item ak-sticky-logo">
	<div class="ak-logo-wrap ak-logo-<?php echo newsy_get_option( 'sticky_logo_type', 'image' ); ?>">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php echo newsy_generate_logo( 'sticky' ); ?>
		</a>
	</div>
</div>
